package com.sf.realtime.test;

import com.sf.realtime.common.utils.DateUtil;
import com.sf.realtime.common.utils.MD5Util;

/**
 * @Author 01419728
 * @Date 2022/2/15 18:09
 */
public class DateTimeTest {
    public static void main(String[] args) {
        String carNo = "389227224803";
        String s = new StringBuffer(carNo).reverse().toString();
        System.out.println("rt_container_waybill_relation 表的rowkey"+s);
        String weybill="SF2060933170912";
        String rowKey = MD5Util.getMD5(weybill);
        Long time = DateUtil.getTime(7);
        System.out.println(rowKey);
    }
}