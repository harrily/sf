package com.sf.realtime.common.pojo;

public enum WhichDay {
    YESTERDAY,TODAY,TOMORROW;
}
