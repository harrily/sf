package com.sf.realtime.common.config;

import com.typesafe.config.ConfigFactory;

public class Config {
    private static com.typesafe.config.Config config;
    private static com.typesafe.config.Config schema_config;
    static{
         config = ConfigFactory.load();
        schema_config = ConfigFactory.load("schema/schema.conf");
    }

    public static com.typesafe.config.Config getConfig() {
        return config;
    }
    public static com.typesafe.config.Config getSchemaConfig() {
        return schema_config;
    }
}
