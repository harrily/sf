package com.sf.bdp.report.util;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

/**
 * Creator: 01380994
 * Date: 2019/9/10
 */
public final class CryptUtils {

    private static final String AES = "AES";

    protected static final char[] HEX_ARRAY= {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

    public static final String encryptAES(String text, String key) throws Exception {
        KeyGenerator kgen = KeyGenerator.getInstance(AES);
        SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
        secureRandom.setSeed(key.getBytes());
        kgen.init(128, secureRandom);
        SecretKey secretKey = kgen.generateKey();
        byte[] encBytes = secretKey.getEncoded();
        SecretKeySpec keySpec = new SecretKeySpec(encBytes, AES);

        Cipher cipher = Cipher.getInstance(AES);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec);
        byte[] bytes = cipher.doFinal(text.getBytes("utf-8"));
        String hexStr = bytesToHex(bytes);
        byte[] base64Bytes = Base64.getEncoder().encode(hexStr.getBytes());
        String encrypted = new String(base64Bytes, "utf-8");

        return encrypted;
    }

    public static final String decryptAES(String encrypted, String key) throws Exception {
        KeyGenerator kgen = KeyGenerator.getInstance(AES);
        SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
        secureRandom.setSeed(key.getBytes());
        kgen.init(128, secureRandom);
        SecretKey secretKey = kgen.generateKey();
        byte[] encBytes = secretKey.getEncoded();
        SecretKeySpec keySpec = new SecretKeySpec(encBytes, AES);

        Cipher cipher = Cipher.getInstance(AES);
        cipher.init(Cipher.DECRYPT_MODE, keySpec);
        byte[] base64Bytes = encrypted.getBytes("utf-8");
        String hexStr = new String(Base64.getDecoder().decode(base64Bytes));
        byte[] bytes = cipher.doFinal(hexToBytes(hexStr));
        String text = new String(bytes, "utf-8");

        return text;
    }

    private static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }

        return new String(hexChars);
    }

    private static byte[] hexToBytes(String hexStr) {
        byte[] result = new byte[hexStr.length() / 2];

        for(int i = 0; i < hexStr.length() / 2; ++i) {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
            result[i] = (byte)(high * 16 + low);
        }

        return result;
    }

    public static void main(String[] args) throws Exception {
        boolean flag = true;
        DateTimeFormatter df3 = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime last = now.minusDays(2);
        while(flag){
            last = last.minusDays(1);
            String day = last.format(df3);
            String sql = "alter table sx_dim_department drop partition p"+day+";";
            System.out.println(sql);
            if(day.compareTo("20200302") == -1){
                flag = false;
            }
        }


    }

}
