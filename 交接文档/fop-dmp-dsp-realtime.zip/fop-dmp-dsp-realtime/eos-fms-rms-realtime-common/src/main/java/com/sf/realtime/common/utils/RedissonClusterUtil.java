package com.sf.realtime.common.utils;

import com.typesafe.config.ConfigFactory;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.ClusterServersConfig;
import org.redisson.config.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @Classname: RedissionSentinelUtil
 * @Description:
 * @Author: 01391007
 * @Date: 2020/2/9 16:46
 * @Version: V1.0
 */
public class RedissonClusterUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(RedissonClusterUtil.class);

    private static RedissonClient redission;
    static {
        init();
    }

    private static void init() {
        com.typesafe.config.Config config = ConfigFactory.load();
        String password = config.getString("redis.password");

        List<String> serverArray = config.getStringList("redis.nodes");

        Config redisConfig = new Config();
        redisConfig.setCodec(new org.redisson.client.codec.StringCodec());
        ClusterServersConfig clusterConfig = redisConfig.useClusterServers();
        clusterConfig.addNodeAddress(serverArray.toArray(new String[serverArray.size()]));

        if(password != null && !password.equals(""))
            clusterConfig.setPassword(password);

        redission = Redisson.create(redisConfig);

    }

    public static RedissonClient getClient(){
        return redission;
    }
}