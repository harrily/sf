package com.sf.realtime.common.utils;

import com.sf.realtime.common.config.Config;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPoolConfig;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RedisClusterPool {
    private static JedisCluster jedisCluster = null;
    static{
        Set<HostAndPort> connectionMes = new HashSet<>();
        List<String> nodes = Config.getConfig().getStringList("redis.nodes");
        String password = Config.getConfig().getString("redis.password");
        for(String node : nodes){
            String host = node.split(":")[0];
            Integer port = Integer.parseInt(node.split(":")[1]);
            connectionMes.add(new HostAndPort(host, port));
        }
        //连接池配置
        JedisPoolConfig poolConfig = new JedisPoolConfig();
        //最大连接数
        poolConfig.setMaxTotal(1000);
        //最大空闲连接数
        poolConfig.setMaxIdle(10);
        int connectionTimeout = 10000;
        int soTimeout = 3000;
        int maxAttempts = 5;
        jedisCluster = new JedisCluster(connectionMes,connectionTimeout,soTimeout,maxAttempts,password,poolConfig);
    }

    public synchronized static JedisCluster getConn(){
        return jedisCluster;
    }
}
