package com.sf.realtime.common;

import com.alibaba.fastjson.JSONObject;
import com.github.kevinsawicki.http.HttpRequest;
import org.apache.http.protocol.HTTP;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    private static final Logger log = LoggerFactory.getLogger(App.class);
    private static String REGISTER_URL = "https://sfbi.sf-express.com/cdbi-ext/user/create";
    private static String TOKEN_KEY = "9008185DB4876E86841788A0C0E058A8";
    public static void main( String[] args ) throws Exception {
        int i = 0;
        for(EmpInfo emp : readEmpInfo()){
            System.out.println(emp.getName());
            System.out.println(emp.getEmpNo());
            System.out.println(emp.getEmail());
            System.out.println(emp.getPhone());
            registerJmFjt(emp.getName(),emp.getEmpNo(),emp.getEmail(),emp.getPhone());
            i++;
        }
        System.out.println(i);
    }
    public static void registerJmFjt(String name,String empNo,String email,String phone) throws Exception {
        HashMap<String,String> header=new HashMap<>();
        String token = com.sf.bdp.report.util.CryptUtils.encryptAES("FOP-DMP-DSP"+System.currentTimeMillis(),TOKEN_KEY);
        header.put(HTTP.CONTENT_TYPE, HttpRequest.CONTENT_TYPE_JSON);
        header.put(HTTP.CONTENT_LEN,HttpRequest.HEADER_CONTENT_LENGTH);
        header.put(HTTP.TARGET_HOST,"");
        header.put("token", token);
        header.put("appId","FOP-DMP-DSP");
        header.put("extId","01388729");
        JSONObject j = new JSONObject();
        j.put("userLogin",empNo);
        j.put("userName",name);
        j.put("mailAddress",email);
        j.put("phone",phone);

        boolean success = false;
        int i=0;
        JSONObject res = null;
        while(i++<3&& !success){
            try {
                String body = HttpRequest.post(REGISTER_URL).headers(header).send(j.toJSONString()).body();
                res = JSONObject.parseObject(body);
            } catch (Exception e) {
                log.error("数据请求失败", e.getMessage());
            }
            if (res != null) {
                log.info("res keys: " + res.keySet());
                if(res.keySet().contains("errMsg")){
                    log.info("postData errMsg: "+res.getString("errorMessage"));
                }

                success = res.getBoolean("status");
                log.info("数据请求状态success: "+success);
            }else{
                log.info("数据请求失败");
            }
        }
    }
    private static List<EmpInfo> readEmpInfo(){
        List<EmpInfo> list = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader("D:/data/sxemp8.txt"));
            String line = null;
            while((line=reader.readLine())!=null){
                String item[] = line.split(",");
                EmpInfo empInfo = new EmpInfo();
                empInfo.setName(item[1]);
                empInfo.setEmpNo(item[0]);
                empInfo.setEmail(item[3]);
                empInfo.setPhone(item[2]);
                list.add(empInfo);
            }
        }catch (Exception e){

        }finally {

        }
        return list;
    }

    static class EmpInfo{
        private String name;
        private String empNo;
        private String email;
        private String phone;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getEmpNo() {
            return empNo;
        }

        public void setEmpNo(String empNo) {
            this.empNo = empNo;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }
    }

}
