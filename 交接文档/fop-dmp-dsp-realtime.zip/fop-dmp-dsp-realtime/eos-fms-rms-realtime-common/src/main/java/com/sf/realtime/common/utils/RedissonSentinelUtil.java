package com.sf.realtime.common.utils;

import com.typesafe.config.ConfigFactory;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.redisson.config.SentinelServersConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @Classname: RedissionSentinelUtil
 * @Description:
 * @Author: 01391007
 * @Date: 2020/2/9 16:46
 * @Version: V1.0
 */
public class RedissonSentinelUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(RedissonSentinelUtil.class);

    private static RedissonClient redission;
    static {
        init();
    }

    private static void init() {
        com.typesafe.config.Config config = ConfigFactory.load();
        String password = config.getString("redis1.password");
        String masterName = config.getString("redis1.cluster.name");

        String clusterStr = config.getString("redis1.cluster.servers");
        String[] serverArray = clusterStr.split(",");

        Config redisConfig = new Config();
        redisConfig.setCodec(new org.redisson.client.codec.StringCodec());
        SentinelServersConfig sentinelConfig = redisConfig.useSentinelServers();
        sentinelConfig.addSentinelAddress(serverArray);
        sentinelConfig.setMasterName(masterName);

        if(password != null && !password.equals(""))
            sentinelConfig.setPassword(password);

        redission = Redisson.create(redisConfig);

    }

    public static RedissonClient getClient(){
        return redission;
    }
}