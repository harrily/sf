package com.sf.realtime.common.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class ParamConfig {

    public static Properties configByKafka(String kafkaClusterName,String taskName){
        Properties props = new Properties();
        props.put("bootstrap.servers", Config.getConfig().getString(kafkaClusterName+".kafka.bootstrap.servers"));
        props.put("zookeeper.connect", Config.getConfig().getString(kafkaClusterName+".kafka.zookeeper.connect"));
        props.put("group.id",  Config.getConfig().getString(kafkaClusterName+".kafka."+taskName+".task.group.id"));
        props.put("enable.auto.commit", "true");
        props.put("auto.commit.interval.ms", "1000");
        props.put("auto.offset.reset", Config.getConfig().getString(kafkaClusterName+".kafka.auto.offset.reset"));
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        return props;
    }

    public static Map<String, String> getKafkaConfigMap(String kafkaClusterName, String taskName){
        Map<String, String> map = new HashMap<>();
        map.put("bootstrap.servers", Config.getConfig().getString(kafkaClusterName+".kafka.bootstrap.servers"));
        map.put("zookeeper.connect", Config.getConfig().getString(kafkaClusterName+".kafka.zookeeper.connect"));
        map.put("group.id",  Config.getConfig().getString(kafkaClusterName+".kafka."+taskName+".task.group.id"));
        map.put("enable.auto.commit", "true");
        map.put("auto.commit.interval.ms", "1000");
        map.put("auto.offset.reset", Config.getConfig().getString(kafkaClusterName+".kafka.auto.offset.reset"));
        map.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        map.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        return map;
    }
}
