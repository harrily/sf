package com.sf.realtime.common.utils;

import com.sf.realtime.common.pojo.WhichDay;

import java.sql.Timestamp;
import java.text.ParseException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.Date;

public class DateUtil {
    public static final DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final DateTimeFormatter df2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public static final DateTimeFormatter df3 = DateTimeFormatter.ofPattern("yyyyMMdd");
    @Deprecated
    public static Date getCurrentStartDate(int startHours) throws ParseException {
        LocalDateTime now = LocalDateTime.now();
        int currentHours = now.getHour();
        if(currentHours < startHours){
            LocalDateTime last = now.minusDays(1);
            LocalDateTime start = LocalDate.parse(df.format(last),df).atStartOfDay();
            LocalDateTime end = start.plusHours(startHours);
            return Date.from(end.atZone(ZoneId.systemDefault()).toInstant());
        }else{
            LocalDateTime start = LocalDate.parse(df.format(now),df).atStartOfDay();
            LocalDateTime end = start.plusHours(startHours);
            return Date.from(end.atZone(ZoneId.systemDefault()).toInstant());
        }
    }
    @Deprecated
    public static Date getCurrentStartDate2(int startHours) throws ParseException {
        LocalDateTime now = LocalDateTime.now();
        int currentHours = now.getHour();
        if(currentHours >= startHours){
            LocalDateTime last = now.plusDays(1);
            LocalDateTime start = LocalDate.parse(df.format(last),df).atStartOfDay();
            LocalDateTime end = start.plusHours(startHours);
            return Date.from(end.atZone(ZoneId.systemDefault()).toInstant());
        }else{
            LocalDateTime start = LocalDate.parse(df.format(now),df).atStartOfDay();
            LocalDateTime end = start.plusHours(startHours);
            return Date.from(end.atZone(ZoneId.systemDefault()).toInstant());
        }
    }


    public static Date getCurrentStartDate(int startHours, WhichDay day ) throws ParseException {
        LocalDateTime now = LocalDateTime.now();
        int currentHours = now.getHour();
        switch (day){
            case TOMORROW:
                return getCurrentStartDate2(startHours);
            case TODAY:
                return getCurrentStartDate(startHours);
            default:
                return null;
        }
    }
    @Deprecated
    public static Long getCurrentStartTime(int startHours) throws ParseException {
        return getCurrentStartDate(startHours).getTime();
    }

    public static Long getCurrentStartTime(int startHours, WhichDay day) throws ParseException {
        switch (day){
            case TOMORROW:
                return getCurrentStartDate2(startHours).getTime();
            case TODAY:
                return getCurrentStartDate(startHours).getTime();
            default:
                return null;
        }
    }

    public static Long getBeforeDayStartTime(int startHours, int beforeDays) throws ParseException {
        Long currentStartTime = getCurrentStartTime(startHours,WhichDay.TODAY);
        Instant instant = Instant.ofEpochMilli(currentStartTime);
        ZoneId zone = ZoneId.systemDefault();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant,zone);
        LocalDateTime beforeLocal = localDateTime.minusDays(beforeDays);
        return beforeLocal.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

    @Deprecated
    public static Timestamp getCurrentStartTimestamp(int startHours) throws ParseException {
        return new Timestamp(getCurrentStartTime(startHours));
    }

    public static Timestamp getCurrentStartTimestamp(int startHours,WhichDay day) throws ParseException {
        return new Timestamp(getCurrentStartTime(startHours,day));
    }
    @Deprecated
    public static String getCurrentStartString(int startHours) throws ParseException {
        return getCurrentStartDate(startHours).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime().format(df2);
    }

    public static String getCurrentStartString(int startHours,WhichDay day) throws ParseException {
        return getCurrentStartDate(startHours,day).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime().format(df2);
    }

    public static String getCurrentStartStringWithoutHMS(int startHours,WhichDay day) throws ParseException {
        return getCurrentStartDate(startHours,day).toInstant().atZone(ZoneId.systemDefault()).toLocalDate().format(df);
    }

    public static Long getTime(int lastDay){
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime last = now.minusDays(lastDay);
        return last.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

    public static Long getTime(String date){
        LocalDateTime start =  LocalDate.parse(date,df).atStartOfDay();
        return start.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

    public static Long getTimeWithHms(String date){
        LocalDateTime start =  LocalDateTime.parse(date,df2);
        return start.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

    public static Timestamp getTimestamp(int lastDay){
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime last = now.minusDays(lastDay);
        return new Timestamp(last.toInstant(ZoneOffset.of("+8")).toEpochMilli());
    }

    public static String getDateString(int lastDay){
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime last = now.minusDays(lastDay);
        return last.format(df2);
    }


    public static String getDateString2(int lastDay){
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime last = now.minusDays(lastDay);
        return last.format(df3);
    }
    public static String getDateString1(int lastDay){
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime last = now.minusDays(lastDay);
        return last.format(df);
    }

    public static String getDateStringWithoutHMS(int lastDay){
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime last = now.minusDays(lastDay);
        return last.format(df);
    }

    public static String getDateString(long currentTime, int lastDay){
        LocalDateTime now = LocalDateTime.ofEpochSecond(currentTime/1000,0,ZoneOffset.ofHours(8));
        LocalDateTime last = now.minusDays(lastDay);
        return last.format(df2);
    }

    public static Long getLastHoursTime(int lastHours){
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime last = now.minusHours(lastHours);
        return last.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

    public static Long getAfterHoursTime(int afterHours){
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime after = now.plusHours(afterHours);
        return after.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

    public static int getDayOfWeek(){
        LocalDate local = LocalDate.now();
        return local.getDayOfWeek().getValue();
    }

    public static String getLastYearDayString(String date,int lastYear){
        LocalDateTime start =  LocalDate.parse(date,df).atStartOfDay();
        LocalDateTime last = start.minusYears(lastYear);
        return last.format(df);
    }
    public static String getLastDayString(String date,int lastDay){
        LocalDateTime start =  LocalDate.parse(date,df).atStartOfDay();
        LocalDateTime last = start.minusDays(lastDay);
        return last.format(df);
    }

    public static Long getTime3(String date){
        LocalDateTime start =  LocalDate.parse(date,df3).atStartOfDay();
        return start.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

    public static Long getLastTime3(String date,int lastDay){
        LocalDateTime start =  LocalDate.parse(date,df3).atStartOfDay();
        LocalDateTime last = start.minusDays(lastDay);
        return last.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }
    public static Long getLastTimeStamp(String date,int lastDay){
        // 取lastDay的00:00:00
        LocalDateTime start =  LocalDate.parse(date,df2).atStartOfDay();
        LocalDateTime last = start.minusDays(lastDay);
        return last.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }
    public static String timestampToDate(long dateString){
        LocalDateTime date1 = LocalDateTime.ofEpochSecond(dateString/1000,0,ZoneOffset.ofHours(8));
        return date1.format(df3);
    }
    public static String getLastDayStringdf3(String date,int lastDay){
        LocalDateTime start =  LocalDate.parse(date,df3).atStartOfDay();
        LocalDateTime last = start.minusDays(lastDay);
        return last.format(df3);
    }
    public static String df2Todf3(String date){
        LocalDateTime localTime =  LocalDateTime.parse(date,df2);
        return localTime.format(df3);
    }
    public static Long getLastHoursTime(String countDate,int lastHours){//统计时间前24小时
        LocalDateTime start =  LocalDateTime.parse(countDate,df2);
        LocalDateTime last = start.minusHours(lastHours);
        return last.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

    public static String getLastStringTime(String countDate,int lastDay){//统计时间前24小时
        LocalDateTime start =  LocalDateTime.parse(countDate,df2);
        LocalDateTime last = start.minusDays(lastDay);
        return last.format(df2);
    }

    public static void main(String[] args) throws ParseException {
//        System.out.println(getLastStringTime("2021-11-04 09:00:00",-5).substring(0,10).concat(" 00:00:00"));
//        System.out.println(getLastStringTime("2021-11-04 09:00:00",3).substring(0,10).concat(" 00:00:00"));
//        System.out.println(getLastTimeStamp("2021-11-04 09:00:00",3));
//        System.out.println(getLastHoursTime("2021-11-04 09:00:00",24));
        System.out.println("2021-11-04 09:00:00".substring(0, 10));
    }
}
