package com.sf.realtime.common.utils;

import com.typesafe.config.ConfigFactory;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @Classname: RedisUtil
 * @Description: TODO
 * @Author: 01391007
 * @Date: 2020/1/16 17:10
 * @Version: V1.0
 */
public class RedisUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(RedisUtil.class);

    private static RedissonClient redission;
    static {
        init();
    }

    private static void init() {
        com.typesafe.config.Config config = ConfigFactory.load();
        Config redisConfig = new Config();
        redisConfig.setCodec(new org.redisson.client.codec.StringCodec());

        String address = config.getString("redis.host") + ":" + config.getString("redis.port");
        redisConfig.useSingleServer().setAddress(address);

        String max = config.getString("redis.connections.max");
        redisConfig.useSingleServer().setConnectionPoolSize(Integer.parseInt(max));
        redisConfig.useSingleServer().setIdleConnectionTimeout(10000);
        redisConfig.useSingleServer().setConnectTimeout(10000);
        String password = config.getString("redis.user.password");
        redisConfig.useSingleServer().setPassword(password);

        redission = Redisson.create(redisConfig);

    }

    public static RedissonClient getClient(){
        return redission;
    }

}
