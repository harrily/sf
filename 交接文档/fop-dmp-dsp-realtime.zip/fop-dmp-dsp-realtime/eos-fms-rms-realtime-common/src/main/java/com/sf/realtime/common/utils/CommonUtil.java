package com.sf.realtime.common.utils;

import com.sf.realtime.common.pojo.ProductCode;

public class CommonUtil {
    public static boolean isKyProduct(String productCode){
        boolean flag = false;
        for(ProductCode code : ProductCode.values()){
            flag = code.getCode().equals(productCode);
            if(flag){
                break;
            }
        }
        return flag;
    }
}
