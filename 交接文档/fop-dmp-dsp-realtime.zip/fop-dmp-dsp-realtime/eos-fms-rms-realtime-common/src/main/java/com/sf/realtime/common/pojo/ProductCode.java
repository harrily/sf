package com.sf.realtime.common.pojo;

public enum ProductCode {
    heavy_package("重货包裹","SE0100"),
    heavy_package_b("重货包裹b","SE010001"),
    little_ticket("小票零担","SE0101"),
    large_ticket("大票零担","SE0114"),
    logistics_general_trans("物流普运","SE0006"),
    special_general_trans("专线普运","SE0091"),
    heavy_special_trans("重货专运","SE0020");

    private String name;
    private String code;

    private ProductCode(String name, String code) {
        this.code = code;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }
}
