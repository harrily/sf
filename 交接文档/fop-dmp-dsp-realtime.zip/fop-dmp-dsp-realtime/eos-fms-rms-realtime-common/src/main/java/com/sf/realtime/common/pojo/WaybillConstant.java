package com.sf.realtime.common.pojo;

/**
 * Description：运单常量字面值
 * <br/>
 * Copyright (c) ， 2020， 顺丰快运 <br/>
 * This program is protected by copyright laws. <br/>
 * Date: 2020/4/1
 *
 * @author chenyh chenyuanhua@sfmail.sf-express.com
 * @version : 1.0
 */
public interface WaybillConstant {
    //ES集群名称
    String ES_CLUSTER_NAME = "cluster.name";

    //批量写入ES时的记录条数
    String ES_BULK_FLUSH_MAX_ACTIONS = "bulk.flush.max.actions";

    //hbase运单表名称
    String WB_HBASE_TABLE_NAME = "wb_info_data_sx";

    //hbase账单表信息
    String BILL_HBASE_TABLE_NAME = "bill_info_data_sx";

    //运单表列族名称
    String WB_HBASE_CF = "baseInfo";

    //账单表列族名称
    String BILL_HBASE_CF = "baseInfo";

    //hbase 连接池数量
    Integer NUM_HBASE_POOR = 100;

    //es运单索引库名称
    String WB_INDEX = "wb_info_data_sx";

    //es运单索引库type名称
    String WB_TYPE = "wb_info_data_sx";

    //es账单索引库名称
    String BILL_INDEX = "bill_info_data_sx";

    //es账单索引库type名称
    String BILL_TYPE = "bill_info_data_sx";

    //es 连接超时时间
    Integer ES_LINK_TIMEOUT = 5 * 60 * 1000;

    ////ecEwbFlag的值是0|1，这样模糊匹配会出现很多，
    //标准化0：悲伤:1：开心
    String ES_STAND_ECEWBFLAG_0 = "悲伤";
    String ES_STAND_ECEWBFLAG_1 = "高兴";

}
