package com.sf.realtime.common.utils;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisSentinelPool;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class JedisSentinelPoolUtil {
    private static final Logger log = LoggerFactory.getLogger(JedisSentinelPoolUtil.class);
    private static JedisSentinelPool redisSentinelPool = null;

    static {
        Config config = ConfigFactory.load();

        String clusterStr = config.getString("redis.cluster.servers");
        String[] serverArray = clusterStr.split(",");
        Set<String> sentinels = new HashSet<>();
        sentinels.addAll(Arrays.asList(serverArray));
        int maxTotal = config.getInt("redis.maxTotal");
        int maxIdle  = config.getInt("redis.maxIdle");
        int minIdle  = config.getInt("redis.minIdle");
        boolean testOnBorrow = config.getBoolean("redis.testOnBorrow");
        boolean testOnReturn = config.getBoolean("redis.testOnReturn");
        Long maxWaitMillis = config.getLong("redis.maxWaitMillis");
        String password = config.getString("redis.password");
        String masterName = config.getString("redis.cluster.name");

        redisSentinelPool = initPool(sentinels,masterName,maxTotal, maxIdle,minIdle,
                testOnBorrow, testOnReturn,maxWaitMillis,password);
    }

    private static JedisSentinelPool initPool(Set<String> sentinels, String masterName, int maxTotal, int maxIdle, //NOSONAR
                                              int minIdle, boolean testOnBorrow, boolean testOnReturn,
                                              Long maxWaitMillis, String password){
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxTotal(maxTotal);
        config.setMaxIdle(maxIdle);
        config.setMinIdle(minIdle);
        config.setMaxWaitMillis(maxWaitMillis);
        config.setTestOnBorrow(testOnBorrow);
        config.setTestOnReturn(testOnReturn);

        if(password == null || password.equals(""))
            redisSentinelPool = new JedisSentinelPool(masterName,sentinels,config);
        else
            redisSentinelPool = new JedisSentinelPool(masterName,sentinels,config,password);
        return redisSentinelPool;
    }

    public static JedisSentinelPool getRedisSentinelPool(){
        return redisSentinelPool;
    }

    public static void Close(){
        if(redisSentinelPool!=null){
            redisSentinelPool.close();
        }
    }

}
