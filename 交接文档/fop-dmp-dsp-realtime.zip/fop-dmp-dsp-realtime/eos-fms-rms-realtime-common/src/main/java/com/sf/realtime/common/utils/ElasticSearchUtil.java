package com.sf.realtime.common.utils;


import com.google.gson.Gson;
import com.sf.realtime.common.config.Config;
import com.sf.realtime.common.pojo.WaybillConstant;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpStatus;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Description：ES公共类
 * <br/>
 * Copyright (c) ， 2020， 顺丰快运 <br/>
 * This program is protected by copyright laws. <br/>
 * Date: 2020/7/13
 *
 * @author chenyh chenyuanhua@sfmail.sf-express.com
 * @version : 1.0
 */
public class ElasticSearchUtil {
    /**
     * Log日志打印
     **/
    private static final Logger LOG = LoggerFactory.getLogger(ElasticSearchUtil.class);
    /**
     * RestClient对象
     **/
    private static RestClient restClient = null;


    /**
     * 获取连接
     *
     * @return
     */
    public static RestClient getConnect() {
        ArrayList<String> hostsarray = new ArrayList<>();
        List<String> hosts = Config.getConfig().getStringList("es.product.host");      //生产环境
        HttpHost[] httpHosts = new HttpHost[hosts.size()];
        for (int i = 0; i < hosts.size(); i++) {
            httpHosts[i] = new HttpHost(hosts.get(i), Config.getConfig().getInt("es.product.port"));    //生产环境
        }
        return RestClient.builder(httpHosts)
                .setMaxRetryTimeoutMillis(WaybillConstant.ES_LINK_TIMEOUT)
                .build();
    }


    /**
     * 修改mapping
     *
     * @param index
     * @param type
     * @param updataInfo
     * @return
     */
    public static Boolean setMapping(RestClient client, String index, String type, String updataInfo) {
        Boolean resultBoolean;
        Response response;
        if (client == null) {
            return false;
        }
        Request request = new Request("PUT", "/" + index + "/_mapping" + "/" + type);
        NStringEntity nStringEntity = new NStringEntity(updataInfo, ContentType.APPLICATION_JSON);
        request.setEntity(nStringEntity);
        try {
            response = client.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                LOG.info("update successful");
                resultBoolean = true;
            } else {
                LOG.error("update fail!");
                resultBoolean = false;
            }
        } catch (IOException e) {
            LOG.error("e:" + e);
            resultBoolean = false;
        }
        return resultBoolean;
    }

    /**
     * 查看集群状态
     *
     * @return
     */
    public static String catHealth() {
        if (restClient == null) {
            restClient = getConnect();
        }
        Response response;
        String resultStr = "";
        Request request = new Request("GET", "/_cat/health");
        try {
            response = restClient.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                LOG.info("CAT successful!");
                resultStr = EntityUtils.toString(response.getEntity());
            } else {
                LOG.error("ERROR");
            }
        } catch (IOException e) {
            LOG.error("E:" + e);
        }
        return resultStr;
    }

    /**
     * 查询集群索引
     *
     * @return
     */
    public static String catIndices() {
        if (restClient == null) {
            restClient = getConnect();
        }
        Response response;
        String resultStr = "";
        Request request = new Request("GET", "_cat/indices");
        try {
            response = restClient.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                LOG.info("Indices successful");
                resultStr = EntityUtils.toString(response.getEntity());
            }
            {
                LOG.error("not get Indices");
            }
        } catch (IOException e) {
            LOG.error("E:" + e);
        }
        return resultStr;
    }

    /**
     * 手动创建索引，指定settings，和mappings
     *
     * @param index
     * @param data
     * @param isPretty
     * @return
     */
    public static Boolean createIndex(RestClient client, String index, String data, Boolean isPretty) {
        Response response;
        Boolean resultBoolean;
        if (client == null) {
            return null;
        }
        String endpoint = isPretty ? ("/" + index + "?pretty") : index;
        Request request = new Request("PUT", endpoint);
        HttpEntity httpEntity = new NStringEntity(data, ContentType.APPLICATION_JSON);
        request.setEntity(httpEntity);
        try {
            response = restClient.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                LOG.info("Create Successful!");
                resultBoolean = true;
            } else {
                LOG.error("Create ERROR!");
                resultBoolean = false;
            }
        } catch (IOException e) {
            LOG.error("异常:" + e);
            resultBoolean = false;
        }
        return resultBoolean;
    }

    /**
     * 删除索引
     *
     * @param index
     * @return
     */
    public static Boolean deleteIndex(String index) {
        if (restClient == null) {
            restClient = getConnect();
        }
        Response response;
        Boolean resultBoolean;
        Request request = new Request("DELETE", "/" + index);
        try {
            response = restClient.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                LOG.info("Delete successful!");
                resultBoolean = true;
            } else {
                resultBoolean = false;
            }
        } catch (IOException e) {
            LOG.error("Fail:" + e);
            resultBoolean = false;
        }
        return resultBoolean;
    }

    /**
     * delete es doc by doc id
     * @param index
     * @param id
     * @return
     */
    public static Boolean deleteById(String index, String type, String id) throws IOException {
        if (restClient == null){
            restClient = getConnect();
        }
        Response response;
        Boolean resultBoolean;
        Request request = new Request("DELETE", "/" + index+"/"+type+"/" +id);
        response = restClient.performRequest(request);
        if(response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            LOG.info("Delete document with id("+id+") successfully.");
            resultBoolean = true;
        }else {
            resultBoolean = false;
        }
        return resultBoolean;
    }

    /**
     * 向指定索引插入数据,如果不指定id，传入id为空
     *
     * @param index
     * @param type
     * @param id
     * @param data
     * @return
     */
    public static Boolean postDataToIndex(String index, String type, String id, Map<String, String> data) {
        if (restClient == null) {
            restClient = getConnect();
        }
        Response response;
        Boolean resultBoolan;
        String endpoint = id.length() == 0 ? ("/" + index + "/" + type) : ("/" + index + "/" + type + "/" + id);
        Request request = new Request("POST", endpoint);
        Gson gson = new Gson();
        NStringEntity nStringEntity = new NStringEntity(gson.toJson(data), ContentType.APPLICATION_JSON);
        request.setEntity(nStringEntity);
        try {
            response = restClient.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK ||
                    HttpStatus.SC_CREATED == response.getStatusLine().getStatusCode()) {
                LOG.info("POST successful!");
                resultBoolan = true;
            } else {
                LOG.error("POST error!");
                resultBoolan = false;
            }
        } catch (IOException e) {
            LOG.error("exception:" + e);
            resultBoolan = false;
        }
        return resultBoolan;
    }

    /**
     * 指定index type id 数据为字符串，插入数据,如果不指定id，id为空
     *
     * @param index
     * @param type
     * @param id
     * @param data
     * @return
     */
    public static Boolean postDataString(String index, String type, String id, String data) {
        if (restClient == null) {
            restClient = getConnect();
        }
        Response response;
        Boolean resultBoolean;
        String endpoint = id.length() == 0 ? ("/" + index + "/" + type) : ("/" + index + "/" + type + "/" + id);
        Request request = new Request("POST", endpoint);
        NStringEntity nStringEntity = new NStringEntity(data, ContentType.APPLICATION_JSON);
        request.setEntity(nStringEntity);
        try {
            response = restClient.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK ||
                    response.getStatusLine().getStatusCode() == HttpStatus.SC_CREATED) {
                LOG.info("put successful!");
                resultBoolean = true;
            } else {
                LOG.error("PUT error!");
                resultBoolean = false;
            }
        } catch (IOException e) {
            LOG.error(e.toString());
            resultBoolean = false;
        }
        return resultBoolean;
    }

    public static Boolean updateData(String index, String type, String id, String data) throws IOException {
        if (restClient == null) {
            restClient = getConnect();
        }
        Response response;
        Boolean resultBoolean;
        data = "{\"doc\": " + data + "}";
        NStringEntity entity = new NStringEntity(data, ContentType.APPLICATION_JSON);
        Request request = new Request("POST", "/" + index + "/" + type + "/" + id + "/_update");
        request.setEntity(entity);
        response = restClient.performRequest(request);
        if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            LOG.info("update successful!");
            resultBoolean = true;
        } else {
            LOG.error("update error!");
            resultBoolean = false;
        }
        return resultBoolean;
    }

    /**
     * 批量查询：在所有index，type范围内
     *
     * @param client
     * @param data
     * @param isPretty
     * @return
     */
    public static String mgetData(RestClient client, String data, Boolean isPretty) {
        return mgetData(client, "", data, isPretty);
    }

    /**
     * 在指定index内，批量查询
     *
     * @param client
     * @param index
     * @param data
     * @param isPretty
     * @return
     */
    public static String mgetData(RestClient client, String index, String data, Boolean isPretty) {
        return mgetData(client, index, "", data, isPretty);
    }

    /**
     * 在指定index，type范围内，批量查询
     *
     * @param client
     * @param index
     * @param type
     * @param data
     * @param isPretty
     * @return
     */
    public static String mgetData(RestClient client, String index, String type, String data, Boolean isPretty) {
        if (client == null) {
            return null;
        }
        String resultStr;
        Response response;
        NStringEntity entity = new NStringEntity(data, ContentType.APPLICATION_JSON);
        String endpoint = "";
        if (index.length() == 0 && type.length() == 0) {
            endpoint = "/_mget";
        } else if (index.length() != 0 && type.length() == 0) {
            endpoint = "/" + index + "/_mget";
        } else if (index.length() != 0 && type.length() != 0) {
            endpoint = "/" + index + "/" + type + "/_mget";
        }
        endpoint = isPretty ? (endpoint + "?pretty") : endpoint;

        Request request = new Request("GET", endpoint);
        request.setEntity(entity);
        try {
            response = client.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                LOG.error("mget sucessful!");
                resultStr = EntityUtils.toString(response.getEntity());
            } else {
                LOG.error("mget error");
                resultStr = null;
            }
        } catch (IOException e) {
            LOG.error("" + e);
            resultStr = null;
        }
        return resultStr;
    }

    /**
     * 局部更新数据
     *
     * @param index
     * @param type
     * @param id
     * @return
     */
    public static Boolean updateData(RestClient client, String index, String type, String id, String data) {
        if (client == null) {
            return false;
        }
        Response response;
        Boolean resultBoolean;
        NStringEntity entity = new NStringEntity(data, ContentType.APPLICATION_JSON);
        Request request = new Request("POST", "/" + index + "/" + type + "/" + id + "/_update");
        request.setEntity(entity);

        try {
            response = client.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                LOG.info("update successful!");
                resultBoolean = true;
            } else {
                LOG.error("update error!");
                resultBoolean = false;
            }
        } catch (IOException e) {
            LOG.error("" + e);
            resultBoolean = false;
        }

        return resultBoolean;
    }

    /**
     * 查询指定索引、type 的指定document
     *
     * @param index
     * @param type
     * @param id
     * @return
     */
    public static String queryIdData(String index, String type, String id) {
        Response response;
        String resultStr = "";
        if (restClient == null) {
            restClient = getConnect();
        }
        //定义请求对象
        Request request = new Request("GET", "/" + index + "/" + type + "/" + id);
        try {
            response = restClient.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                LOG.info("GET successful!");
                response.getEntity();
                resultStr = EntityUtils.toString(response.getEntity());
            } else {
                LOG.error("ERROR not get!");
            }
        } catch (IOException e) {
            e.printStackTrace();
            LOG.error("ioexception " + e);
        }
        return resultStr;
    }

    /**
     * 查询索引所有数据
     *
     * @param index
     * @return
     */
    public static String queryIndexAll(String index) {
        if (restClient == null) {
            restClient = getConnect();
        }
        Response response;
        String resultstr = "";
        Request request = new Request("GET", "/" + index + "/_search");
        try {
            response = restClient.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                LOG.info("Index all successful!");
                resultstr = EntityUtils.toString(response.getEntity());
            } else {
                LOG.error("Not get");
            }
        } catch (IOException e) {
            LOG.error("E:" + e);

        }
        return resultstr;
    }

    /**
     * 按照指定查询
     *
     * @param index
     * @param query
     * @return
     */
    public static String queryDSL(String index, String query, Boolean isPretty) {
        if (restClient == null) {
            restClient = getConnect();
        }
        Response response;
        String resultStr = "";
        String endpoint = isPretty ? ("/" + index + "/_search?pretty") : ("/" + index + "/_search");
        Request request = new Request("GET", endpoint);
        NStringEntity nStringEntity = new NStringEntity(query, ContentType.APPLICATION_JSON);
        request.setEntity(nStringEntity);
        try {
            response = restClient.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                LOG.info("query successful!");
                resultStr = EntityUtils.toString(response.getEntity());
            } else {
                LOG.error("query error");
            }
        } catch (IOException e) {
            LOG.error(e.toString());
        }
        return resultStr;
    }


    /**
     * 对未指定index，type进行批量操作
     *
     * @param client
     * @param data
     * @param isPretty
     * @return
     */
    public static Boolean bulk(RestClient client, String data, Boolean isPretty) {
        return bulk(client, "", data, isPretty);
    }

    /**
     * 对指定index，未指定type进行操作
     *
     * @param client
     * @param index
     * @param data
     * @param isPretty
     * @return
     */
    public static Boolean bulk(RestClient client, String index, String data, Boolean isPretty) {
        return bulk(client, index, "", data, isPretty);
    }

    /**
     * 对指定index，type进行批量操作
     *
     * @param client
     * @param index
     * @param type
     * @param data
     * @param isPretty
     * @return
     */
    public static Boolean bulk(RestClient client, String index, String type, String data, Boolean isPretty) {
        if (client == null) {
            return false;
        }
        Boolean resultBoolen;
        Response response;
        String endpoint = "";
        if (index.length() == 0 && type.length() == 0) {
            endpoint = "/_bulk";
        } else if (index.length() != 0 && type.length() == 0) {
            endpoint = "/" + index + "/_bulk";
        } else if (index.length() != 0 && type.length() != 0) {
            endpoint = "/" + index + "/" + type + "/_bulk";
        }
        endpoint = isPretty ? (endpoint + "?pretty") : endpoint;
        NStringEntity entity = new NStringEntity(data, ContentType.APPLICATION_JSON);
        Request request = new Request("POST", endpoint);
        request.setEntity(entity);
        try {
            response = client.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK ||
                    response.getStatusLine().getStatusCode() == HttpStatus.SC_CREATED
            ) {
                LOG.info("bulk successful!");
                resultBoolen = true;
            } else {
                LOG.error("bulk error");
                resultBoolen = false;
            }
        } catch (IOException e) {
            LOG.error("" + e);
            resultBoolen = false;
        }
        return resultBoolen;
    }

    /**
     * 使用query string方式搜索
     *
     * @param client
     * @param data
     * @param isPretty
     * @return
     */
    public static String queryString(RestClient client, String data, Boolean isPretty) {
        if (client == null) {
            return null;
        }
        String resultStr;
        Response response;
        String endpoint = isPretty ? (data + "&pretty") : data;
        Request request = new Request("GET", endpoint);
        try {
            response = client.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                LOG.info("query successful!");
                resultStr = EntityUtils.toString(response.getEntity());
            } else {
                LOG.error("query error");
                resultStr = null;
            }
        } catch (IOException e) {
            LOG.error("" + e);
            resultStr = null;
        }
        return resultStr;
    }

    /**
     * 获取指定index，type的mapping
     *
     * @param client
     * @param index
     * @param type
     * @param isPretty
     * @return
     */
    public static String getMapping(RestClient client, String index, String type, Boolean isPretty) {
        if (client == null) {
            return null;
        }
        String resultStr = null;
        Response response;
        String pretty = isPretty ? "?pretty" : "";
        Request request = new Request("GET", "/" + index + "/_mapping" + "/" + type + pretty);
        try {
            response = client.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                resultStr = EntityUtils.toString(response.getEntity());
                LOG.info("getmapping successful!");
            } else {
                LOG.error("getmapping error");
            }
        } catch (IOException e) {
            LOG.error("e:" + e);
        }
        return resultStr;
    }

    /**
     * 分词器测试
     *
     * @param client
     * @param data
     * @return
     */
    public static String analyze(RestClient client, String data, Boolean isPretty) {
        if (client == null) {
            return null;
        }
        String resultStr = null;
        Response response;
        NStringEntity entity = new NStringEntity(data, ContentType.APPLICATION_JSON);
        String pretty = isPretty ? "?pretty" : "";
        Request request = new Request("GET", "/_analyze" + pretty);
        request.setEntity(entity);
        try {
            response = client.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                resultStr = EntityUtils.toString(response.getEntity());
                LOG.info("analyze successful!");
            } else {
                LOG.error("analyze error!");
            }
        } catch (IOException e) {
            LOG.error("E:" + e);
        }
        return resultStr;
    }

    /**
     * 创建index，自定义mapping
     *
     * @param client
     * @param index
     * @param data
     * @param isPretty
     * @return
     */
    public static Boolean createIndexMapping(RestClient client, String index, String data, Boolean isPretty) {
        if (client == null) {
            return null;
        }
        Boolean resultBoolean = false;
        Response response;
        NStringEntity entity = new NStringEntity(data, ContentType.APPLICATION_JSON);
        String endpoint = isPretty ? ("/" + index + "?pretty") : index;
        Request request = new Request("PUT", endpoint);
        request.setEntity(entity);
        try {
            response = client.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                resultBoolean = true;
                LOG.info("create index and mapping successful!");
            } else {
                LOG.error("create index and mapping error!");
            }
        } catch (IOException e) {
            LOG.error("E:" + e);
        }
        return resultBoolean;
    }

    /**
     * 测试index 某个字段分词情况
     *
     * @param client
     * @param index
     * @param data
     * @param isPretty
     * @return
     */
    public static String indexAnalyze(RestClient client, String index, String data, Boolean isPretty) {
        if (client == null) {
            return null;
        }
        String resultStr = null;
        Response response;
        NStringEntity entity = new NStringEntity(data, ContentType.APPLICATION_JSON);
        String endpoint = isPretty ? ("/" + index + "/_analyze" + "?pretty") : ("/" + index + "/_analyze");
        Request request = new Request("GET", endpoint);
        request.setEntity(entity);
        try {
            response = client.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                resultStr = EntityUtils.toString(response.getEntity());
                LOG.info("successful!");
            } else {
                LOG.error("error");
            }
        } catch (IOException e) {
            LOG.error("E:" + e);
        }
        return resultStr;
    }

    /**
     * 验证查询语句是否合法
     *
     * @param client
     * @param index
     * @param type
     * @param data
     * @param isPretty
     * @return
     */
    public static String validateQuery(RestClient client, String index, String type, String data, Boolean isPretty) {
        if (client == null) {
            return null;
        }
        String resultStr = null;
        Response response;
        NStringEntity entity = new NStringEntity(data, ContentType.APPLICATION_JSON);
        String endpoint = isPretty ? ("/" + index + "/" + type + "/_validate/query?explain&pretty") : ("/" + index + "/" + type + "/_validate/query?explain");
        Request request = new Request("GET", endpoint);
        request.setEntity(entity);
        try {
            response = client.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                resultStr = EntityUtils.toString(response.getEntity());
                LOG.info("validate successful!");
            } else {
                LOG.error("validate error!");
            }
        } catch (IOException e) {
            LOG.error("e:" + e);
        }
        return resultStr;
    }

    /**
     * 滚动查询
     *
     * @param client
     * @param index
     * @param type
     * @param data
     * @param isPretty
     * @return
     */
    public static String scrollQuery(RestClient client, String index, String type, String window, String data, Boolean isPretty) {
        if (client == null) {
            return null;
        }
        String resultStr = null;
        Response response;
        NStringEntity entity = new NStringEntity(data, ContentType.APPLICATION_JSON);
        String endpoint = "";
        if (index.length() == 0 && type.length() == 0) {
            endpoint = isPretty ? ("/_search/scroll?pretty") : ("/_search/scroll");
        } else {
            endpoint = isPretty ? ("/" + index + "/" + type + "/_search?scroll=" + window + "&pretty") : ("/" + index + "/" + type + "/_search=" + window);
        }
        Request request = new Request("GET", endpoint);
        request.setEntity(entity);
        try {
            response = client.performRequest(request);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                LOG.info("scroll successful!");
                resultStr = EntityUtils.toString(response.getEntity());
            } else {
                LOG.error("scroll error");
            }
        } catch (IOException e) {
            LOG.error("e" + e);
        }
        return resultStr;
    }

    /**
     * 关闭连接
     */
    public static void close() {
        if (restClient != null) {
            try {
                restClient.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}