#!/usr/bin/env bash
class_name=$1
deploy_mode=$2
num_executors=$3
executor_cores=$4
executor_memory=$5
queue=$6
jar_name=$7
env=$8

spark-submit \
--class $class_name \
--master yarn \
--deploy-mode $deploy_mode \
--driver-memory 2g \
--num-executors $num_executors \
--executor-cores $executor_cores \
--executor-memory $executor_memory \
--queue $queue \
$jar_name \
$env