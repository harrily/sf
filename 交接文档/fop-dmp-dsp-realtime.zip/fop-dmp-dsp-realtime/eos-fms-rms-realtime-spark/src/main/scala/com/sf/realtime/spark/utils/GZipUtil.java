package com.sf.realtime.spark.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class GZipUtil {

    /**
     * 使用gzip进行压缩
     */
    public static String compress(String primStr) {
        if (primStr == null || primStr.length() == 0) {
            return primStr;
        }
        byte[] bytes = compress(primStr.getBytes());
        return new sun.misc.BASE64Encoder().encode(bytes);
    }

    public static byte[] compress(byte[] data) {
        if (data == null) {
            return data;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        GZIPOutputStream gzip = null;
        try {
            gzip = new GZIPOutputStream(out);
            gzip.write(data);
        } catch (IOException e) {
            //log.error("字符串压缩失败", e);
        } finally {
            if (gzip != null) {
                try {
                    gzip.close();
                } catch (IOException e) {
                    //log.error("字符串压缩失败", e);
                }
            }
        }
        return out.toByteArray();
    }

    /**
     * 使用gzip进行解压缩
     */
    public static String uncompress(String compressedStr) {
        if (compressedStr == null) {
            return null;
        }
        byte[] uncompress = null;
        try {
            byte[] compressed = new sun.misc.BASE64Decoder().decodeBuffer(compressedStr);
            uncompress = uncompress(compressed);
        } catch (Exception e) {
            //log.error("字符串解压失败", e);
        }
        if (uncompress == null) {
            return null;
        }
        return new String(uncompress);
    }

    public static byte[] uncompress(byte[] data) {
        if (data == null) {
            return null;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayInputStream in = null;
        GZIPInputStream ginzip = null;
        byte[] decompressed = null;
        try {
            in = new ByteArrayInputStream(data);
            ginzip = new GZIPInputStream(in);

            byte[] buffer = new byte[1024];
            int offset = -1;
            while ((offset = ginzip.read(buffer)) != -1) {
                out.write(buffer, 0, offset);
            }
            decompressed = out.toByteArray();
        } catch (IOException e) {
            //log.error("字符串解压失败", e);
        } finally {
            if (ginzip != null) {
                try {
                    ginzip.close();
                } catch (IOException e) {
                    //log.error("字符串解压失败", e);
                }
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    //log.error("字符串解压失败", e);
                }
            }
            try {
                out.close();
            } catch (IOException e) {
                //log.error("字符串解压失败", e);
            }
        }
        return decompressed;
    }

    public static void main(String[] args) {
        String str = "[{\"checkTime\":1600087584599,\"createTime\":1600135112270,\"deviceCode\":\"814C65F2-F546-4B0B-B560-A17A072F1FF7\",\"gpsType\":1,\"latitude\":\"22.531654\",\"longitude\":\"113.94613\",\"speed\":0.0,\"systemSource\":\"IOV\",\"vehicleSerial\":\"赣F33301\"},{\"checkTime\":1600087644600,\"createTime\":1600135113012,\"deviceCode\":\"814C65F2-F546-4B0B-B560-A17A072F1FF7\",\"gpsType\":1,\"latitude\":\"22.531654\",\"longitude\":\"113.94614\",\"speed\":0.0,\"systemSource\":\"IOV\",\"vehicleSerial\":\"赣F33301\"}]";
        //log.info("原字符串：" + str);
        //log.info("原长度：" + str.length());
        String compress = GZipUtil.compress(str);
        //log.info("压缩后字符串：" + compress);
        //log.info("压缩后字符串长度：" + compress.length());

        String string = GZipUtil.uncompress(compress);
//        string = GZipUtil.uncompress("H4sIAAAAAAAAAO3MMQrCMBSA4asLFUXUFkRQtMUpuAgRKVppgpd5eUmmXsGAl3D412/4kvnkyofGymjE1+Luk9uIX4S9jeubDNtU+Z/nbqdHE0/zInnZTO5cJLx7PTy1vRSPVxt7K0Otj5W+ZomZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZn5j+cvpcwGv0wsAAA=");
        //log.info("解压缩后字符串：" + string);
//        log.info("解压缩后字符串长度：" + string.length());
    }
}
