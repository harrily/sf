package com.sf.realtime.spark.context

import com.sf.realtime.spark.context.Context.conf
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

object EsContext {
  val conf = new SparkConf().setAppName("RefreshCargoInfoTask")
  conf.set("es.nodes","10.117.106.60,10.117.106.61,10.117.106.62")                   //生产环境
  conf.set("es.port","9200")
  conf.set("es.mapping.date.rich","false")
  conf.set("es.nodes.wan.only","true")
  conf.set("es.internal.es.version","5.4.1")
  conf.set("es.internal.es.cluster.name","bdp-eos-fms-rms-ssd")
  conf.set("spark.sql.shuffle.partitions", "200")
  conf.set("spark.default.parallelism", "200")
  def getContext(enableHive:Boolean):SparkSession={
    if(enableHive){
      SparkSession.builder()
        .config(conf)
        //.master("local[2]")
        .enableHiveSupport()
        .getOrCreate()
    }else{
      SparkSession.builder()
        .config(conf)
        //.master("local[2]")
        .getOrCreate()
    }
  }
}
