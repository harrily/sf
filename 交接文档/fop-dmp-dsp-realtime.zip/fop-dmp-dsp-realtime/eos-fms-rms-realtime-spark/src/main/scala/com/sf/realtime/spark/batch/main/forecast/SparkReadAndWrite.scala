package com.sf.realtime.spark.batch.main.forecast

import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.Result
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapreduce.{TableInputFormat, TableOutputFormat}
import org.apache.hadoop.mapred.JobConf
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.util.Properties

/**
 * @Author 01419728
 * @Date 2022/4/19 22:14
 */
object SparkReadAndWrite {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("")
    //设置优雅关闭
    conf.set("spark.streaming.stopGracefullyOnShutdown","true")
    //开启反压
    conf.set("spark.streaming.backpressure.enabled","true")
    //启用反压机制时每个接收器接收第一批数据的初始最大速率
    conf.set("spark.streaming.backpressure.initialRate", "5000")
    //设定对目标topic每个partition每秒钟拉取的数据条数
    conf.set("spark.streaming.kafka.maxRatePerPartition", "5000")
    //提高shuffle并行度
    conf.set("spark.sql.shuffle.partitions", "500")
    //RDD任务的默认并行度
    conf.set("spark.default.parallelism", "500")
    //设置字段长度最大值
    conf.set("spark.debug.maxToStringFields", "100")

//
//        SparkSession.builder()
//          .config(conf)
//          //.master("local[2]")
//          .enableHiveSupport() //enableHiveSupport 操作hive表
//          .getOrCreate()

    val spark = SparkSession.builder().master("local[2]").getOrCreate()
    val sc = spark.sparkContext
    val prop =new Properties()

    val mysqlUrl="jdbc:mysql://dmpdsp-tilb.db.sfcloud.local:3306/dmpdsp?rewriteBatchedStatements=true"
    prop.setProperty("user","fmsrms")
    prop.setProperty("password","fms_rms#12")

    val predicates = Array("id<10", "id>=15 and id<20", "id>=20 and id<=25")
    spark.sqlContext.read.option("driver", "com.mysql.cj.jdbc.Driver")
      .jdbc(mysqlUrl, "ads_fin_cargo_forecast_flow_sum_di", predicates, prop)
      .show()

    spark.sqlContext.read.option("driver", "com.mysql.cj.jdbc.Driver")
      .jdbc(mysqlUrl, "ads_fin_cargo_forecast_flow_sum_di","id",50,100,4,prop)
      .show()

//    //读取HBase
//    val hbaseConf = HBaseConfiguration.create()
//    hbaseConf.set("hbase.zookeeper.quorum","CNSZ22PL0138,CNSZ22PL0139,CNSZ22PL0140,CNSZ22PL0141,CNSZ22PL0142")  //设置zooKeeper集群地址，也可以通过将hbase-site.xml导入classpath，但是建议在程序里这样设置
//    hbaseConf.set("hbase.zookeeper.property.clientPort", "2181")       //设置zookeeper连接端口，默认2181
//    hbaseConf.set(TableOutputFormat.OUTPUT_TABLE, "tablename")
//    val resultRdd: RDD[(ImmutableBytesWritable, Result)] = sc
//      .newAPIHadoopRDD(hbaseConf, classOf[TableInputFormat], classOf[ImmutableBytesWritable], classOf[Result])
//    resultRdd.collect()
////    val jobConf = new JobConf(hbaseConf)
////    jobConf.setOutputFormat(classOf[TableOutputFormat])
////
////    hbaseConf.set(TableInputFormat.INPUT_TABLE,"")
//    val jobConf = new JobConf(sc.hadoopConfiguration)
//    jobConf.set("","")
  }
}
