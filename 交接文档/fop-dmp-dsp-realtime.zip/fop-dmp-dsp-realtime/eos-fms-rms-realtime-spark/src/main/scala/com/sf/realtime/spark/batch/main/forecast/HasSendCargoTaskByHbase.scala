package com.sf.realtime.spark.batch.main.forecast

import com.sf.realtime.common.utils.DateUtil
import com.sf.realtime.hbase.HbaseUtil
import com.sf.realtime.hbase.common.ColumnType
import com.sf.realtime.spark.context.Context
import com.sf.realtime.spark.sql.DeptInfo
import org.apache.hadoop.hbase.CellUtil
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

import java.util
import scala.collection.JavaConverters._
import scala.collection.mutable.ArrayBuffer

object HasSendCargoTaskByHbase {
  def main(args: Array[String]): Unit = {
    val spark = Context.getContext(true)
    import spark.implicits._
    val allArrive =  spark.sqlContext.sql(""" SELECT require_id ,car_no,translevel,src_zone_code,dest_zone_code,arrive_time,send_time FROM tmp_ordi_predict.tmp_all_arrive_before_hbase_248838 """.stripMargin)
    allArrive.createOrReplaceTempView("allArrive")
    println("===>1")
    val requireCarNoDetail = allArrive.rdd.repartition(3000).filter(r=>r.getAs[String]("car_no")!= null && !r.getAs[String]("car_no").equals("") ).mapPartitions(f=>{
      val hbase = HbaseUtil.getInstance()
      f.map(r=>{
        val requireId = r.getAs[String]("require_id")
        val translevel = r.getAs[Integer]("translevel")
        val carNo = r.getAs[String]("car_no")
        val srcZoneCode = r.getAs[String]("src_zone_code")
        val destZoneCode = r.getAs[String]("dest_zone_code")
        val arriveTime = r.getAs[Long]("arrive_time")
        val sendTime = r.getAs[Long]("send_time")
        val rowKey = carNo.reverse
        val rtContrnRes = hbase.getRow("rt_container_waybill_relation", Bytes.toBytes(rowKey))
        var listRow = new ArrayBuffer[Row]()
        if (rtContrnRes != null && !rtContrnRes.isEmpty) {
          val cells = rtContrnRes.listCells().asScala
          val getList = new util.ArrayList[String]()
          var columns = new util.HashMap[String,ColumnType]()
          for(cell <- cells){
            val waybillNo = Bytes.toString(CellUtil.cloneQualifier(cell))
            //val get = new Get(Bytes.toBytes(waybillNo.reverse))
            //get.addColumn(Bytes.toBytes("baseInfo"), Bytes.toBytes("packageMeterageWeightQty"))
            getList.add(waybillNo)
            columns.put("packageMeterageWeightQty",ColumnType.DOUBLE)
          }
          //val result = hbase.getList("wb_info_data",getList.toList.asJava)
          val hrs = hbase.getListSpecialForWbInfo(getList, columns);
          println("===>hbase_inner")
          for(waybillResult <- hrs.entrySet().asScala; if hrs!=null && !hrs.isEmpty) {
            var weight = 0D
            var ticket = 0L
            var waybillNo = ""
            if(waybillResult !=null){
              waybillNo = waybillResult.getKey
              val wCells = waybillResult.getValue
              for(wCell <- wCells.entrySet().asScala) {
                weight = wCell.getValue.asInstanceOf[Double]
                ticket = 1L
              }
            }
            listRow += Row(requireId,carNo,srcZoneCode,destZoneCode,sendTime,arriveTime,ticket,weight,waybillNo,translevel.toString)
          }
        }
        listRow.toArray
      }).flatMap(r=>r.iterator)
    })
    println("-切换hbase-改造2")
    val structFields = Array(StructField("require_id", StringType, true), StructField("car_no", StringType, true),
      StructField("src_zone_code", StringType, true),StructField("dest_zone_code", StringType, true),StructField("send_time", LongType, true),StructField("arrive_time", LongType, true),StructField("tickets", LongType, true),StructField("weight", DoubleType, true),StructField("waybill_no", StringType, true),StructField("translevel", StringType, true))
    val structType = StructType(structFields)
    val requireCarNoDetailDf = spark.createDataFrame(requireCarNoDetail, structType).dropDuplicates("waybill_no","dest_zone_code")

    /*
    val resultPre = requireCarNoDetailDf.groupBy("require_id","car_no","translevel","src_zone_code","dest_zone_code","send_time","arrive_time").agg(sum("tickets").as("tickets"),sum("weight").as("weight"))
    resultPre.createOrReplaceTempView("result_pre")
    println("===>3")
    // 结果写入临时表
        spark.sqlContext.sql("""drop table if exists tmp_ordi_predict.tmp_all_arrive_behind_hbase_2_248838;""")
        spark.sqlContext.sql(
          """create table tmp_ordi_predict.tmp_all_arrive_behind_hbase_2_248838
            |stored as parquet as
            | select require_id,car_no,src_zone_code,dest_zone_code,send_time,arrive_time,tickets,weight,translevel
            | from result_pre""".stripMargin)
*/
        requireCarNoDetailDf.createOrReplaceTempView("requireCarNoDetailDf")

        spark.sqlContext.sql("""drop table if exists tmp_ordi_predict.tmp_all_arrive_behind_hbase_248838;""")
    spark.sqlContext.sql(
      """create table tmp_ordi_predict.tmp_all_arrive_behind_hbase_248838
        |stored as parquet as
        | select require_id,car_no,src_zone_code,dest_zone_code,send_time,arrive_time,tickets,weight,waybill_no,translevel
        | from requireCarNoDetailDf""".stripMargin)
  }

}
