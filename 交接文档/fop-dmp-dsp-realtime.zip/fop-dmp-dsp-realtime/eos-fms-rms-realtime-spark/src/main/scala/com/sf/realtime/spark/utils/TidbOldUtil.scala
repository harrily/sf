package com.sf.realtime.spark.utils

import com.sf.realtime.common.config.Config
import com.sf.realtime.common.utils.DateUtil
import org.apache.spark.sql.{DataFrame, SQLContext, SaveMode}

import java.util.{Date, Properties}

object TidbOldUtil {
  val config = Config.getConfig
  val jdbcUrl = config.getString("tidb.old.jdbc.url")
  val user = config.getString("tidb.old.user")
  val passwd = config.getString("tidb.old.passwd")

  val prop =new Properties()
  prop.setProperty("user",user)
  prop.setProperty("password",passwd)

  def read(tableName:String,sqlContext:SQLContext,predicates:Array[String]):DataFrame={
    val df = sqlContext.read.option("driver", "com.mysql.cj.jdbc.Driver")
      .jdbc(jdbcUrl, tableName, predicates, prop)
    df
  }

  def read(tableName:String,sqlContext:SQLContext):DataFrame={
    val df = sqlContext.read.option("driver", "com.mysql.cj.jdbc.Driver")
      .jdbc(jdbcUrl, tableName, prop)
    df
  }

  def write(tableName:String,data:DataFrame):Unit={
    write(tableName,data,SaveMode.Append)
  }

  def cleanAndInsert(tableName:String, data:DataFrame):Unit={
    val now = new Date()
    val currenthours = now.getHours
    if(currenthours==1)
      deleteLastData()
    write(tableName,data,SaveMode.Append)
  }

  def deleteLastData():Unit={
    val conn = Mysql2Util.conn()
    val st   = conn.createStatement()
    val sql  = "DELETE FROM fmsrms.t_monitor_sx_site_delivery WHERE calculateTime < \""+DateUtil.getCurrentStartTimestamp(0)+"\""
    st.executeUpdate(sql)
    if(st!=null){
      st.close()
    }
  }

  def write(tableName:String,data:DataFrame,mode:SaveMode) = mode match {
    case SaveMode.Overwrite =>
      data.write.option("driver", "com.mysql.cj.jdbc.Driver")
        .option("isolationLevel", "NONE")
        .option("truncate", true)
        .option("batchsize",50000)
        .mode(mode)
        .jdbc(jdbcUrl, tableName, prop)
    case _ =>
      data.write.option("driver", "com.mysql.cj.jdbc.Driver")
        .option("isolationLevel", "NONE")
        .option("batchsize",10000)
        .mode(mode)
        .jdbc(jdbcUrl, tableName, prop)
  }
}
