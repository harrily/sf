package com.sf.realtime.spark.utils

import com.sf.realtime.common.config.Config

import java.sql.{Connection, DriverManager}

object Mysql2Util {
  private var connection: Connection = _
  private val driver = "com.mysql.cj.jdbc.Driver"
  private val url = Config.getConfig.getString("mysql.jdbc.url")
  private val username = Config.getConfig.getString("mysql.user")
  private val password = Config.getConfig.getString("mysql.passwd")

  /**
    * 创建mysql连接
    *
    * @return
    */
  def conn(): Connection = {
    if (connection == null) {
      Class.forName(this.driver)
      connection = DriverManager.getConnection(this.url, this.username, this.password)
    }
    connection
  }

  def getConn(): Connection = {
      Class.forName(this.driver)
      connection = DriverManager.getConnection(this.url, this.username, this.password)
      connection
  }
  
}