package com.sf.realtime.spark.utils

import com.sf.realtime.common.config.Config
import org.apache.spark.sql.{DataFrame, SQLContext, SaveMode}

import java.sql.{Connection, DriverManager}
import java.util.Properties

object DatamapUtil {
  private var connection: Connection = _
  private val driver = "com.mysql.cj.jdbc.Driver"
  private val url = Config.getConfig.getString("datamap.jdbc.url")
  private val username = Config.getConfig.getString("datamap.user")
  private val password = Config.getConfig.getString("datamap.passwd")

  val prop =new Properties()
  prop.setProperty("user",username)
  prop.setProperty("password",password)

  /**
   * 创建mysql连接
   *
   * @return
   */
  def conn(): Connection = {
    if (connection == null) {
      Class.forName(this.driver)
      connection = DriverManager.getConnection(this.url, this.username, this.password)
    }
    connection
  }

  def getConn(): Connection = {
    Class.forName(this.driver)
    connection = DriverManager.getConnection(this.url, this.username, this.password)
    connection
  }


  def read(tableName:String,sqlContext:SQLContext,predicates:Array[String]):DataFrame={
    val df = sqlContext.read.option("driver", "com.mysql.cj.jdbc.Driver")
      .jdbc(url, tableName, predicates, prop)
    df
  }

  def read(tableName:String,sqlContext:SQLContext):DataFrame={
    val df = sqlContext.read.option("driver", "com.mysql.cj.jdbc.Driver")
      .jdbc(url, tableName, prop)
    df
  }

  def write(tableName:String,data:DataFrame):Unit={
    write(tableName,data,SaveMode.Append)
  }

  def write(tableName:String,data:DataFrame,mode:SaveMode) = mode match {
    case SaveMode.Overwrite =>
      data.write.option("driver", "com.mysql.cj.jdbc.Driver")
        .option("isolationLevel", "NONE")
        .option("truncate", true)
        .option("batchsize",50000)
        .mode(mode)
        .jdbc(url, tableName, prop)
    case _ =>
      data.write.option("driver", "com.mysql.cj.jdbc.Driver")
        .option("isolationLevel", "NONE")
        .option("batchsize",10000)
        .mode(mode)
        .jdbc(url, tableName, prop)
  }
}
