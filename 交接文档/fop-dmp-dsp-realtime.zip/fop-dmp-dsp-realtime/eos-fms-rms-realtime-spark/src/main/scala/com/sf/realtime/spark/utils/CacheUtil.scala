package com.sf.realtime.spark.utils

import java.sql.Timestamp

import com.sf.realtime.spark.batch.sql.MysqlConnect

object CacheUtil {
  def updateCacheTable(sqlId:String,updateTime:String): Unit = {
    val qSql = "select * from hr_hivedata_update_flag where table_name ='"+sqlId+"'"
    val uSql = "update hr_hivedata_update_flag set append_time = '"+updateTime+"' where table_name = '"+sqlId+"'"
    val iSql = "insert into hr_hivedata_update_flag(table_name,append_time) values('"+sqlId+"','"+updateTime+"')"
    val conn = Mysql2Util.conn()
    val st = conn.createStatement()
    val rs = st.executeQuery(qSql)
    if(rs.next()){
      st.executeUpdate(uSql)
      println("更新缓存刷新时间成功:"+uSql)
    }else{
      st.executeUpdate(iSql)
      println("更新缓存刷新时间成功:"+iSql)
    }
  }

  def updateCacheTableS(sqlId:String,updateTime:String): Unit = {
    val uSql = "update hr_hivedata_update_flag set append_time = '"+updateTime+"' where table_name in ('pickup_send_quality_result_growth_rate','pickup_send_quality_urge_pre','pickup_send_quality_urge_pre_area','pickup_send_quality_result')"
    val conn = Mysql2Util.conn()
    val st = conn.createStatement()
    st.executeUpdate(uSql)
    println("更新缓存刷新时间成功:"+uSql)
  }

  def updateCacheTableS2(sqlId:String,updateTime:String): Unit = {
    val uSql = "update hr_hivedata_update_flag set append_time = '"+updateTime+"'"
    val conn = Mysql2Util.conn()
    val st = conn.createStatement()
    st.executeUpdate(uSql)
    println("更新缓存刷新时间成功:"+uSql)
  }


  def updateTMonitorDetailData(tableName:String, updateTime:Timestamp, startOrEnd:Integer): Unit = {
    var uSql=""
    if(startOrEnd == 1){
      uSql = "update t_monitor_detail_data_process set statues = 1,start_time = '"+updateTime+"',insertTime = current_timestamp() where table_name = '"+tableName+"'"
    }else if(startOrEnd == 2){
      uSql = "update t_monitor_detail_data_process set statues = 2,end_time = '"+updateTime+"',insertTime = current_timestamp() where table_name = '"+tableName+"'"
    }
    val conn = MysqlConnect.getConn()
    val st = conn.createStatement()
    st.executeUpdate(uSql)
    println("更新缓存刷新时间成功:"+uSql)
  }

  def insertTMonitorDataRows(tableName:String, updateTime:Timestamp, rows:Long): Unit = {
    val sql = """insert into t_monitor_detail_data_row values('"""+tableName+"""',"""+rows+""",'"""+updateTime+"""')"""
    val conn = MysqlConnect.getConn()
    val st = conn.createStatement()
    st.setQueryTimeout(3600)
    st.executeUpdate(sql)
    println("更新数据行数监控表成功:"+sql)
  }
}