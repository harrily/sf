package com.sf.realtime.spark.utils

import scalaj.http._

object HttpUtil {
  def post(url:String,data:String):Unit={
    val code = Http(url).postData(data).header("content-type", "application/json").asString.code
    println("http post send code:"+code)
  }
}