package com.sf.realtime.spark.batch.main.forecast

import com.alibaba.fastjson.JSON
import com.sf.realtime.common.utils.DateUtil
import com.sf.realtime.hbase.HbaseUtil
import com.sf.realtime.hbase.common.ColumnType
import com.sf.realtime.spark.context.Context
import com.sf.realtime.spark.sql.{CarInfo, DeptInfo}
import com.sf.realtime.spark.utils.{CacheUtil, KgMysqlUtil, TidbUtil}
import org.apache.commons.lang.StringUtils
import org.apache.hadoop.hbase.CellUtil
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.row_number
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Row, SaveMode}

import java.sql.Timestamp
import java.util
import scala.collection.JavaConverters._
import scala.collection.mutable.ArrayBuffer

object InRoadCargoTaskByHbase {
  def main(args: Array[String]): Unit = {
    val spark = Context.getContext(true)
    // 读取上游产生的数据，关联hbase，生成重量，票量
    // 保持
    val kyAllCarNos = spark.sqlContext.sql(""" select requireId,carNo,translevel,carStatus,srcZoneCode,preArriveZoneCode,preArriveTm from tmp_ordi_predict.tmp_ky_all_car_nos_before_hbase """)
    val f1 = kyAllCarNos.rdd.mapPartitions(f=>{
      val hbase = HbaseUtil.getInstance()
      f.map(r=>{
        val requireId = r.getAs[String]("requireId")
        val carNo = r.getAs[String]("carNo")
        val translevel = r.getAs[Integer]("translevel")
        val carStatus = r.getAs[Integer]("carStatus")
        val srcZoneCode = r.getAs[String]("srcZoneCode")
        val preArriveZoneCode = r.getAs[String]("preArriveZoneCode")
        val preArriveTm = r.getAs[Long]("preArriveTm")
        val rowKey = r.getAs[String]("carNo").reverse
        val rtContrnRes = hbase.getRow("rt_container_waybill_relation", Bytes.toBytes(rowKey))
        var listRow = new ArrayBuffer[Row]()
        if (rtContrnRes != null && !rtContrnRes.isEmpty) {
          val cells = rtContrnRes.listCells().asScala
          val getList = new util.ArrayList[String]()
          var columns = new util.HashMap[String,ColumnType]()
          for(cell <- cells){
            val waybillNo = Bytes.toString(CellUtil.cloneQualifier(cell))
            val waybillJson = JSON.parseObject(Bytes.toString(CellUtil.cloneValue(cell)))
            val jobType = waybillJson.getString("jobType")
            if (StringUtils.isNotEmpty(waybillNo)&&jobType.equals("30") && waybillJson.getInteger("isDeleted") == 0){
              //val get = new Get(Bytes.toBytes(waybillNo.reverse))
              //get.addColumn(Bytes.toBytes("baseInfo"), Bytes.toBytes("packageMeterageWeightQty"))
              getList.add(waybillNo)
              columns.put("packageMeterageWeightQty",ColumnType.DOUBLE)
            }
          }
          //val result = hbase.getList("wb_info_data",getList.toList.asJava)
          val hrs = hbase.getListSpecialForWbInfo(getList, columns);
          for(waybillResult <- hrs.entrySet().asScala; if hrs!=null && !hrs.isEmpty) {
            var weight = 0D
            var ticket = 0L
            var waybillNo = ""
            if(waybillResult !=null){
              waybillNo = waybillResult.getKey
              val wCells = waybillResult.getValue
              for(wCell <- wCells.entrySet().asScala) {
                weight = wCell.getValue.asInstanceOf[Double]
                if(weight > 1000000D){
                  weight = 1000000D
                }
                ticket = 1L
              }
            }
            listRow += Row(requireId,carNo,translevel,carStatus,srcZoneCode,preArriveTm,preArriveZoneCode,waybillNo,ticket,weight)
          }
        }else{
          listRow += Row(requireId,carNo,translevel,carStatus,srcZoneCode,preArriveTm,preArriveZoneCode,null,0L,0D)
        }
        listRow.toArray
      }).flatMap(r=>r.iterator)
    })
    println("---25")
    val structFields = Array(StructField("requireId", StringType, true), StructField("carNo", StringType, true),
      StructField("transLevel", IntegerType, true),StructField("carStatus", IntegerType, true),
      StructField("srcZoneCode", StringType, true),StructField("preArriveTm", LongType, true),
      StructField("preArriveZoneCode", StringType, true),StructField("waybillNo", StringType, true),
      StructField("tickets", LongType, true),StructField("weight", DoubleType, true))
    println("---26")
    val structType = StructType(structFields)
    println("---27")
    val f1Df = spark.createDataFrame(f1, structType)
    f1Df.createOrReplaceTempView("f1Df")
    // 结果写入临时表
    spark.sqlContext.sql("""drop table if exists tmp_ordi_predict.tmp_ky_all_car_nos_behind_hbase;""")
    spark.sqlContext.sql(
      """create table tmp_ordi_predict.tmp_ky_all_car_nos_behind_hbase
        |stored as parquet as
        | select requireId,carNo,transLevel,carStatus,srcZoneCode,preArriveTm,preArriveZoneCode,waybillNo,tickets,weight
          | from f1Df""".stripMargin)
  }
}
