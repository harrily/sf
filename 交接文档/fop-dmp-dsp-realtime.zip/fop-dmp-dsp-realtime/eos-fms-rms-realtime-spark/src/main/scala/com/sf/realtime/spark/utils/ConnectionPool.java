package com.sf.realtime.spark.utils;



import com.sf.realtime.common.config.Config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.LinkedList;

public class ConnectionPool {
    private static LinkedList<Connection> connectionQueue;
    private static String url = Config.getConfig().getString("tidb.jdbc.url");
    private static String username = Config.getConfig().getString("tidb.user");
    private static String password = Config.getConfig().getString("tidb.passwd");
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        }catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public synchronized static Connection getConnection() {
        try {
            if (connectionQueue == null) {
                connectionQueue = new LinkedList<Connection>();
                for (int i = 0;i < 2;i ++) {
                    Connection conn = DriverManager.getConnection(
                            url,
                            username,
                            password
                    );
                    connectionQueue.push(conn);
                }
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        return connectionQueue.poll();
    }

    public static void returnConnection(Connection conn) {
        connectionQueue.push(conn);
    }
}
