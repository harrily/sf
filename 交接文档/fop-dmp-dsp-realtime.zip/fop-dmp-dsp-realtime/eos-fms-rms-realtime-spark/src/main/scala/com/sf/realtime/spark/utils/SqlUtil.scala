package com.sf.realtime.spark.utils

import com.sf.realtime.common.utils.DateUtil

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}
import scala.collection.mutable.ArrayBuffer

object SqlUtil {
  //设置spark读取mysql表的分区数及分区字段
  def getReadMysqlPartitionByHourTime(startTime:Long, numPartitions:Int, beforeDays:Int):Array[(Long,Long)]={
    val partitionArray = new ArrayBuffer[(Long,Long)]
    val incHour = (24*beforeDays) / numPartitions
    val c = Calendar.getInstance()
    val start1 = startTime
    val startDate = new Date(start1)
    c.setTime(startDate)
    var start = start1
    for(i<- 1 to numPartitions){
      c.add(Calendar.HOUR_OF_DAY, incHour)
      val end = c.getTime.getTime
      partitionArray.+=(start -> end)
      start = end
    }
    partitionArray.toArray
  }

  def getReadMysqlPartitionByHourString(startTime:String, numPartitions:Int, beforeDays:Int):Array[(String,String)]={
    val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val partitionArray = new ArrayBuffer[(String,String)]
    val incHour = (24*beforeDays) / numPartitions
    val c = Calendar.getInstance()
    val start1 = startTime
    val startDate = sdf.parse(start1)
    c.setTime(startDate)
    var start = start1
    for(i<- 1 to numPartitions){
      c.add(Calendar.HOUR_OF_DAY, incHour)
      val end = sdf.format(c.getTime)
      partitionArray.+=(start -> end)
      start = end
    }
    partitionArray.toArray
  }
}
