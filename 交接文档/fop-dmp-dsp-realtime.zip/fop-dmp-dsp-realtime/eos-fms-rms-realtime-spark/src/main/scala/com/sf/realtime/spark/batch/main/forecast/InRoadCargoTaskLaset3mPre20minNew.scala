package com.sf.realtime.spark.batch.main.forecast

import com.sf.realtime.common.utils.DateUtil
import com.sf.realtime.spark.context.Context
import com.sf.realtime.spark.sql.DeptInfo
import com.sf.realtime.spark.utils.KgMysqlUtil
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{count, row_number, sum}

/**
 * 快运场地数据回刷-->回刷过去一年的数据---->货量及票量通过已到达的数据进行join得到
 *
 * 002 只需要回刷未发和在途的数据就可以
 *
 * 按照动态分区的思想,每天写入数据,不着急写入已到达数据
 * 取过去1天的数据, 标记20分钟的标记  --  关联运单及重量之后的数据  写入inc_day中,并标记flag20min
 * @Author 01419728
 * @Date 2022/2/14 13:56
 */
object InRoadCargoTaskLaset3mPre20minNew {

  def main(args: Array[String]): Unit = {


    val spark = Context.getContext(true)
    //todo 155个场地列表
    val transitDf = DeptInfo.getKyNewDeptInfo(spark.sqlContext)
    var countAll = 0L
    transitDf.createOrReplaceTempView("transit_info_tmp")


    val countTime = args(0) //业务时间,也就是每20分钟  统计时间"yyyy-MM-dd HH:mm:ss"
    val endDay = args(1) //月末最后一天  统计时间"20220131"
    val countDate = DateUtil.df2Todf3(countTime) //统计时间"yyyyMMdd"


    val Ago15Day = DateUtil.getLastDayStringdf3(endDay, -15)

    //2.获取车辆信息前48小时车辆任务
    //old
    //val requireTaskDf1 = CarInfo.getVehicleNotSendTaskInfo(spark.sqlContext,DateUtil.getLastHoursTime(24),1).drop("currentOpZoneCode")
    //val requireTaskDf1 = CarInfo.getVehicleNotSendTaskInfo(spark.sqlContext,DateUtil.getLastHoursTime(24),1,true).drop("currentOpZoneCode")
    val requireTaskDf1 = spark.sqlContext.sql("""select
case when idKey = 'null' then null else idKey end as idKey,
case when requireId = 'null' then null else requireId end as requireId,
case when translevel = 'null' then null else cast(translevel as int) end as translevel,
case when carNo = 'null' then null else carNo end as carNo,
case when lineCode = 'null' then null else lineCode end as lineCode,
case when carStatus = 'null' then null else cast(carStatus as int) end as carStatus,
case when lastUpdateTm = 'null' then null else cast(lastUpdateTm as bigint) end as lastUpdateTm,
case when srcZoneCode = 'null' then null else srcZoneCode end as srcZoneCode,
case when srcPlanReachTm = 'null' then null else cast(srcPlanReachTm as bigint) end as srcPlanReachTm,
case when srcPlanDepartTm = 'null' then null else cast(srcPlanDepartTm as bigint) end as srcPlanDepartTm,
case when srcActualDepartTm = 'null' then null else cast(srcActualDepartTm as bigint) end as srcActualDepartTm,
case when srcPreDepartTm = 'null' then null else cast(srcPreDepartTm as bigint) end as srcPreDepartTm,
case when srcPlanArriveTm = 'null' then null else cast(srcPlanArriveTm as bigint) end as srcPlanArriveTm,
case when srcActualArriveTm = 'null' then null else cast(srcActualArriveTm as bigint) end as srcActualArriveTm,
case when srcPreArriveTm = 'null' then null else cast(srcPreArriveTm as bigint) end as srcPreArriveTm,
case when secondZoneCode = 'null' then null else secondZoneCode end as secondZoneCode,
case when secondPlanReachTm = 'null' then null else cast(secondPlanReachTm as bigint) end as secondPlanReachTm,
case when secondPlanDepartTm = 'null' then null else cast(secondPlanDepartTm as bigint) end as secondPlanDepartTm,
case when secondActualDepartTm = 'null' then null else cast(secondActualDepartTm as bigint) end as secondActualDepartTm,
case when secondPreDepartTm = 'null' then null else cast(secondPreDepartTm as bigint) end as secondPreDepartTm,
case when secondPlanArriveTm = 'null' then null else cast(secondPlanArriveTm as bigint) end as secondPlanArriveTm,
case when secondActualArriveTm = 'null' then null else cast(secondActualArriveTm as bigint) end as secondActualArriveTm,
case when secondPreArriveTm = 'null' then null else cast(secondPreArriveTm as bigint) end as secondPreArriveTm,
case when thirdZoneCode = 'null' then null else thirdZoneCode end as thirdZoneCode,
case when thirdPlanReachTm = 'null' then null else cast(thirdPlanReachTm as bigint) end as thirdPlanReachTm,
case when thirdPlanDepartTm = 'null' then null else cast(thirdPlanDepartTm as bigint) end as thirdPlanDepartTm,
case when thirdActualDepartTm = 'null' then null else cast(thirdActualDepartTm as bigint) end as thirdActualDepartTm,
case when thirdPreDepartTm = 'null' then null else cast(thirdPreDepartTm as bigint) end as thirdPreDepartTm,
case when thirdPlanArriveTm = 'null' then null else cast(thirdPlanArriveTm as bigint) end as thirdPlanArriveTm,
case when thirdActualArriveTm = 'null' then null else cast(thirdActualArriveTm as bigint) end as thirdActualArriveTm,
case when thirdPreArriveTm = 'null' then null else cast(thirdPreArriveTm as bigint) end as thirdPreArriveTm,
case when destZoneCode = 'null' then null else destZoneCode end as destZoneCode,
case when destPlanReachTm = 'null' then null else cast(destPlanReachTm as bigint) end as destPlanReachTm,
case when destPlanDepartTm = 'null' then null else cast(destPlanDepartTm as bigint) end as destPlanDepartTm,
case when destActualDepartTm = 'null' then null else cast(destActualDepartTm as bigint) end as destActualDepartTm,
case when destPreDepartTm = 'null' then null else cast(destPreDepartTm as bigint) end as destPreDepartTm,
case when destPlanArriveTm = 'null' then null else cast(destPlanArriveTm as bigint) end as destPlanArriveTm,
case when destActualArriveTm = 'null' then null else cast(destActualArriveTm as bigint) end as destActualArriveTm,
case when destPreArriveTm = 'null' then null else cast(destPreArriveTm as bigint) end as destPreArriveTm,
case when insertTime = 'null' then null else cast(insertTime as timestamp) end as insertTime,
case when fullLoadWeight = 'null' then null else cast(fullLoadWeight as double) end as fullLoadWeight,
case when srcLoadContnrNos = 'null' then null else srcLoadContnrNos end as srcLoadContnrNos,
case when srcArriveContnrNos = 'null' then null else srcArriveContnrNos end as srcArriveContnrNos,
case when srcUnloadContnrNos = 'null' then null else srcUnloadContnrNos end as srcUnloadContnrNos,
case when secondLoadContnrNos = 'null' then null else secondLoadContnrNos end as secondLoadContnrNos,
case when secondArriveContnrNos = 'null' then null else secondArriveContnrNos end as secondArriveContnrNos,
case when secondUnloadContnrNos = 'null' then null else secondUnloadContnrNos end as secondUnloadContnrNos,
case when thirdLoadContnrNos = 'null' then null else thirdLoadContnrNos end as thirdLoadContnrNos,
case when thirdArriveContnrNos = 'null' then null else thirdArriveContnrNos end as thirdArriveContnrNos,
case when thirdUnloadContnrNos = 'null' then null else thirdUnloadContnrNos end as thirdUnloadContnrNos,
case when destLoadContnrNos = 'null' then null else destLoadContnrNos end as destLoadContnrNos,
case when destArriveContnrNos = 'null' then null else destArriveContnrNos end as destArriveContnrNos,
case when destUnloadContnrNos = 'null' then null else destUnloadContnrNos end as destUnloadContnrNos,
case when srcJobType = 'null' then null else srcJobType end as srcJobType,
case when secondJobType = 'null' then null else secondJobType end as secondJobType,
case when thirdJobType = 'null' then null else thirdJobType end as thirdJobType,
case when destJobType = 'null' then null else destJobType end as destJobType,
case when nextzonecodedynamicprearrivetime = 'null' then null else nextzonecodedynamicprearrivetime end as nextzonecodedynamicprearrivetime,
from_unixtime(cast(ceil(lastUpdateTm/(1000*60*20))*(60*20) as bigint),'yyyy-MM-dd HH:mm:ss') flag20min,
inc_day
from dm_heavy_cargo.rt_vehicle_task_monitor_for_not_send_detail4
where inc_day between '"""+ countDate +"""' and '"""+endDay+"""'""")
    val requireTaskDf = requireTaskDf1


    import spark.implicits._
    // TODO 不进行去重, 去重---同一个20分钟内的数据进行去重操作
    val w = Window.partitionBy($"requireId",$"flag20min").orderBy($"lastUpdateTm".desc)
    val newRequireTaskDf = requireTaskDf.withColumn("rn", row_number().over(w)).where($"rn" === 1).drop("rn")
    newRequireTaskDf.createOrReplaceTempView("new_require_task_info")
    spark.sqlContext.cacheTable("new_require_task_info")

    //[1.1 --->计算未发] 	实际发车时间为空  1待指派,2已指派,3待执行,4异常,5执行中,6已完成,7取消
    //[src未发车]
    val requireTask301 = spark.sqlContext.sql(
      """
        |select * from new_require_task_info where carStatus in (1,2,3,4,5) and srcActualDepartTm is null""".stripMargin)
    requireTask301.createOrReplaceTempView("require_task_301")
    spark.sqlContext.cacheTable("require_task_301")
    val result1 = spark.sqlContext.sql(
      """select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.srcZoneCode as srcZoneCode,a.secondPlanArriveTm as preArriveTm,a.secondZoneCode as preArriveZoneCode,0 as tickets,0 as weight, 1 as status,nvl(srcPlanDepartTm,srcpredeparttm) as sendTime,lineCode,flag20min from require_task_301 a join transit_info_tmp b on a.secondZoneCode = b.deptCode where a.secondZoneCode is not null and a.secondJobType <> '1'""")
    // result1 【未发车】的第一个途径网点在白名单场地内的车辆数据
    val result4 = spark.sqlContext.sql(
      """select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.srcZoneCode as srcZoneCode,  a.destPlanArriveTm as preArriveTm,  a.destZoneCode as preArriveZoneCode,0 as tickets,0 as weight, 1 as status,nvl(srcPlanDepartTm,srcpredeparttm) as sendTime,lineCode,flag20min from require_task_301 a join transit_info_tmp b on a.destZoneCode = b.deptCode where destZoneCode is not null""")
    //result4 【未发车】的目的地在白名单内的车辆数据
    val result6 = spark.sqlContext.sql(
      """select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.srcZoneCode as srcZoneCode, a.thirdPlanArriveTm as preArriveTm, a.thirdZoneCode as preArriveZoneCode,0 as tickets,0 as weight, 1 as status,nvl(srcPlanDepartTm,srcpredeparttm) as sendTime,lineCode,flag20min from require_task_301 a join transit_info_tmp b on a.thirdZoneCode = b.deptCode where a.thirdZoneCode is not null and a.thirdJobType <> '1' """)
    //result6 【未发车】的第二个途径网点在白名单内的车辆数据
    val lastResult1 = result1.union(result4).union(result6).dropDuplicates("requireId","srcZoneCode","preArriveZoneCode","flag20min")

    // [second未发车]
    val requireTask302 = spark.sqlContext.sql(
      """
        |select * from new_require_task_info where carStatus in (1,2,3,4,5) and srcActualDepartTm >0 and secondActualDepartTm is null""".stripMargin)
    requireTask302.createOrReplaceTempView("require_task_302")
    spark.sqlContext.cacheTable("require_task_302")
    //result21 [src-second段未发]确保途经点2在白名单,途经点1不为null
    val result21 = spark.sqlContext.sql("""select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.secondZoneCode as srcZoneCode, a.thirdPlanArriveTm as preArriveTm,a.thirdZoneCode as preArriveZoneCode,0 as tickets,0 as weight,1 as status, nvl(secondplandeparttm,secondpredeparttm) as sendTime,lineCode,flag20min from require_task_302 a join transit_info_tmp b on a.thirdZoneCode = b.deptCode where a.secondZoneCode is not null and a.thirdZoneCode is not null and a.thirdJobType <> '1'""")
    //result23 [src-second段未发]确保目的地在白名单,途经点1不为null
    val result23 = spark.sqlContext.sql("""select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.secondZoneCode as srcZoneCode,  a.destPlanArriveTm as preArriveTm, a.destZoneCode as preArriveZoneCode,0 as tickets,0 as weight, 1 as status,nvl(secondplandeparttm,secondpredeparttm) as sendTime,lineCode,flag20min from require_task_302 a join transit_info_tmp b on a.destZoneCode = b.deptCode where a.secondZoneCode is not null and a.destZoneCode is not null""")
    //lastResult2 [src-second段未发]确保途经点2+目的地在白名单
    val lastResult2 = result21.union(result23).dropDuplicates("requireId","srcZoneCode","preArriveZoneCode","flag20min")

    //[third未发]
    val requireTask303 = spark.sqlContext.sql("""select * from new_require_task_info where carStatus in (1,2,3,4,5) and srcActualDepartTm >0 and secondActualDepartTm >0 and thirdActualDepartTm is null""")
    requireTask303.createOrReplaceTempView("require_task_303")
    //result31 [second-third未发] 目的地在白名单
    val result31 = spark.sqlContext.sql("""select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.thirdZoneCode as srcZoneCode,a.destPlanArriveTm as preArriveTm,a.destZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,1 as status,nvl(thirdplandeparttm,thirdpredeparttm) as sendTime,lineCode,flag20min from require_task_303 a join transit_info_tmp b on a.destZoneCode = b.deptCode where a.thirdZoneCode is not null and a.destZoneCode is not null""")
    val lastResult3 = result31.dropDuplicates("requireId","srcZoneCode","preArriveZoneCode","flag20min")

    //lr [全程未发union  0-1-2] 目的地在白名单
    val lr = lastResult1.union(lastResult2).union(lastResult3)
      .selectExpr("requireId as require_id","carNo as car_no","transLevel","carStatus as car_status","srcZoneCode as src_zone_code","FROM_UNIXTIME(int(sendTime/1000)) as send_time","FROM_UNIXTIME(int(preArriveTm/1000)) as pre_arrive_tm",
        "preArriveZoneCode as pre_arrive_zone_code","tickets","weight","status","lineCode as line_code","flag20min")
      .where($"src_zone_code" =!= $"pre_arrive_zone_code")

    //TidbUtil.write("t_monitor_in_road_cargo_big",lr,SaveMode.Overwrite)
    spark.sqlContext.uncacheTable("require_task_301")
    spark.sqlContext.uncacheTable("require_task_302")

    println("1:未发车辆计算完毕")
    println("2:开始计算在途")

    //[在途计算--->后期计算需要union近7天的在途数据]
    val requireTaskInRoad = requireTaskDf1
      .withColumn("rn", row_number().over(w))
      .where($"rn" === 1).drop("rn")
    requireTaskInRoad.createOrReplaceTempView("new_require_task_info2")
    //
    val inRoad = spark.sqlContext.sql("" +
      "select * from new_require_task_info2 " +
      "where carStatus in (1,2,3,4,5) ")
    inRoad.createOrReplaceTempView("in_road_cars")
    spark.sqlContext.cacheTable("in_road_cars")
    //in_road_cars_first 【o-1在途】且经过途经点1，途经点2为空，目的地为空
    val inFirstCarNos = spark.sqlContext.sql("""  select requireId, "" as carNo,translevel,carStatus,                   srcZoneCode, secondZoneCode as preArriveZoneCode, coalesce(nextzonecodedynamicprearrivetime,secondPreArriveTm,secondPlanArriveTm) as preArriveTm,   srcActualDepartTm as sendTime,lineCode,flag20min, 2 as status,0 tickets,0 weight from in_road_cars where srcActualDepartTm >0 and secondZoneCode is not null and secondActualArriveTm is null and thirdActualArriveTm is null and destActualArriveTm is null and secondJobType <> '1' """)
    //in_road_cars_second 【o-d 不经过途经点的车辆在途数据】
    val inSecondCarNos = spark.sqlContext.sql(""" select requireId, "" as carNo,translevel,carStatus,                   srcZoneCode,   destZoneCode as preArriveZoneCode,     coalesce(nextzonecodedynamicprearrivetime,destPreArriveTm,destPlanArriveTm) as preArriveTm,   srcActualDepartTm as sendTime,lineCode,flag20min, 2 as status,0 tickets,0 weight from in_road_cars where srcActualDepartTm >0 and secondZoneCode is null     and secondActualArriveTm is null and thirdActualArriveTm is null and destActualArriveTm is null and destZoneCode is not null  """)
    //【1-2在途】 车辆数据
    val inThirdCarNos = spark.sqlContext.sql("""  select requireId, "" as carNo,translevel,carStatus, secondZoneCode as srcZoneCode,  thirdZoneCode as preArriveZoneCode,   coalesce(nextzonecodedynamicprearrivetime,thirdPreArriveTm,thirdPlanArriveTm) as preArriveTm,secondActualDepartTm as sendTime,lineCode,flag20min, 2 as status,0 tickets,0 weight from in_road_cars where srcActualDepartTm >0 and secondZoneCode is not null and secondActualDepartTm > 0 and thirdZoneCode is not null and thirdActualArriveTm is null and destActualArriveTm is null and thirdJobType <> '1' """)
    //【1-d在途】 车辆数据
    val inForthCarNos = spark.sqlContext.sql("""  select requireId, "" as carNo,translevel,carStatus, secondZoneCode as srcZoneCode,   destZoneCode as preArriveZoneCode,     coalesce(nextzonecodedynamicprearrivetime,destPreArriveTm,destPlanArriveTm) as preArriveTm,secondActualDepartTm as sendTime,lineCode,flag20min, 2 as status,0 tickets,0 weight from in_road_cars where srcActualDepartTm >0 and secondZoneCode is not null and secondActualDepartTm > 0 and thirdZoneCode is null and destActualArriveTm is null and destZoneCode is not null """)
    //【2-d在途】 车辆数据
    val inFivethCarNos = spark.sqlContext.sql(""" select requireId, "" as carNo,translevel,carStatus,  thirdZoneCode as srcZoneCode,   destZoneCode as preArriveZoneCode,     coalesce(nextzonecodedynamicprearrivetime,destPreArriveTm,destPlanArriveTm) as preArriveTm, thirdActualDepartTm as sendTime,lineCode,flag20min, 2 as status,0 tickets,0 weight from in_road_cars where srcActualDepartTm >0 and  thirdZoneCode is not null and thirdActualDepartTm > 0 and destActualArriveTm is null and destZoneCode is not null """)

    val inAllCarNos = inFirstCarNos.union(inSecondCarNos).union(inThirdCarNos).union(inForthCarNos).union(inFivethCarNos)
    inAllCarNos.createOrReplaceTempView("in_all_car_nos")
    //所有白名单车标
    val sfAllCarNos = spark.sqlContext.sql(""" select a.* from in_all_car_nos a join transit_info_tmp b on a.preArriveZoneCode = b.deptCode """)

    val inTotalAll = sfAllCarNos.where($"srcZoneCode" =!= $"preArriveZoneCode")
      .selectExpr("requireId as require_id","carNo as car_no","transLevel","carStatus as car_status","srcZoneCode as src_zone_code","FROM_UNIXTIME(int(sendTime/1000)) as send_time","FROM_UNIXTIME(int(preArriveTm/1000)) as pre_arrive_tm",
        "preArriveZoneCode as pre_arrive_zone_code","tickets","weight","status","lineCode as line_code","flag20min")

    //TidbUtil.write("t_monitor_in_road_cargo_big",inTotalAll,SaveMode.Append)
    spark.sqlContext.uncacheTable("in_road_cars")
    println("3:在途货量计算完毕")

    println("4:开始计算已到达")
    //TODO 后期join上已到达的数据  dm_heavy_cargo.big_has_arrive_cargo_new  近3天的数据 [时间格式问题]
    //补充已到达车辆没有车标的情况
    /*val kArriverCargo = spark.sqlContext.sql(
      """
        SELECT
                require_id,
                car_no,
                translevel,
                6 as car_status,
                src_zone_code,
                from_unixtime(int(send_time/1000 )) send_time,
                from_unixtime(int(arrive_time/1000)) as pre_arrive_tm,
                dest_zone_code as pre_arrive_zone_code,
                sum(tickets) over(partition by require_id,dest_zone_code) as tickets,
                sum(weight) over(partition by require_id,dest_zone_code) as weight,
                3 as status,
                null line_code,
                from_unixtime(cast(ceil(arrive_time/(1000*60*20))*(60*20) as bigint),'yyyy-MM-dd HH:mm:ss') flag20min,
                from_unixtime(cast(arrive_time/1000 as bigint), 'yyyyMMdd') inc_day,
                row_number() over(partition by require_id,dest_zone_code order by arrive_time) as num
            FROM ky.dm_heavy_cargo.ky_has_arrive_cargo
            where inc_day ='"""+Ago15Day+"""'
        """).where("num =1 and inc_day between '"+countDate+"' and '"+endDay+"'").drop("num","inc_day")
      .dropDuplicates("require_id","pre_arrive_zone_code","flag20min")*/

    requireTaskDf1.withColumn("rn", row_number().over(w)).where($"rn" === 1).drop("rn").createOrReplaceTempView("last_day_car_info")
    val hasArrive1 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus,                  srcZoneCode, secondActualArriveTm as preArriveTm,secondZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status,    srcActualDepartTm as sendTime ,lineCode,flag20min from last_day_car_info where (carNo is null or carNo = '') and srcActualDepartTm > 0 and secondActualArriveTm > 0 and secondActualDepartTm is null""")
    val hasArrive2 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus,secondZoneCode as srcZoneCode,  thirdActualArriveTm as preArriveTm, thirdZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status, secondActualDepartTm as sendTime ,lineCode,flag20min from last_day_car_info where (carNo is null or carNo = '') and secondActualDepartTm > 0 and thirdActualArriveTm > 0 and thirdActualDepartTm is null""")
    val hasArrive3 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus, thirdZoneCode as srcZoneCode,   destActualArriveTm as preArriveTm,  destZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status,  thirdActualDepartTm as sendTime ,lineCode,flag20min from last_day_car_info where (carNo is null or carNo = '') and thirdActualDepartTm > 0 and destActualArriveTm > 0 """)
    val hasArrive4 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus,secondZoneCode as srcZoneCode,   destActualArriveTm as preArriveTm,  destZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status, secondActualDepartTm as sendTime ,lineCode,flag20min from last_day_car_info where (carNo is null or carNo = '') and secondActualDepartTm > 0 and thirdZoneCode is null and destActualArriveTm > 0""")
    val hasArrive5 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus,                  srcZoneCode,   destActualArriveTm as preArriveTm,  destZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status,    srcActualDepartTm as sendTime ,lineCode,flag20min from last_day_car_info where (carNo is null or carNo = '') and srcActualDepartTm > 0 and secondZoneCode is null and thirdZoneCode is null and destActualArriveTm > 0 """)
    val hasArriveTotalPre2 = hasArrive1.union(hasArrive2).union(hasArrive3).union(hasArrive4).union(hasArrive5).dropDuplicates("requireId","preArriveZoneCode","flag20min")
    hasArriveTotalPre2.createOrReplaceTempView("has_arrive_total_pre2")

    val hasArriveTotal2 = spark.sqlContext.sql("""select a.* from has_arrive_total_pre2 a join transit_info_tmp b on a.preArriveZoneCode = b.deptCode""")
      .selectExpr("requireId as require_id","carNo as car_no","transLevel","carStatus as car_status","srcZoneCode as src_zone_code","FROM_UNIXTIME(int(sendTime/1000)) as send_time","FROM_UNIXTIME(int(preArriveTm/1000)) as pre_arrive_tm",
        "preArriveZoneCode as pre_arrive_zone_code","tickets","weight","status","lineCode as line_code","flag20min")
    hasArriveTotal2.createOrReplaceTempView("has_arrive_all")
    val hasArriveResult = spark.sqlContext.sql("""select t.* from (select a.*,row_number() over(partition by require_id,pre_arrive_zone_code,flag20min order by weight desc) as rn from has_arrive_all a)t where t.rn = 1 """).drop("rn").where($"src_zone_code" =!= $"pre_arrive_zone_code")
    println("4:已到达货量计算完毕")

    //todo 写入hive
    val result = lr.union(inTotalAll).union(hasArriveResult)
      .repartition(1)
    result.createOrReplaceTempView("Result")

    //TODO 写入hive表
      spark.sqlContext.sql("set hive.merge.sparkFiles=true;")
      spark.sqlContext.sql("set mapred.max.split.size=268435456;")
      spark.sqlContext.sql("set mapred.min.split.size.per.node=268435456;")
      spark.sqlContext.sql("set mapred.min.split.size.per.rack=268435456;")
      spark.sqlContext.sql("set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;")
      spark.sqlContext.sql("set hive.exec.reducers.bytes.per.reducer=268435456;")
      spark.sqlContext.sql("set hive.exec.reducers.max=1099;")
      spark.sqlContext.sql("set hive.merge.size.per.task=268435456;")
      spark.sqlContext.sql("set hive.merge.smallfiles.avgsize=134217728;")
    spark.sqlContext.sql("""
                                  | insert into table dm_heavy_cargo.dwd_ky_dept_in_road_pre20min_dtl_di partition(inc_day)
                                  | select
                                  |       require_id,car_no,translevel,car_status,src_zone_code,send_time,pre_arrive_tm,pre_arrive_zone_code,
                                  |       tickets,
                                  |       weight,
                                  |       status,
                                  |       line_code,
                                  |       flag20min,
                                  |       date_format(flag20min,'yyyyMMdd') inc_day
                                  | from Result""".stripMargin)
  }
}

