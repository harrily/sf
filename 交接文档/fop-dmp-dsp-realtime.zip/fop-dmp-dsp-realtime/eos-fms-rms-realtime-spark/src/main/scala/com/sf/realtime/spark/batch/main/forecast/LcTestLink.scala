package com.sf.realtime.spark.batch.main.forecast

import com.sf.realtime.common.utils.DateUtil
import com.sf.realtime.spark.context.Context
import com.sf.realtime.spark.sql.{CarInfo, DeptInfo}
import org.apache.spark.sql.{DataFrame, Dataset, Row}

object LcTestLink {
  def main(args: Array[String]): Unit = {
    val spark = Context.getContext(true)
    var deptCodeDf: DataFrame = null
    var hasArriveTaskDf: Dataset[Row] = null
    deptCodeDf = DeptInfo.getKyNewDeptInfo(spark.sqlContext).limit(1000)
    deptCodeDf.createOrReplaceTempView("dim_dept")
    //3.顺丰车辆数据过滤
    hasArriveTaskDf = CarInfo.getVehicleHasArriveTaskInfo(spark.sqlContext,DateUtil.getLastHoursTime(24*14),14).limit(1000)
    hasArriveTaskDf.createOrReplaceTempView("arrive_car")
    spark.sqlContext.sql("""create table tmp_dm_predict.lc_dept_code_1 as select * from dim_dept""")
    spark.sqlContext.sql("""create table tmp_dm_predict.lc_arrive_car_1 as select * from arrive_car""")
  }
}
