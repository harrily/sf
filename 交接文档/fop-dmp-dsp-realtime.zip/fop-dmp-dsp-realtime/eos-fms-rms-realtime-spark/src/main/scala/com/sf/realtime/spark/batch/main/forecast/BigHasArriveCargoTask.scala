package com.sf.realtime.spark.batch.main.forecast


import com.sf.realtime.common.utils.DateUtil
import com.sf.realtime.spark.context.Context
import com.sf.realtime.spark.sql.DeptInfo
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


object BigHasArriveCargoTask {

  def main(args: Array[String]): Unit = {

    val spark = Context.getContext(true)
    val startDay = args(0)
    val currentDay = args(1)//"2022-02-23 06:15:00"
    val endDay = DateUtil.df2Todf3(currentDay)
    //TODO 修改白名单场地
    val transitDf = DeptInfo.getKyNewDeptInfo(spark.sqlContext)
    transitDf.createOrReplaceTempView("transit_info_tmp")

    val sql =
      """select * from (select
        | case when idKey = 'null' then null else idKey end as idKey,
        | case when requireId = 'null' then null else requireId end as requireId,
        | case when translevel = 'null' then null else cast(translevel as int) end as translevel,
        | case when carNo = 'null' then null else carNo end as carNo,
        | case when lineCode = 'null' then null else lineCode end as lineCode,
        | case when carStatus = 'null' then null else cast(carStatus as int) end as carStatus,
        | case when lastUpdateTm = 'null' then null else cast(lastUpdateTm as bigint) end as lastUpdateTm,
        | case when srcZoneCode = 'null' then null else srcZoneCode end as srcZoneCode,
        | case when srcPlanReachTm = 'null' then null else cast(srcPlanReachTm as bigint) end as srcPlanReachTm,
        | case when srcPlanDepartTm = 'null' then null else cast(srcPlanDepartTm as bigint) end as srcPlanDepartTm,
        | case when srcActualDepartTm = 'null' then null else cast(srcActualDepartTm as bigint) end as srcActualDepartTm,
        | case when srcPreDepartTm = 'null' then null else cast(srcPreDepartTm as bigint) end as srcPreDepartTm,
        | case when srcPlanArriveTm = 'null' then null else cast(srcPlanArriveTm as bigint) end as srcPlanArriveTm,
        | case when srcActualArriveTm = 'null' then null else cast(srcActualArriveTm as bigint) end as srcActualArriveTm,
        | case when srcPreArriveTm = 'null' then null else cast(srcPreArriveTm as bigint) end as srcPreArriveTm,
        | case when secondZoneCode = 'null' then null else secondZoneCode end as secondZoneCode,
        | case when secondPlanReachTm = 'null' then null else cast(secondPlanReachTm as bigint) end as secondPlanReachTm,
        | case when secondPlanDepartTm = 'null' then null else cast(secondPlanDepartTm as bigint) end as secondPlanDepartTm,
        | case when secondActualDepartTm = 'null' then null else cast(secondActualDepartTm as bigint) end as secondActualDepartTm,
        | case when secondPreDepartTm = 'null' then null else cast(secondPreDepartTm as bigint) end as secondPreDepartTm,
        | case when secondPlanArriveTm = 'null' then null else cast(secondPlanArriveTm as bigint) end as secondPlanArriveTm,
        | case when secondActualArriveTm = 'null' then null else cast(secondActualArriveTm as bigint) end as secondActualArriveTm,
        | case when secondPreArriveTm = 'null' then null else cast(secondPreArriveTm as bigint) end as secondPreArriveTm,
        | case when thirdZoneCode = 'null' then null else thirdZoneCode end as thirdZoneCode,
        | case when thirdPlanReachTm = 'null' then null else cast(thirdPlanReachTm as bigint) end as thirdPlanReachTm,
        | case when thirdPlanDepartTm = 'null' then null else cast(thirdPlanDepartTm as bigint) end as thirdPlanDepartTm,
        | case when thirdActualDepartTm = 'null' then null else cast(thirdActualDepartTm as bigint) end as thirdActualDepartTm,
        | case when thirdPreDepartTm = 'null' then null else cast(thirdPreDepartTm as bigint) end as thirdPreDepartTm,
        | case when thirdPlanArriveTm = 'null' then null else cast(thirdPlanArriveTm as bigint) end as thirdPlanArriveTm,
        | case when thirdActualArriveTm = 'null' then null else cast(thirdActualArriveTm as bigint) end as thirdActualArriveTm,
        | case when thirdPreArriveTm = 'null' then null else cast(thirdPreArriveTm as bigint) end as thirdPreArriveTm,
        | case when destZoneCode = 'null' then null else destZoneCode end as destZoneCode,
        | case when destPlanReachTm = 'null' then null else cast(destPlanReachTm as bigint) end as destPlanReachTm,
        | case when destPlanDepartTm = 'null' then null else cast(destPlanDepartTm as bigint) end as destPlanDepartTm,
        | case when destActualDepartTm = 'null' then null else cast(destActualDepartTm as bigint) end as destActualDepartTm,
        | case when destPreDepartTm = 'null' then null else cast(destPreDepartTm as bigint) end as destPreDepartTm,
        | case when destPlanArriveTm = 'null' then null else cast(destPlanArriveTm as bigint) end as destPlanArriveTm,
        | case when destActualArriveTm = 'null' then null else cast(destActualArriveTm as bigint) end as destActualArriveTm,
        | case when destPreArriveTm = 'null' then null else cast(destPreArriveTm as bigint) end as destPreArriveTm,
        | case when insertTime = 'null' then null else cast(insertTime as timestamp) end as insertTime,
        | case when fullLoadWeight = 'null' then null else cast(fullLoadWeight as double) end as fullLoadWeight,
        | case when srcLoadContnrNos = 'null' then null else srcLoadContnrNos end as srcLoadContnrNos,
        | case when srcArriveContnrNos = 'null' then null else srcArriveContnrNos end as srcArriveContnrNos,
        | case when srcUnloadContnrNos = 'null' then null else srcUnloadContnrNos end as srcUnloadContnrNos,
        | case when secondLoadContnrNos = 'null' then null else secondLoadContnrNos end as secondLoadContnrNos,
        | case when secondArriveContnrNos = 'null' then null else secondArriveContnrNos end as secondArriveContnrNos,
        | case when secondUnloadContnrNos = 'null' then null else secondUnloadContnrNos end as secondUnloadContnrNos,
        | case when thirdLoadContnrNos = 'null' then null else thirdLoadContnrNos end as thirdLoadContnrNos,
        | case when thirdArriveContnrNos = 'null' then null else thirdArriveContnrNos end as thirdArriveContnrNos,
        | case when thirdUnloadContnrNos = 'null' then null else thirdUnloadContnrNos end as thirdUnloadContnrNos,
        | case when destLoadContnrNos = 'null' then null else destLoadContnrNos end as destLoadContnrNos,
        | case when destArriveContnrNos = 'null' then null else destArriveContnrNos end as destArriveContnrNos,
        | case when destUnloadContnrNos = 'null' then null else destUnloadContnrNos end as destUnloadContnrNos,
        | case when srcJobType = 'null' then null else srcJobType end as srcJobType,
        | case when secondJobType = 'null' then null else secondJobType end as secondJobType,
        | case when thirdJobType = 'null' then null else thirdJobType end as thirdJobType,
        | case when destJobType = 'null' then null else destJobType end as destJobType,
        | case when nextzonecodedynamicprearrivetime = 'null' then null else nextzonecodedynamicprearrivetime end as nextzonecodedynamicprearrivetime,
        | inc_day,
        |row_number() over(partition by requireId order by lastUpdateTm desc) rn from dm_heavy_cargo.rt_vehicle_task_monitor_for_not_send_detail4 a where inc_day between '""".stripMargin+startDay+"""' and '"""+endDay+"""' and (secondActualArriveTm >0 or thirdActualArriveTm>0 or destActualArriveTm >0))aa where aa.rn=1 and aa.carStatus in (3,4,5,6)"""
    val requireDetail = spark.sqlContext.sql(sql).drop("rn")
    requireDetail.createOrReplaceTempView("require_detail")
    val hasArrive1 = spark.sqlContext.sql("""select aa.*, adTable.car_no as car_no from (select a.requireId as require_id,a.translevel,   a.srcZoneCode as src_zone_code,   nvl(a.srcActualDepartTm,nvl(srcPlanDepartTm,   srcpredeparttm))    as send_time,a.secondZoneCode as dest_zone_code,a.secondActualArriveTm as arrive_time,a.secondUnloadContnrnos as car_nos,a.linecode as line_code from require_detail a join transit_info_tmp b on a.secondZoneCode = b.deptCode where a.secondZoneCode is not null and a.secondActualArriveTm > 0 and a.secondUnloadContnrnos is not null)aa LATERAL VIEW explode(split(car_nos, ',')) adTable AS car_no""")
    val hasArrive2 = spark.sqlContext.sql("""select aa.*, adTable.car_no as car_no from (select a.requireId as require_id,a.translevel,a.secondZoneCode as src_zone_code,nvl(a.secondActualDepartTm,nvl(secondplandeparttm,secondpredeparttm)) as send_time, a.thirdZoneCode as dest_zone_code,a.thirdActualArriveTm as arrive_time,a.thirdUnloadContnrnos as car_nos,a.linecode as line_code from require_detail a join transit_info_tmp b on a.thirdZoneCode = b.deptCode where a.thirdZoneCode is not null and a.thirdActualArriveTm > 0 and a.thirdUnloadContnrnos is not null)aa LATERAL VIEW explode(split(car_nos, ',')) adTable AS car_no""")
    val hasArrive3 = spark.sqlContext.sql("""select aa.*, adTable.car_no as car_no from (select a.requireId as require_id,a.translevel,   a.srcZoneCode as src_zone_code,   nvl(a.srcActualDepartTm,nvl(srcPlanDepartTm,   srcpredeparttm))    as send_time,  a.destZoneCode as dest_zone_code,  a.destActualArriveTm as arrive_time, case when a.destUnloadContnrnos is not null then a.destUnloadContnrnos when a.destArriveContnrnos is not null then a.destArriveContnrnos else a.carNo end as car_nos,a.linecode as line_code from require_detail a join transit_info_tmp b on a.destZoneCode = b.deptCode where a.destZoneCode is not null and a.destActualArriveTm > 0 and a.secondZoneCode is null)aa LATERAL VIEW explode(split(car_nos, ',')) adTable AS car_no""")
    val hasArrive4 = spark.sqlContext.sql("""select aa.*, adTable.car_no as car_no from (select a.requireId as require_id,a.translevel,a.secondZoneCode as src_zone_code,nvl(a.secondActualDepartTm,nvl(secondplandeparttm,secondpredeparttm)) as send_time,  a.destZoneCode as dest_zone_code,  a.destActualArriveTm as arrive_time, case when a.destUnloadContnrnos is not null then a.destUnloadContnrnos  when a.destArriveContnrnos is not null then a.destArriveContnrnos else a.carNo end as car_nos,a.linecode as line_code from require_detail a join transit_info_tmp b on a.destZoneCode = b.deptCode where a.destZoneCode is not null and a.destActualArriveTm > 0 and a.secondZoneCode is not null and a.thirdZoneCode is null)aa LATERAL VIEW explode(split(car_nos, ',')) adTable AS car_no""")
    val hasArrive5 = spark.sqlContext.sql("""select aa.*, adTable.car_no as car_no from (select a.requireId as require_id,a.translevel, a.thirdZoneCode as src_zone_code, nvl(a.thirdActualDepartTm,nvl(thirdplandeparttm, thirdpredeparttm))  as send_time,  a.destZoneCode as dest_zone_code,  a.destActualArriveTm as arrive_time, case when a.destUnloadContnrnos is not null then a.destUnloadContnrnos  when a.destArriveContnrnos is not null then a.destArriveContnrnos else a.carNo end as car_nos,a.linecode as line_code from require_detail a join transit_info_tmp b on a.destZoneCode = b.deptCode where a.destZoneCode is not null and a.destActualArriveTm > 0 and a.thirdZoneCode is not null )aa LATERAL VIEW explode(split(car_nos, ',')) adTable AS car_no""")
    import spark.implicits._
    val w = Window.partitionBy($"requireId",$"car_no").orderBy($"arrive_time")
    val allArrive = hasArrive1.union(hasArrive2).union(hasArrive3).union(hasArrive4).union(hasArrive5)
      .withColumn("rn", row_number().over(w)).where($"rn" === 1).drop("rn")

    val allArrive2 = allArrive.filter(r => r.getAs[String]("car_no") != null && !r.getAs[String]("car_no").equals(""))
    val requireCarNoDetail = allArrive2
    //TODO hive表关联   dim_freight.dim_container_waybill_info_di 【车标运单关系维表】 --保留15kg+的运单
    val carNoWaybilno = spark
      .sqlContext.sql("""select packageNo,carno,chargeweight from ky.dm_heavy_cargo.dm_unload_carno_waybill_dtl_di where inc_day between '""" + DateUtil.getLastDayStringdf3(startDay,30)  + """' and '""" + endDay + """'""")
      .dropDuplicates("packageNo","carno")
      .groupBy("carno")
      .agg(sum("chargeweight") as ("weight"), count("packageNo") as ("tickets"))
    // 左连接
    val requireCarNoDetailDf = allArrive2
      .join(carNoWaybilno, carNoWaybilno("carno").equalTo(allArrive2("car_no")),"left")

    val resultPre = requireCarNoDetailDf.groupBy("require_id","line_code","car_no","translevel","src_zone_code","dest_zone_code","send_time","arrive_time").agg(sum("tickets").as("tickets"),sum("weight").as("weight"))
    resultPre.createOrReplaceTempView("result_pre")
    val result = spark.sqlContext.sql(
      """select a.require_id,a.car_no,a.src_zone_code,a.dest_zone_code,
        |from_unixtime(cast(a.send_time/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as send_time,
        |from_unixtime(cast(a.arrive_time/1000 as bigint), 'yyyy-MM-dd HH:mm:ss') as arrive_time,
        |a.tickets,a.weight,a.translevel,a.line_code from result_pre a """.stripMargin)

    spark.sqlContext.sql("set hive.merge.sparkFiles=true;")
    spark.sqlContext.sql("set mapred.max.split.size=268435456;")
    spark.sqlContext.sql("set mapred.min.split.size.per.node=268435456;")
    spark.sqlContext.sql("set mapred.min.split.size.per.rack=268435456;")
    spark.sqlContext.sql("set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;")
    spark.sqlContext.sql("set hive.exec.reducers.bytes.per.reducer=268435456;")
    spark.sqlContext.sql("set hive.exec.reducers.max=1099;")
    spark.sqlContext.sql("set hive.merge.size.per.task=268435456;")
    spark.sqlContext.sql("set hive.merge.smallfiles.avgsize=134217728;")
    result.repartition(1).createOrReplaceTempView("result")
    //TODO 将结果写出到dm_heavy_cargo.big_has_arrive_cargo
    spark.sqlContext.sql("""insert overwrite table ky.dm_heavy_cargo.dm_sf_has_arrive_001_dtl_di partition(inc_day='"""+endDay+"""') select * from result""")
  }
}
