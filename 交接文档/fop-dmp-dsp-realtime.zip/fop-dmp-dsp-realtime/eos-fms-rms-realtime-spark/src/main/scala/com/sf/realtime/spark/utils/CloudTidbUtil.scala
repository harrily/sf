package com.sf.realtime.spark.utils

import com.sf.realtime.common.config.Config
import org.apache.spark.sql.{DataFrame, SQLContext}

import java.sql.{Connection, DriverManager}
import java.util.Properties

object CloudTidbUtil {
  private var connection: Connection = _
  private val driver = "com.mysql.cj.jdbc.Driver"
  private val url = Config.getConfig.getString("tidb.cloud.jdbc.url")
  private val username = Config.getConfig.getString("tidb.cloud.user")
  private val password = Config.getConfig.getString("tidb.cloud.passwd")

  val prop =new Properties()
  prop.setProperty("user",username)
  prop.setProperty("password",password)

  /**
   * 创建mysql连接
   *
   * @return
   */
  def conn(): Connection = {
    if (connection == null) {
      Class.forName(this.driver)
      connection = DriverManager.getConnection(this.url, this.username, this.password)
    }
    connection
  }

  def getConn(): Connection = {
    Class.forName(this.driver)
    connection = DriverManager.getConnection(this.url, this.username, this.password)
    connection
  }


  def read(tableName:String,sqlContext:SQLContext,predicates:Array[String]):DataFrame={
    val df = sqlContext.read.option("driver", "com.mysql.cj.jdbc.Driver")
      .jdbc(url, tableName, predicates, prop)
    df
  }

  def read(tableName:String,sqlContext:SQLContext):DataFrame={
    val df = sqlContext.read.option("driver", "com.mysql.cj.jdbc.Driver")
      .jdbc(url, tableName, prop)
    df
  }
}
