package com.sf.realtime.spark.context

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession


object Context {

  val conf = new SparkConf().setAppName("")
  //设置优雅关闭
  conf.set("spark.streaming.stopGracefullyOnShutdown","true")
  //开启反压
  conf.set("spark.streaming.backpressure.enabled","true")
  //启用反压机制时每个接收器接收第一批数据的初始最大速率
  conf.set("spark.streaming.backpressure.initialRate", "5000")
  //设定对目标topic每个partition每秒钟拉取的数据条数
  conf.set("spark.streaming.kafka.maxRatePerPartition", "5000")
  //提高shuffle并行度
  conf.set("spark.sql.shuffle.partitions", "500")
  //RDD任务的默认并行度
  conf.set("spark.default.parallelism", "500")
  //设置字段长度最大值
  conf.set("spark.debug.maxToStringFields", "100")
  conf.set("hive.exec.dynamici.partition", "true")
  conf.set("hive.exec.dynamic.partition.mode", "nonstrict")

  def getContext(enableHive:Boolean):SparkSession={
    if(enableHive){
      SparkSession.builder()
        .config(conf)
        //.master("local[2]")
        .enableHiveSupport() //enableHiveSupport 操作hive表
        .getOrCreate()
    }else{
      SparkSession.builder()
        .config(conf)
        //.master("local[2]")
        .getOrCreate()
    }
  }
  def getContext():SparkSession={
    getContext(true)
  }
}
