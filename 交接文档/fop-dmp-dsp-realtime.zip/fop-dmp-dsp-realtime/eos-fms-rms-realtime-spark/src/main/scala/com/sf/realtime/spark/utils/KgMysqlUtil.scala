package com.sf.realtime.spark.utils

import java.util.Properties

import com.sf.realtime.common.config.Config
import org.apache.spark.sql.{DataFrame, SQLContext, SaveMode}

object KgMysqlUtil {
  val config = Config.getConfig
  val jdbcUrl = config.getString("mysql.kg.jdbc.url")
  val user = config.getString("mysql.kg.user")
  val passwd = config.getString("mysql.kg.passwd")

  val prop =new Properties()
  prop.setProperty("user",user)
  prop.setProperty("password",passwd)

  def read(tableName:String,sqlContext:SQLContext,predicates:Array[String]):DataFrame={
    val df = sqlContext.read.option("driver", "com.mysql.cj.jdbc.Driver")
      .jdbc(jdbcUrl, tableName, predicates, prop)
    df
  }

  def read(tableName:String,sqlContext:SQLContext):DataFrame={
    val df = sqlContext.read.option("driver", "com.mysql.cj.jdbc.Driver")
      .jdbc(jdbcUrl, tableName, prop)
    df
  }

  def write(tableName:String,data:DataFrame):Unit={
    write(tableName,data,SaveMode.Append)
  }

  def write(tableName:String,data:DataFrame,mode:SaveMode) = mode match {
    case SaveMode.Overwrite =>
      data.write.option("driver", "com.mysql.cj.jdbc.Driver")
        .option("isolationLevel", "NONE")
        .option("truncate", true)
        .mode(mode)
        .jdbc(jdbcUrl, tableName, prop)
    case _ =>
      data.write.option("driver", "com.mysql.cj.jdbc.Driver")
        .option("isolationLevel", "NONE")
        .mode(mode)
        .jdbc(jdbcUrl, tableName, prop)
  }
}
