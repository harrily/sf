package com.sf.realtime.spark.batch.sql

import java.sql.{Connection, DriverManager}

import com.sf.realtime.common.config.Config


object MysqlConnect {
  private var connection: Connection = _

  private val driver = "com.mysql.cj.jdbc.Driver"
  private val url = Config.getConfig.getString("tidb.jdbc.url")
  private val username = Config.getConfig.getString("tidb.user")
  private val password = Config.getConfig.getString("tidb.passwd")

  /**
    * 创建mysql连接
    *
    * @return
    */
  def conn(): Connection = {

    if (connection == null || connection.isClosed) {
      Class.forName(this.driver)
      connection = DriverManager.getConnection(this.url, this.username, this.password)
    }
    connection
  }

  def close():Unit = {
    if(connection != null){
      connection.close()
    }
  }

  def getConn():Connection = {
    Class.forName(this.driver)
    connection = DriverManager.getConnection(this.url, this.username, this.password)
    connection
  }
}