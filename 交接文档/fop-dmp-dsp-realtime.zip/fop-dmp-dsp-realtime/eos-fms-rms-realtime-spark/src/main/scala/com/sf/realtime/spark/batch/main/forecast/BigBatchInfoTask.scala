package com.sf.realtime.spark.batch.main.forecast

import com.sf.realtime.common.utils.DateUtil
import com.sf.realtime.spark.context.Context

import java.time.LocalDate
import java.time.format.DateTimeFormatter

/**
 * @Author 01419728
 * @Date 2022/4/6 20:45
 */
object BigBatchInfoTask {
  def main(args: Array[String]): Unit = {
    val incday = DateUtil.df2Todf3(args(0)) //统计时间"yyyyMMdd"
    val spark = Context.getContext(true)
    import spark.implicits._
    val cargoResult = spark.sqlContext.sql("""select * from dm_heavy_cargo.dwd_t_monitor_in_road_cargo_big_dtl_di where inc_day ='""" + incday + """'""")
    cargoResult.rdd.mapPartitions(f=>{
      f.map(r=>{
        val require_id = r.getAs[String]("require_id")
        val car_no = r.getAs[String]("car_no")
        val translevel = r.getAs[Integer]("translevel")
        val car_status = r.getAs[Integer]("car_status")
        val src_zone_code = r.getAs[String]("src_zone_code")
        val pre_arrive_tm = r.getAs[String]("pre_arrive_tm")
        val pre_arrive_zone_code = r.getAs[String]("pre_arrive_zone_code")
        val tickets = r.getAs[Long]("tickets")
        val weight = r.getAs[Double]("weight")
        val status = r.getAs[Integer]("status")
        val count_time = r.getAs[String]("count_time")
        val count_date = r.getAs[String]("count_date")
        val send_time = r.getAs[String]("send_time")
        val line_code = r.getAs[String]("line_code")
        val inc_day = r.getAs[String]("inc_day")
        val df4:DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        val df5:DateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
        val arr_tm = LocalDate.parse(pre_arrive_tm, df4).atStartOfDay().format(df5)


        val sqlq=
          """
            | SELECT zonecode,batch_code,batch_date,start_last_arr_tm,end_last_arr_tm
            | from bdp.dm_heavy_cargo.dwd_batch_info_dtl_di
            | where zonecode='"""+ pre_arrive_zone_code +"""' and
            | '"""+ arr_tm +"""'>start_last_arr_tm and '"""+ arr_tm +"""'<end_last_arr_tm;
            |""".stripMargin
      })
    })
  }

}
