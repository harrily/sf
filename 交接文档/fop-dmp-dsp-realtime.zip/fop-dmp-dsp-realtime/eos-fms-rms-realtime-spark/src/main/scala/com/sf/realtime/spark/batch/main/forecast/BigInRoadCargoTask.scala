package com.sf.realtime.spark.batch.main.forecast

import java.sql.Timestamp
import java.util
import com.alibaba.fastjson.JSON
import com.sf.realtime.common.config.Config
import com.sf.realtime.common.pojo.WaybillConstant
import com.sf.realtime.common.utils.{DateUtil, ElasticSearchUtil}
import com.sf.realtime.hbase.HbaseUtil
import com.sf.realtime.hbase.common.ColumnType
import com.sf.realtime.spark.context.Context
import com.sf.realtime.spark.sql.{CarInfo, DeptInfo}
import com.sf.realtime.spark.utils.{CacheUtil, KgMysqlUtil, TidbUtil}
import io.searchbox.client.{JestClient, JestClientFactory}
import io.searchbox.client.config.HttpClientConfig
import io.searchbox.core.{Search, SearchResult}
import org.apache.commons.lang.StringUtils
import org.apache.hadoop.hbase.CellUtil
import org.apache.hadoop.hbase.util.Bytes
import org.apache.http.HttpHost
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.row_number
import org.apache.spark.sql.types.{BooleanType, DoubleType, IntegerType, LongType, StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}
import org.apache.spark.sql.functions._

import java.text.SimpleDateFormat
import java.util.{Calendar, Collections, Date, List}
import scala.collection.JavaConverters._
import scala.collection.mutable.ArrayBuffer

/**
 * @Author 01419728
 * @Date 2022/2/14 13:56
 */
object BigInRoadCargoTask {

  def main(args: Array[String]): Unit = {
    //Y0 获取spark context 支持hive的
    val spark: SparkSession = Context.getContext(true)
    //1.获取中转场信息
    //todo 修改白名单场地  tidb2 中dim_heavy_transit_info_big 表取白名单
    val transitDf = DeptInfo.getBigNewDeptInfo(spark.sqlContext)
    var count = 0L
    //Y1.2 创建临时表 transit_info_tmp  select dept_code as deptCode from dim_heavy_transit_info 白名单场地
    transitDf.createOrReplaceTempView("transit_info_tmp")

    val countTime = args(0) //业务时间,也就是每20分钟  统计时间"yyyy-MM-dd HH:mm:ss"
    val countDate = DateUtil.df2Todf3(countTime) //统计时间"yyyyMMdd"
    //取数区间是inc_day between last30 and countDate并且lastupdate < counttime
    val countTimeStamp = DateUtil.getTimeWithHms(countTime) //统计时间"yyyy-MM-dd HH:mm:ss"
    val last30Day = DateUtil.getLastDayStringdf3(countDate, 30)
    val last3Day = DateUtil.getLastDayStringdf3(countDate, 3)
    val last7Day = DateUtil.getLastTimeStamp(countTime, 7)
    //todo 优化点 可以把上一个版本的数据更换版本号 再写一遍, 读hive只读取近20分钟到达数据
    //todo 1.通过读取版本号控制写入的版本

    val versionDf = TidbUtil.read("pub_table_sync_version", spark.sqlContext)
    var versionId = versionDf.where("table_name= 't_monitor_in_road_cargo_big' ")
      .collect()(0).getAs("version_id").asInstanceOf[Long]
    //如果当前版本是1,  删除版本为2的数据 则写入数据为version=2
    if (1L == versionId) {
      versionId = 2L
    } else {
      versionId = 1L
    }
    val conn = TidbUtil.conn()
    val st = conn.createStatement()
    val sql1 = "DELETE FROM dmpdsp.t_monitor_in_road_cargo_big WHERE version_id = " + versionId + " "
    st.executeUpdate(sql1)
    if (st != null) {
      st.close()
    }
    if(conn!= null){
      conn.close()
    }

    //2.获取车辆信息前48小时车辆任务
    //old
    //val requireTaskDf1 = CarInfo.getVehicleNotSendTaskInfo(spark.sqlContext,DateUtil.getLastHoursTime(24),1).drop("currentOpZoneCode")
    //val requireTaskDf1 = CarInfo.getVehicleNotSendTaskInfo(spark.sqlContext,DateUtil.getLastHoursTime(24),1,true).drop("currentOpZoneCode")
    val requireTaskDf1 = spark.sqlContext.sql("""select
case when idKey = 'null' then null else idKey end as idKey,
case when requireId = 'null' then null else requireId end as requireId,
case when translevel = 'null' then null else cast(translevel as int) end as translevel,
case when carNo = 'null' then null else carNo end as carNo,
case when lineCode = 'null' then null else lineCode end as lineCode,
case when carStatus = 'null' then null else cast(carStatus as int) end as carStatus,
case when lastUpdateTm = 'null' then null else cast(lastUpdateTm as bigint) end as lastUpdateTm,
case when srcZoneCode = 'null' then null else srcZoneCode end as srcZoneCode,
case when srcPlanReachTm = 'null' then null else cast(srcPlanReachTm as bigint) end as srcPlanReachTm,
case when srcPlanDepartTm = 'null' then null else cast(srcPlanDepartTm as bigint) end as srcPlanDepartTm,
case when srcActualDepartTm = 'null' then null else cast(srcActualDepartTm as bigint) end as srcActualDepartTm,
case when srcPreDepartTm = 'null' then null else cast(srcPreDepartTm as bigint) end as srcPreDepartTm,
case when srcPlanArriveTm = 'null' then null else cast(srcPlanArriveTm as bigint) end as srcPlanArriveTm,
case when srcActualArriveTm = 'null' then null else cast(srcActualArriveTm as bigint) end as srcActualArriveTm,
case when srcPreArriveTm = 'null' then null else cast(srcPreArriveTm as bigint) end as srcPreArriveTm,
case when secondZoneCode = 'null' then null else secondZoneCode end as secondZoneCode,
case when secondPlanReachTm = 'null' then null else cast(secondPlanReachTm as bigint) end as secondPlanReachTm,
case when secondPlanDepartTm = 'null' then null else cast(secondPlanDepartTm as bigint) end as secondPlanDepartTm,
case when secondActualDepartTm = 'null' then null else cast(secondActualDepartTm as bigint) end as secondActualDepartTm,
case when secondPreDepartTm = 'null' then null else cast(secondPreDepartTm as bigint) end as secondPreDepartTm,
case when secondPlanArriveTm = 'null' then null else cast(secondPlanArriveTm as bigint) end as secondPlanArriveTm,
case when secondActualArriveTm = 'null' then null else cast(secondActualArriveTm as bigint) end as secondActualArriveTm,
case when secondPreArriveTm = 'null' then null else cast(secondPreArriveTm as bigint) end as secondPreArriveTm,
case when thirdZoneCode = 'null' then null else thirdZoneCode end as thirdZoneCode,
case when thirdPlanReachTm = 'null' then null else cast(thirdPlanReachTm as bigint) end as thirdPlanReachTm,
case when thirdPlanDepartTm = 'null' then null else cast(thirdPlanDepartTm as bigint) end as thirdPlanDepartTm,
case when thirdActualDepartTm = 'null' then null else cast(thirdActualDepartTm as bigint) end as thirdActualDepartTm,
case when thirdPreDepartTm = 'null' then null else cast(thirdPreDepartTm as bigint) end as thirdPreDepartTm,
case when thirdPlanArriveTm = 'null' then null else cast(thirdPlanArriveTm as bigint) end as thirdPlanArriveTm,
case when thirdActualArriveTm = 'null' then null else cast(thirdActualArriveTm as bigint) end as thirdActualArriveTm,
case when thirdPreArriveTm = 'null' then null else cast(thirdPreArriveTm as bigint) end as thirdPreArriveTm,
case when destZoneCode = 'null' then null else destZoneCode end as destZoneCode,
case when destPlanReachTm = 'null' then null else cast(destPlanReachTm as bigint) end as destPlanReachTm,
case when destPlanDepartTm = 'null' then null else cast(destPlanDepartTm as bigint) end as destPlanDepartTm,
case when destActualDepartTm = 'null' then null else cast(destActualDepartTm as bigint) end as destActualDepartTm,
case when destPreDepartTm = 'null' then null else cast(destPreDepartTm as bigint) end as destPreDepartTm,
case when destPlanArriveTm = 'null' then null else cast(destPlanArriveTm as bigint) end as destPlanArriveTm,
case when destActualArriveTm = 'null' then null else cast(destActualArriveTm as bigint) end as destActualArriveTm,
case when destPreArriveTm = 'null' then null else cast(destPreArriveTm as bigint) end as destPreArriveTm,
case when insertTime = 'null' then null else cast(insertTime as timestamp) end as insertTime,
case when fullLoadWeight = 'null' then null else cast(fullLoadWeight as double) end as fullLoadWeight,
case when srcLoadContnrNos = 'null' then null else srcLoadContnrNos end as srcLoadContnrNos,
case when srcArriveContnrNos = 'null' then null else srcArriveContnrNos end as srcArriveContnrNos,
case when srcUnloadContnrNos = 'null' then null else srcUnloadContnrNos end as srcUnloadContnrNos,
case when secondLoadContnrNos = 'null' then null else secondLoadContnrNos end as secondLoadContnrNos,
case when secondArriveContnrNos = 'null' then null else secondArriveContnrNos end as secondArriveContnrNos,
case when secondUnloadContnrNos = 'null' then null else secondUnloadContnrNos end as secondUnloadContnrNos,
case when thirdLoadContnrNos = 'null' then null else thirdLoadContnrNos end as thirdLoadContnrNos,
case when thirdArriveContnrNos = 'null' then null else thirdArriveContnrNos end as thirdArriveContnrNos,
case when thirdUnloadContnrNos = 'null' then null else thirdUnloadContnrNos end as thirdUnloadContnrNos,
case when destLoadContnrNos = 'null' then null else destLoadContnrNos end as destLoadContnrNos,
case when destArriveContnrNos = 'null' then null else destArriveContnrNos end as destArriveContnrNos,
case when destUnloadContnrNos = 'null' then null else destUnloadContnrNos end as destUnloadContnrNos,
case when srcJobType = 'null' then null else srcJobType end as srcJobType,
case when secondJobType = 'null' then null else secondJobType end as secondJobType,
case when thirdJobType = 'null' then null else thirdJobType end as thirdJobType,
case when destJobType = 'null' then null else destJobType end as destJobType,
case when nextzonecodedynamicprearrivetime = 'null' then null else nextzonecodedynamicprearrivetime end as nextzonecodedynamicprearrivetime,
inc_day
from dm_heavy_cargo.rt_vehicle_task_monitor_for_not_send_detail4
where inc_day between '"""+last30Day+"""' and '"""+ countDate +"""' and lastUpdateTm <= '"""+ countTimeStamp +"""'""")

    //val requireTaskDf2 = spark.sqlContext.sql("""select * from dm_heavy_cargo.rt_vehicle_task_monitor_for_not_send_detail where inc_day >= '"""+last30Day+"""'""")
    //val requireTaskDf = requireTaskDf1.union(requireTaskDf2)
    val requireTaskDf = requireTaskDf1
    //requireTaskDf.createOrReplaceTempView("car_require_task_info")
    //3.取车辆任务的最新状态
    //Y3.1  近30天未发车辆数据  获取车辆任务的最新状态 new_require_task_info
    import spark.implicits._
    val w = Window.partitionBy($"requireId").orderBy($"lastUpdateTm".desc)
    val newRequireTaskDf = requireTaskDf.withColumn("rn", row_number().over(w)).where($"rn" === 1).drop("rn")
    newRequireTaskDf.createOrReplaceTempView("new_require_task_info")
    spark.sqlContext.cacheTable("new_require_task_info")
    //Y3.2 	实际发车时间为空  1待指派,2已指派,3待执行,4异常,5执行中,6已完成,7取消
    //Y 从最新的车辆状态中获取  未发车的数据 requireTask301
    val requireTask301 = spark.sqlContext.sql(
      """
        |select * from new_require_task_info where carStatus in (1,2,3,4,5) and srcActualDepartTm is null""".stripMargin)
    requireTask301.createOrReplaceTempView("require_task_301")
    spark.sqlContext.cacheTable("require_task_301")
    val result1 = spark.sqlContext.sql(
      """select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.srcZoneCode as srcZoneCode,a.secondPlanArriveTm as preArriveTm,a.secondZoneCode as preArriveZoneCode,0 as tickets,0 as weight, 1 as status,'"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,nvl(srcPlanDepartTm,srcpredeparttm) as sendtime,lineCode from require_task_301 a join transit_info_tmp b on a.secondZoneCode = b.deptCode where a.secondZoneCode is not null and a.secondJobType <> '1'""")
    // result1 【未发车】的第一个途径网点在白名单场地内的车辆数据
    val result4 = spark.sqlContext.sql(
      """select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.srcZoneCode as srcZoneCode,  a.destPlanArriveTm as preArriveTm,  a.destZoneCode as preArriveZoneCode,0 as tickets,0 as weight, 1 as status,'"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,nvl(srcPlanDepartTm,srcpredeparttm) as sendtime,lineCode from require_task_301 a join transit_info_tmp b on a.destZoneCode = b.deptCode where destZoneCode is not null""")
    //result4 【未发车】的目的地在白名单内的车辆数据
    val result6 = spark.sqlContext.sql(
      """select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.srcZoneCode as srcZoneCode, a.thirdPlanArriveTm as preArriveTm, a.thirdZoneCode as preArriveZoneCode,0 as tickets,0 as weight, 1 as status,'"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,nvl(srcPlanDepartTm,srcpredeparttm) as sendtime,lineCode from require_task_301 a join transit_info_tmp b on a.thirdZoneCode = b.deptCode where a.thirdZoneCode is not null and a.thirdJobType <> '1' """)
    //result6 【未发车】的第二个途径网点在白名单内的车辆数据
    //dropDuplicates 指定列相同时去重  目的地网点或者途径网点在白名单内的【未发车】数据
    val lastResult1 = result1.union(result4).union(result6).dropDuplicates("requireId","srcZoneCode","preArriveZoneCode")
    // requireTask302 【o-1段未发】车辆在途数据(发车网点--第一个途径网点之间)  实际发车时间>0 途径1发车时间为null 车辆在途  second发车时间为null
    val requireTask302 = spark.sqlContext.sql(
      """
        |select * from new_require_task_info where carStatus in (1,2,3,4,5) and srcActualDepartTm >0 and secondActualDepartTm is null""".stripMargin)
    requireTask302.createOrReplaceTempView("require_task_302")
    spark.sqlContext.cacheTable("require_task_302")
    //result21 【o-1段未发】确保途经点2在白名单,途经点1不为null
    val result21 = spark.sqlContext.sql("""select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.secondZoneCode as srcZoneCode, a.thirdPlanArriveTm as preArriveTm,a.thirdZoneCode as preArriveZoneCode,0 as tickets,0 as weight,1 as status,'"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate ,nvl(secondplandeparttm,secondpredeparttm) as sendtime,lineCode from require_task_302 a join transit_info_tmp b on a.thirdZoneCode = b.deptCode where a.secondZoneCode is not null and a.thirdZoneCode is not null and a.thirdJobType <> '1'""")
    //result23 【o-1段未发】确保目的地在白名单,途经点1不为null
    val result23 = spark.sqlContext.sql("""select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.secondZoneCode as srcZoneCode,  a.destPlanArriveTm as preArriveTm, a.destZoneCode as preArriveZoneCode,0 as tickets,0 as weight, 1 as status,'"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,nvl(secondplandeparttm,secondpredeparttm) as sendtime,lineCode from require_task_302 a join transit_info_tmp b on a.destZoneCode = b.deptCode where a.secondZoneCode is not null and a.destZoneCode is not null""")
    //lastResult2 【o-1段未发】确保途经点2+目的地在白名单
    val lastResult2 = result21.union(result23).dropDuplicates("requireId","srcZoneCode","preArriveZoneCode")
    //require_task_303 【1-2段未发】
    val requireTask303 = spark.sqlContext.sql("""select * from new_require_task_info where carStatus in (1,2,3,4,5) and srcActualDepartTm >0 and secondActualDepartTm >0 and thirdActualDepartTm is null""")
    requireTask303.createOrReplaceTempView("require_task_303")
    //result31 【1-2段未发】 目的地在白名单
    val result31 = spark.sqlContext.sql("""select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.thirdZoneCode as srcZoneCode,a.destPlanArriveTm as preArriveTm,a.destZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,1 as status,'"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,nvl(thirdplandeparttm,thirdpredeparttm) as sendtime,lineCode from require_task_303 a join transit_info_tmp b on a.destZoneCode = b.deptCode where a.thirdZoneCode is not null and a.destZoneCode is not null""")
    val lastResult3 = result31.dropDuplicates("requireId","srcZoneCode","preArriveZoneCode")
    //lr 【全程未发union  0-1-2】 目的地在白名单
    val lr = lastResult1.union(lastResult2).union(lastResult3)
      .selectExpr("requireId","carNo","transLevel","carStatus","srcZoneCode","FROM_UNIXTIME(int(sendTime/1000)) as sendTime","FROM_UNIXTIME(int(preArriveTm/1000)) as preArriveTm",
        "preArriveZoneCode","tickets","weight","status","countTime","countDate","lineCode")
      .where($"srcZoneCode" =!= $"preArriveZoneCode")

    val count1 = lr.count()
    print("全程未发数据共 "+count1+" 条")

    //todo 归集班次
    val lrWithBatch = getBatchInfo(lr, spark).withColumn("version_id", lit(versionId))

    //写入tidb   dws_sf_dept_sx_vehicle_sum  appendx写入
    TidbUtil.write("t_monitor_in_road_cargo_big",lrWithBatch)

    /*CacheUtil.updateTMonitorDetailData("t_monitor_in_road_cargo_big",new Timestamp(System.currentTimeMillis()),1)
    //将结果写入表 t_monitor_in_road_cargo_big
    TidbUtil.write("t_monitor_in_road_cargo_big",lr1,SaveMode.Overwrite)*/
    spark.sqlContext.uncacheTable("require_task_301")
    spark.sqlContext.uncacheTable("require_task_302")

    println("1:未发车辆计算完毕")
    println("2:开始计算在途")
    //Y 1.0去重
    spark.sqlContext.uncacheTable("require_task_301")
    spark.sqlContext.uncacheTable("require_task_302")

    println("1:未发车辆计算完毕")
    println("2:开始计算在途")
    //Y 1.0去重
    val requireTaskInRoad = requireTaskDf1
      .where("inc_day >= '"+last3Day+"'" )
      .withColumn("rn", row_number().over(w))
      .where($"rn" === 1).drop("rn")
    requireTaskInRoad.createOrReplaceTempView("new_require_task_info2")
    //Y 保留近七天数据 in_road_cars 近7天跟新的车辆数据
    val inRoad = spark.sqlContext.sql("" +
      "select * from new_require_task_info2 " +
      "where carStatus in (1,2,3,4,5) and lastUpdateTm > " +  DateUtil.getTime(7))
    inRoad.createOrReplaceTempView("in_road_cars")
    spark.sqlContext.cacheTable("in_road_cars")
    //in_road_cars_first 【o-1在途】且经过途经点1，途经点2为空，目的地为空
    val inFirst = spark.sqlContext.sql(""" select * from in_road_cars where srcActualDepartTm >0 and secondZoneCode is not null and secondActualArriveTm is null and thirdActualArriveTm is null and destActualArriveTm is null and secondJobType <> '1'""")
    inFirst.createOrReplaceTempView("in_road_cars_first")
    //【o-1在途】 车标
    val inFirstCarNos = spark.sqlContext.sql("""select requireId, adTable.carNo as carNo,translevel,carStatus,srcZoneCode, secondZoneCode as preArriveZoneCode,coalesce(nextzonecodedynamicprearrivetime,secondPreArriveTm,secondPlanArriveTm) as preArriveTm,srcActualDepartTm as sendTime,lineCode from in_road_cars_first  LATERAL VIEW explode(split(secondArriveContnrNos, ',')) adTable AS carNo""")
    //in_road_cars_second 【o-d 不经过途经点的车辆在途数据】
    val inSecond = spark.sqlContext.sql("""select * from in_road_cars where srcActualDepartTm >0 and secondZoneCode is null and secondActualArriveTm is null and thirdActualArriveTm is null and destActualArriveTm is null and destZoneCode is not null""")
    inSecond.createOrReplaceTempView("in_road_cars_second")
    //【o-d在途】 车标
    val inSecondCarNos = spark.sqlContext.sql("""select requireId, adTable.carNo as carNo,translevel,carStatus,srcZoneCode, destZoneCode as preArriveZoneCode ,coalesce(nextzonecodedynamicprearrivetime,destPreArriveTm,destPlanArriveTm) as preArriveTm ,srcActualDepartTm as sendTime,lineCode from in_road_cars_second  LATERAL VIEW explode(split(destArriveContnrNos, ',')) adTable AS carNo""")
    //【1-2在途】 车辆数据
    val inThird = spark.sqlContext.sql("" +
      " select * " +
      " from in_road_cars " +
      " where srcActualDepartTm >0 and secondZoneCode is not null and secondActualDepartTm > 0 " +
      " and thirdZoneCode is not null and thirdActualArriveTm is null and destActualArriveTm is null and thirdJobType <> '1'")
    inThird.createOrReplaceTempView("in_road_cars_third")
    //【1-2在途】 车标
    val inThirdCarNos = spark.sqlContext.sql("""select requireId, adTable.carNo as carNo,translevel,carStatus, secondZoneCode as srcZoneCode,thirdZoneCode as preArriveZoneCode, coalesce(nextzonecodedynamicprearrivetime,thirdPreArriveTm,thirdPlanArriveTm) as preArriveTm ,secondActualDepartTm as sendTime,lineCode from in_road_cars_third LATERAL VIEW explode(split(thirdArriveContnrNos, ',')) adTable AS carNo""")
    //【1-d在途】 车辆数据
    val inForth = spark.sqlContext.sql("" +
      " select * from in_road_cars " +
      " where srcActualDepartTm >0 and secondZoneCode is not null and secondActualDepartTm > 0 " +
      " and thirdZoneCode is null and destActualArriveTm is null and destZoneCode is not null")
    inForth.createOrReplaceTempView("in_road_cars_forth")
    //【1-d在途】 车标
    val inForthCarNos = spark.sqlContext.sql(""" select requireId, adTable.carNo as carNo,translevel,carStatus,secondZoneCode as srcZoneCode,destZoneCode as preArriveZoneCode , coalesce(nextzonecodedynamicprearrivetime,destPreArriveTm,destPlanArriveTm) as preArriveTm ,secondActualDepartTm as sendTime,lineCode from in_road_cars_forth  LATERAL VIEW explode(split(destArriveContnrNos, ',')) adTable AS carNo""")
    //【2-d在途】 车辆数据
    val inFiveth = spark.sqlContext.sql("select * from in_road_cars " +
      " where srcActualDepartTm >0 and thirdZoneCode is not null and thirdActualDepartTm > 0  " +
      " and destActualArriveTm is null and destZoneCode is not null")
    inFiveth.createOrReplaceTempView("in_road_cars_five")
    val inFivethCarNos = spark.sqlContext.sql("" +
      " select requireId, adTable.carNo as carNo,translevel,carStatus,thirdZoneCode as srcZoneCode,destZoneCode as preArriveZoneCode ," +
      " coalesce(nextzonecodedynamicprearrivetime,destPreArriveTm,destPlanArriveTm) as preArriveTm ,thirdActualDepartTm as sendTime,lineCode " +
      " from in_road_cars_five " +
      " LATERAL VIEW explode(split(destArriveContnrNos, ',')) adTable AS carNo")
    val inAllCarNos = inFirstCarNos.union(inSecondCarNos).union(inThirdCarNos).union(inForthCarNos).union(inFivethCarNos)
    inAllCarNos.createOrReplaceTempView("in_all_car_nos")
    //所有白名单车标
    val sfAllCarNos = spark.sqlContext.sql(""" select a.* from in_all_car_nos a join transit_info_tmp b on a.preArriveZoneCode = b.deptCode where carNo is not null and carNo <> '' """)
    val inNotCarNos = spark.sqlContext.sql(""" select a.* from in_all_car_nos a join transit_info_tmp b on a.preArriveZoneCode = b.deptCode where carNo is null or carNo = '' """)

   val f1 = sfAllCarNos.rdd.mapPartitions(f=>{
      val hbase = HbaseUtil.getInstance()
      f.map(r=>{
        val requireId = r.getAs[String]("requireId")
        val carNo = r.getAs[String]("carNo")
        val translevel = r.getAs[Integer]("translevel")
        val carStatus = r.getAs[Integer]("carStatus")
        val srcZoneCode = r.getAs[String]("srcZoneCode")
        val preArriveZoneCode = r.getAs[String]("preArriveZoneCode")
        val preArriveTm = r.getAs[Long]("preArriveTm")
        val sendTime = r.getAs[Long]("sendTime")
        val lineCode = r.getAs[String]("lineCode")
        val rowKey = r.getAs[String]("carNo").reverse

        //TODO 通过HBase获取 rt_container_waybill_relation 【车标运单关系维表】 --保留15kg+的运单
        val rtContrnRes = hbase.getRow("rt_container_waybill_relation", Bytes.toBytes(rowKey))
        //数据格式: baseInfo:SF2060933170912 {"createZoneCode":"025WH","waybillType":"10","removeZoneCode":"516WH","isDeleted":0,"createTm":1642637716241,"dataStatus":1,"jobType":"31","inferStatus":0}
        var listRow = new ArrayBuffer[Row]()

        if (rtContrnRes != null && !rtContrnRes.isEmpty) {
          val cells = rtContrnRes.listCells().asScala
          val getList = new util.ArrayList[String]()
          var columns = new util.HashMap[String,ColumnType]()
          for(cell <- cells){
            val waybillNo = Bytes.toString(CellUtil.cloneQualifier(cell))
            val waybillJson = JSON.parseObject(Bytes.toString(CellUtil.cloneValue(cell)))
            val jobType = waybillJson.getString("jobType")
            if (StringUtils.isNotEmpty(waybillNo)&&jobType.equals("30") && waybillJson.getInteger("isDeleted") == 0){
              //val get = new Get(Bytes.toBytes(waybillNo.reverse))
              //get.addColumn(Bytes.toBytes("baseInfo"), Bytes.toBytes("packageMeterageWeightQty"))
              getList.add(waybillNo)
              columns.put("packageMeterageWeightQty",ColumnType.DOUBLE)
            }
          }
          //val result = hbase.getList("wb_info_data",getList.toList.asJava)
          val hrs = hbase.getListSpecialForWbInfo(getList, columns);
          for(waybillResult <- hrs.entrySet().asScala; if hrs!=null && !hrs.isEmpty) {
            var weight = 0D
            var ticket = 0L
            var waybillNo = ""
            if(waybillResult !=null){
              waybillNo = waybillResult.getKey
              val wCells = waybillResult.getValue
              for(wCell <- wCells.entrySet().asScala) {
                weight = wCell.getValue.asInstanceOf[Double]
                //TODO 运单筛选
                if (weight >= 15D) {
                  if(weight > 1000000D){
                    weight = 1000000D
                  }
                  ticket = 1L
                } else{
                  weight = 0D
                }
              }
            }
            listRow += Row(requireId,carNo,translevel,carStatus,srcZoneCode,sendTime,preArriveTm,preArriveZoneCode,waybillNo,ticket,weight,lineCode)
          }
        }else{
          listRow += Row(requireId,carNo,translevel,carStatus,srcZoneCode,sendTime,preArriveTm,preArriveZoneCode,null,0L,0D,lineCode)
        }
        listRow.toArray
      }).flatMap(r=>r.iterator)
    })
    val structFields = Array(
      StructField("requireId", StringType, true),  StructField("carNo", StringType, true),            StructField("transLevel", IntegerType, true),
      StructField("carStatus", IntegerType, true), StructField("srcZoneCode", StringType, true),      StructField("sendTime", LongType, true),
      StructField("preArriveTm", LongType, true),StructField("preArriveZoneCode", StringType, true),StructField("waybillNo", StringType, true),
      StructField("tickets", LongType, true),      StructField("weight", DoubleType, true),           StructField("lineCode", StringType, true))
    val structType = StructType(structFields)
    val f1Df = spark.createDataFrame(f1, structType)
    f1Df.createOrReplaceTempView("f1Df")

    //获取快管修改车辆预计到达时间
    val kgTableName = "(select require_id,zone_code,next_zone_code,prologis_in_tm from t_transportct_info where prologis_in_tm is not null ) as t"
    val kgData = KgMysqlUtil.read(kgTableName,spark.sqlContext)
    kgData.createOrReplaceTempView("kg_data")

    val f1DfAfterProcess = spark.sqlContext.sql("select * from (select requireId,transLevel,carStatus,srcZoneCode,preArriveTm,preArriveZoneCode,sum(tickets) over(partition by requireId,preArriveZoneCode) as tickets,sum(weight) over(partition by requireId,preArriveZoneCode) as weight,row_number() over(partition by requireId,preArriveZoneCode order by preArriveTm desc) as num,sendTime,lineCode from f1Df )t where t.num = 1").drop("num")
    f1DfAfterProcess.createOrReplaceTempView("in_road_total")
    val inTotal = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel,               carStatus, srcZoneCode, case when b.prologis_in_tm is null then preArriveTm else unix_timestamp(b.prologis_in_tm,'yyyy-MM-dd HH:mm:ss')*1000 end as preArriveTm, preArriveZoneCode,      tickets,      weight, 2 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,sendTime,lineCode from in_road_total a left join kg_data b on a.requireId = b.require_id and a.srcZoneCode = b.zone_code and a.preArriveZoneCode = b.next_zone_code""")
    inNotCarNos.createOrReplaceTempView("in_not_carno_cars")
    val inTotal2 = spark.sqlContext.sql("""select requireId,"" as carNo, translevel as transLevel, carStatus, srcZoneCode, case when b.prologis_in_tm is null then preArriveTm else unix_timestamp(b.prologis_in_tm,'yyyy-MM-dd HH:mm:ss')*1000 end as preArriveTm, preArriveZoneCode, 0 as tickets, 0 as weight, 2 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,sendTime,lineCode from in_not_carno_cars  a left join kg_data b on a.requireId = b.require_id and a.srcZoneCode = b.zone_code and a.preArriveZoneCode = b.next_zone_code""").dropDuplicates("requireId","srcZoneCode", "preArriveZoneCode")
    val inTotalAll = inTotal.union(inTotal2)
      .selectExpr("requireId","carNo","transLevel","carStatus","srcZoneCode","FROM_UNIXTIME(int(sendTime/1000)) as sendTime","FROM_UNIXTIME(int(preArriveTm/1000)) as preArriveTm",
        "preArriveZoneCode","tickets","weight","status","countTime","countDate","lineCode","version_id")
      .where($"srcZoneCode" =!= $"preArriveZoneCode")
    val count2 = inTotalAll.count()
    //inTotalAll.createOrReplaceTempView("inTotalAll")
    //TODO 写入Tidb表
    //spark.sqlContext.sql("""insert into table dm_heavy_cargo.dwd_t_monitor_in_road_cargo_big partition(inc_day='"""+ countDate +"""',inc_min='"""+ countTime + """') select requireId as require_id,carNo as car_no,transLevel,carStatus as car_status,srcZoneCode as src_zone_code, preArriveTm as pre_arrive_tm,preArriveZoneCode as pre_arrive_zone_code,tickets,weight,status,countTime as count_time,countDate as count_date,sendTime,lineCode from inTotalAll""")

    //归集班次
    val inTotalAllWithBatch = getBatchInfo(inTotalAll, spark).withColumn("version_id", lit(versionId))
    TidbUtil.write("t_monitor_in_road_cargo_big",inTotalAllWithBatch)

    spark.sqlContext.uncacheTable("in_road_cars")
    println("3:在途货量计算完毕")

    println("4:开始计算已到达")
    //TODO 修改车辆到达表
    val hasArriveTaskDf = CarInfo.getVehicleBigHasArriveTaskInfo(spark.sqlContext,DateUtil.getLastHoursTime(24),1)
    hasArriveTaskDf.createOrReplaceTempView("has_arrive_cars")
    val hasArriveTotalPre = spark.sqlContext.sql("select * from (select requireId as requireId,transLevel as translevel,carStatus as carStatus,srcZoneCode as srcZoneCode,actualTime as preArriveTm,destZoneCode as preArriveZoneCode,sum(ticket) over(partition by requireId,destZoneCode) as tickets,sum(weight) over(partition by requireId,destZoneCode) as weight,row_number() over(partition by requireId,destZoneCode order by actualTime) as num,sendTime,lineCode from has_arrive_cars )t where t.num = 1").drop("num")
    hasArriveTotalPre.createOrReplaceTempView("has_arrive_total")
    val hasArriveTotal = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus, srcZoneCode, preArriveTm, preArriveZoneCode, tickets, weight, 3 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate, sendTime,lineCode from has_arrive_total """)
    //补充已到达车辆没有车标的情况
    requireTaskDf1.withColumn("rn", row_number().over(w)).where($"rn" === 1).drop("rn").createOrReplaceTempView("last_day_car_info")
    val hasArrive1 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus,                  srcZoneCode, secondActualArriveTm as preArriveTm,secondZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,    srcActualDepartTm as sendTime ,lineCode from last_day_car_info where (carNo is null or carNo = '') and srcActualDepartTm > 0 and secondActualArriveTm > 0 and secondActualDepartTm is null""")
    val hasArrive2 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus,secondZoneCode as srcZoneCode,  thirdActualArriveTm as preArriveTm, thirdZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate, secondActualDepartTm as sendTime ,lineCode from last_day_car_info where (carNo is null or carNo = '') and secondActualDepartTm > 0 and thirdActualArriveTm > 0 and thirdActualDepartTm is null""")
    val hasArrive3 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus, thirdZoneCode as srcZoneCode,   destActualArriveTm as preArriveTm,  destZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,  thirdActualDepartTm as sendTime ,lineCode from last_day_car_info where (carNo is null or carNo = '') and thirdActualDepartTm > 0 and destActualArriveTm > 0 """)
    val hasArrive4 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus,secondZoneCode as srcZoneCode,   destActualArriveTm as preArriveTm,  destZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate, secondActualDepartTm as sendTime ,lineCode from last_day_car_info where (carNo is null or carNo = '') and secondActualDepartTm > 0 and thirdZoneCode is null and destActualArriveTm > 0""")
    val hasArrive5 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus,                  srcZoneCode,   destActualArriveTm as preArriveTm,  destZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,    srcActualDepartTm as sendTime ,lineCode from last_day_car_info where (carNo is null or carNo = '') and srcActualDepartTm > 0 and secondZoneCode is null and thirdZoneCode is null and destActualArriveTm > 0 """)
    val hasArriveTotalPre2 = hasArrive1.union(hasArrive2).union(hasArrive3).union(hasArrive4).union(hasArrive5).dropDuplicates("requireId","preArriveZoneCode")
    hasArriveTotalPre2.createOrReplaceTempView("has_arrive_total_pre2")
    val hasArriveTotal2 = spark.sqlContext.sql("""select a.* from has_arrive_total_pre2 a join transit_info_tmp b on a.preArriveZoneCode = b.deptCode""")
    hasArriveTotal.union(hasArriveTotal2).createOrReplaceTempView("has_arrive_all")
    val hasArriveResult = spark.sqlContext.sql("""select t.* from (select a.*,row_number() over(partition by requireId,preArriveZoneCode order by weight desc) as rn from has_arrive_all a)t where t.rn = 1 """).drop("rn")
      .selectExpr("requireId","carNo","transLevel","carStatus","srcZoneCode","FROM_UNIXTIME(int(sendTime/1000)) as sendTime","FROM_UNIXTIME(int(preArriveTm/1000)) as preArriveTm",
        "preArriveZoneCode","tickets","weight","status","countTime","countDate","lineCode","version_id")
      .where($"srcZoneCode" =!= $"preArriveZoneCode")
    println("4:已到达货量计算完毕")
    val count3 = hasArriveResult.count()

    //todo 归集班次写入tidb
    val hasArriveResultWithBatch = getBatchInfo(hasArriveResult, spark).withColumn("version_id", lit(versionId))
    TidbUtil.write("t_monitor_in_road_cargo_big",hasArriveResultWithBatch)

    val conn2 = TidbUtil.conn()
    val st2 = conn2.createStatement()
    val sql2 = "update pub_table_sync_version set version_id = " + versionId + ",sync_time = current_timestamp() where table_name = 't_monitor_in_road_cargo_big' "
    st2.executeUpdate(sql2)
    if (st2 != null) {
      st2.close()
    }
    if (conn2!=null) {
      conn2.close()
    }
    count = count1 + count2 + count3
    CacheUtil.insertTMonitorDataRows("t_monitor_in_road_cargo_big",new Timestamp(System.currentTimeMillis()),count)
  }


  def getBatchInfo(lr:DataFrame,spark:SparkSession): DataFrame ={
    val lrAndBatch = lr.rdd.mapPartitions(
      t => {
        //1.创建ES客户端连接池
        val factory = new JestClientFactory
        //2.创建ES客户端连接地址
//        val httpClientConfig = new HttpClientConfig.Builder("http://10.202.116.33:9200").build  //测试
        val serverUris:util.Set[String] = Collections.emptySet()
        serverUris.add("http://10.117.106.60:9200")
        serverUris.add("http://10.117.106.61:9200")
        serverUris.add("http://10.117.106.62:9200")
        val httpClientConfig = new HttpClientConfig.Builder(serverUris).build  //生产
        //3.设置ES连接地址
        factory.setHttpClientConfig(httpClientConfig)
        val connect = ElasticSearchUtil.getConnect

        t.map(r => {
          val requireId = r.getAs[String]("requireId")
          val carNo = r.getAs[String]("carNo")
          val translevel = r.getAs[Integer]("translevel")
          val carStatus = r.getAs[Integer]("carStatus")
          val srcZoneCode = r.getAs[String]("srcZoneCode")
          val sendTime = r.getAs[String]("sendTime")
          val preArriveTm = r.getAs[String]("preArriveTm")
          val preArriveZoneCode = r.getAs[String]("preArriveZoneCode")
          val tickets = r.getAs[Long]("tickets")
          val weight = r.getAs[Double]("weight")
          val status = r.getAs[Integer]("status")
          val countTime = r.getAs[String]("countTime")
          val countDate = r.getAs[String]("countDate")
          val lineCode = r.getAs[String]("lineCode")

          val arrTmDay = preArriveTm.substring(0, 10) //2022-02-22
          val arrTmHHmm = preArriveTm.substring(11, 13).concat(preArriveTm.substring(14, 16)) //1550
          val formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
          val date = formatter.parse(preArriveTm)
          //工作日判断
          val cal = Calendar.getInstance
          cal.setTime(date)
          var week_index = cal.get(Calendar.DAY_OF_WEEK) - 1
          if (week_index < 0) week_index = 0

          //4.获取ES客户端连接
          val jestClient = factory.getObject
          //5.构建查询数据对象
          val search = new Search.Builder("{\"query\":{\"bool\":{\"must\":[" + "{\"term\":{\"zonecode\":\"" + preArriveZoneCode + "\"}}," +
            "{\"term\":{\"arrive_date\":\"" + week_index + "\"}}," + "{\"range\":{\"start_last_arr_tm\":{\"lte\":" + arrTmHHmm + "}}}," +
            "{\"range\":{\"last_arr_tm\":{\"gte\":" + arrTmHHmm + "}}}]}}}")
            .addIndex("dim_sf_batch_info").addType("dim_sf_batch_info").build
          //6.执行查询操作
          val searchResult = jestClient.execute(search)

          //7.解析查询结果
          /*val option = searchResult.getHits(classOf[Map[_, _]]).get(0).asInstanceOf[Map[String, Any]].get("_source")
          val str = option.asInstanceOf[Map[String, Any]].toString()*/

          val source = searchResult.getHits(classOf[Map[String, Any]]).get(0).source
          val batchCode = source.get("batch_code").asInstanceOf[String]
          val batchday = source.get("batch_date").asInstanceOf[Int]

          val batchDate = DateUtil.getLastDayString(arrTmDay, 0 - batchday)
          var listRow = new ArrayBuffer[Row]()

          listRow += Row(requireId, carNo, translevel, carStatus, srcZoneCode, sendTime, preArriveTm, preArriveZoneCode, tickets, weight, status,
            countTime, countDate, lineCode, batchCode, batchDate)
          listRow.toArray
        }).flatMap(r => r.iterator)
      })
    val structFields = Array(
      StructField("requireId", StringType, true),  StructField("carNo", StringType, true),            StructField("transLevel", IntegerType, true),
      StructField("carStatus", IntegerType, true), StructField("srcZoneCode", StringType, true),      StructField("sendTime", StringType, true),
      StructField("preArriveTm", StringType, true),StructField("preArriveZoneCode", StringType, true),StructField("tickets", LongType, true),
      StructField("weight", DoubleType, true),     StructField("status", IntegerType, true),          StructField("countTime", StringType, true),
      StructField("countDate", StringType, true),  StructField("lineCode", StringType, true),         StructField("batchCode", StringType, true),
      StructField("batchDate", StringType, true)
    )
    val structType = StructType(structFields)
    val frame = spark.createDataFrame(lrAndBatch, structType)
    return frame
  }
}

