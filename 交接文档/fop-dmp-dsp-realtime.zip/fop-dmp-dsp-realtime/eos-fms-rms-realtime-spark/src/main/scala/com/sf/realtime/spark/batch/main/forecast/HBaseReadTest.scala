package com.sf.realtime.spark.batch.main.forecast

import com.sf.realtime.hbase.HbaseUtil
import com.sf.realtime.hbase.common.ColumnType
import com.sf.realtime.spark.context.Context
import org.apache.hadoop.hbase.CellUtil
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{DoubleType, IntegerType, LongType, StringType, StructField, StructType}

import java.util
import scala.collection.JavaConverters._
import scala.collection.mutable.ArrayBuffer

/**
 * @Author 01419728
 * @Date 2022/2/20 22:01
 */
object HBaseReadTest {
  def main(args: Array[String]): Unit = {
    val spark = Context.getContext()
    val df = spark.sqlContext.sql(
      """
        |select "390221744494" as carNo
        |""".stripMargin)
    val value = df.rdd.map(r => {
      val carNo = r.getAs[String]("carNo")
      val rowKey = carNo.reverse
      val hbase = HbaseUtil.getInstance()
      val rtContrnRes = hbase.getRow("rt_container_waybill_relation", Bytes.toBytes(rowKey))
      println("查询rt_container_waybill_relation关联运单" + rowKey)
      val cells = rtContrnRes.listCells().asScala
      var listRow = new ArrayBuffer[Row]()
      //遍历整行,获取多个运单号
      if (rtContrnRes != null && !rtContrnRes.isEmpty) {
        val cells = rtContrnRes.listCells().asScala
        val getList = new util.ArrayList[String]()
        var columns = new util.HashMap[String, ColumnType]()
        for (cell <- cells) {
          val waybillNo = Bytes.toString(CellUtil.cloneQualifier(cell))
          getList.add(waybillNo)
          columns.put("packageMeterageWeightQty", ColumnType.DOUBLE)
        }
        //val result = hbase.getList("wb_info_data",getList.toList.asJava)
        println("开始查询运单表wb_info_data关联重量")
        val hrs = hbase.getListSpecialForWbInfo(getList, columns);
        println("查询完毕-----解析结果")
        for (waybillResult <- hrs.entrySet().asScala; if hrs != null && !hrs.isEmpty) {
          var weight = 0D
          var ticket = 0L
          var waybillNo = ""
          if (waybillResult != null) {
            waybillNo = waybillResult.getKey
            val wCells = waybillResult.getValue
            for (wCell <- wCells.entrySet().asScala) {
              weight = wCell.getValue.asInstanceOf[Double]
              if (weight >= 15D) {
                if(weight > 1000000D){
                  weight = 1000000D
                }
                ticket = 1L
              } else{
                weight = 0D
              }
            }
            print("carNo:" + carNo + "waybillNo:" + waybillNo + "weight:" + weight + "ticket:" + ticket)
            listRow += Row(carNo, ticket, weight, waybillNo)
          }
        }
      }
      listRow.toArray
    }).flatMap(r=>r.iterator)

    val structFields = Array(StructField("carNo", StringType, true),
    StructField("waybillNo", StringType, true),
      StructField("tickets", LongType, true),
      StructField("weight", DoubleType, true))
    val structType = StructType(structFields)
    val f1Df = spark.createDataFrame(value, structType)
    f1Df.show()
  }
}
