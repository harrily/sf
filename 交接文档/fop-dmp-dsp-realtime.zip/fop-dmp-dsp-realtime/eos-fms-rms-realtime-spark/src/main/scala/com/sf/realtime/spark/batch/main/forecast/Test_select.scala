package com.sf.realtime.spark.batch.main.forecast

import com.sf.realtime.common.utils.DateUtil
import com.sf.realtime.spark.context.Context
import com.sf.realtime.spark.utils.CloudTidbUtil
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.types._

import java.sql.Timestamp
import java.util.UUID

object Test_select {
 def main(args: Array[String]): Unit = {
    val spark = Context.getContext(true)
    val resultBatch =spark.sqlContext.sql(
      """ SELECT dept_code,trip_id,count_time FROM ky.dm_heavy_cargo.dm_cargo_quantity_handover_dtl_rt
        |where inc_day = '20230619' and inc_hour = '1300' limit 10 """.stripMargin)
   println("select success:"+resultBatch)
  }

}


