package com.sf.realtime.spark.batch.main.forecast

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.realtime.common.utils.RedisClusterPool
import com.sf.realtime.spark.context.Context
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}
import redis.clients.jedis.JedisCluster


/**
 * Spark-->Redis  加载运行时长
 */
object SfTransitRunTime {
  def main(args: Array[String]): Unit = {
    val spark: SparkSession = Context.getContext(true)
    val sql: String =
      """
        |select
        |   start_zone_code,
        |   end_zone_code,
        |   run_time
        |from stg_fop_sdm.t_site_run_time_info
        |""".stripMargin

    val frame: DataFrame = spark.sqlContext.sql(sql)
    val redisKey: Broadcast[String] = spark.sparkContext.broadcast[String]("kyExpectArriveTime")

    frame.toJSON.foreachPartition((it: Iterator[String]) => {
      if (it.nonEmpty) {
        val jedis: JedisCluster = RedisClusterPool.getConn
        it.foreach((data: String) => {
          if (data.nonEmpty) {
            val content: JSONObject = JSON.parseObject(data)
            val start_zone_code: String = content.getString("start_zone_code")
            val end_zone_code: String = content.getString("end_zone_code")
            val run_time: String = content.getString("run_time")
            val value = new JSONObject()
            value.put("start_zone_code", start_zone_code)
            value.put("end_zone_code", end_zone_code)
            value.put("run_time", run_time)
           // jedis set(redisKey, value.toJSONString)
          }
        })
      }
    })

  }
}
