package com.sf.realtime.spark.sql

import com.sf.realtime.common.utils.DateUtil
import com.sf.realtime.spark.context.Context
import com.sf.realtime.spark.utils.{SqlUtil, TidbUtil}
import org.apache.spark.sql.{DataFrame, SQLContext}

object CargoInfo {
  def getCargoInfo(sc: SQLContext, dateCondition:String, beforeDays:Integer):DataFrame = {
    val sql = """(select * from tbl_car_cargo_data_five where modifyTime > '""" + dateCondition + """') as t"""

    val predicates = SqlUtil.getReadMysqlPartitionByHourString(dateCondition,8, beforeDays).map{case (start, end) =>
      s"modifyTime > '$start' and modifyTime <= '$end'"}
    TidbUtil.read(sql, sc, predicates)
  }
  def getCargoInfoForUpCar(sc: SQLContext, dateStart:String,dateEnd:String):DataFrame = {
    val sql = """(select * from tbl_car_cargo_data_five where modifyTime > '""" + dateStart + """' and modifyTime <= '""" + dateEnd + """' and inputCode = '30') as t"""
    TidbUtil.read(sql, sc)
  }

  def getCargoInfoForOutCar(sc: SQLContext, dateStart:String,dateEnd:String):DataFrame = {
    val sql = """(select * from tbl_car_cargo_data_five where modifyTime > '""" + dateStart + """' and modifyTime <= '""" + dateEnd + """' and inputCode in ('30','31')) as t"""
    TidbUtil.read(sql, sc)
  }

  def getCargoInfoForCargoCount(sc: SQLContext, dateCondition:String, beforeDays:Integer):DataFrame = {
    val sql = """(select * from tbl_car_cargo_data_five where inputCode in ('30','31') and modifyTime > '"""+dateCondition+"""') as t"""

    val predicates = SqlUtil.getReadMysqlPartitionByHourString(dateCondition,8, beforeDays).map{case (start, end) =>
      s"modifyTime > '$start' and modifyTime <= '$end'"}
    TidbUtil.read(sql, sc, predicates)
  }

  def getCargoInfoForCarCount(sc: SQLContext, dateCondition:String, beforeDays:Integer):DataFrame = {
    val sql = """(select * from tbl_car_cargo_data_five where inputCode in ('30','31' '36')  and modifyTime > '"""+dateCondition+"""') as t"""

    val predicates = SqlUtil.getReadMysqlPartitionByHourString(dateCondition,24, beforeDays).map{case (start, end) =>
      s"modifyTime > '$start' and modifyTime <= '$end'"}
    TidbUtil.read(sql, sc, predicates)
  }

  def getCargoInfoForCarUnLoad(sc: SQLContext, dateCondition:String):DataFrame = {
    val sql = """(select zoneCode,carNo,count(distinct(packageNo)) as hasUnLoadPiece, min(modifyTime) as unLoadStartTime,max(modifyTime) as unLoadEndTime from tbl_car_cargo_data_five where inputCode ='31'and modifyTime > '"""+dateCondition+"""' group by zoneCode,carNo) as t"""
    TidbUtil.read(sql, sc)
  }

  def getFvpInfo(sc:SQLContext, dateCondition:String):DataFrame = {
    val sql = """(SELECT * FROM fmsrms.tbl_car_cargo_data_five WHERE modifyTime> '""" + dateCondition + """') as t"""

    val predicates = SqlUtil.getReadMysqlPartitionByHourString(dateCondition, 8, 3).map{
      case(start, end) =>  s"modifyTime > '$start' and modifyTime <= '$end'"
    }
    TidbUtil.read(sql, sc, predicates)
  }

  def getLoadRate(sc:SQLContext):DataFrame ={
    val sql = """(SELECT requiredId, zoneCode, totalWeight FROM fmsrms.t_monitor_ky_LoadRate) as t"""
    TidbUtil.read(sql, sc)
  }

  def main(args: Array[String]): Unit = {
    val spark = Context.getContext()
    getCargoInfoForCargoCount(spark.sqlContext,DateUtil.getDateString(3),3).show()
  }
}
