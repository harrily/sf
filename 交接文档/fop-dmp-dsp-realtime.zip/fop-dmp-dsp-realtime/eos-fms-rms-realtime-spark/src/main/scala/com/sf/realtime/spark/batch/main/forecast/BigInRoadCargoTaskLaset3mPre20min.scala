package com.sf.realtime.spark.batch.main.forecast


import com.sf.realtime.common.utils.DateUtil
import com.sf.realtime.spark.context.Context
import com.sf.realtime.spark.sql.{CarInfo, DeptInfo}
import com.sf.realtime.spark.utils.{CacheUtil, KgMysqlUtil, TidbUtil}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{count, row_number, sum}

/**
 * @Author 01419728
 * @Date 2022/2/14 13:56
 */
object BigInRoadCargoTaskLaset3mPre20min {

  def main(args: Array[String]): Unit = {


    val spark = Context.getContext(true)
    val transitDf = DeptInfo.getBigNewDeptInfo(spark.sqlContext)
    var countAll = 0L
    transitDf.createOrReplaceTempView("transit_info_tmp")
    val countTime = args(0) //业务时间,也就是每20分钟  统计时间"yyyy-MM-dd HH:mm:ss"
    val countDate = DateUtil.df2Todf3(countTime) //统计时间"yyyyMMdd"

    val last4Date = DateUtil.getLastDayStringdf3(countDate, 4)


    //取数区间是inc_day between last30 and countDate并且lastupdate < counttime
    val countTimeStamp = DateUtil.getTimeWithHms(countTime) //统计时间"yyyy-MM-dd HH:mm:ss"
    val last30Day = DateUtil.getLastDayStringdf3(countDate, 30)
    val last3Day = DateUtil.getLastDayStringdf3(countDate, 3)
    val last7Day = DateUtil.getLastTimeStamp(countTime, 7)

    val requireTaskDf1 = spark.sqlContext.sql("""select
case when idKey = 'null' then null else idKey end as idKey,
case when requireId = 'null' then null else requireId end as requireId,
case when translevel = 'null' then null else cast(translevel as int) end as translevel,
case when carNo = 'null' then null else carNo end as carNo,
case when lineCode = 'null' then null else lineCode end as lineCode,
case when carStatus = 'null' then null else cast(carStatus as int) end as carStatus,
case when lastUpdateTm = 'null' then null else cast(lastUpdateTm as bigint) end as lastUpdateTm,
case when srcZoneCode = 'null' then null else srcZoneCode end as srcZoneCode,
case when srcPlanReachTm = 'null' then null else cast(srcPlanReachTm as bigint) end as srcPlanReachTm,
case when srcPlanDepartTm = 'null' then null else cast(srcPlanDepartTm as bigint) end as srcPlanDepartTm,
case when srcActualDepartTm = 'null' then null else cast(srcActualDepartTm as bigint) end as srcActualDepartTm,
case when srcPreDepartTm = 'null' then null else cast(srcPreDepartTm as bigint) end as srcPreDepartTm,
case when srcPlanArriveTm = 'null' then null else cast(srcPlanArriveTm as bigint) end as srcPlanArriveTm,
case when srcActualArriveTm = 'null' then null else cast(srcActualArriveTm as bigint) end as srcActualArriveTm,
case when srcPreArriveTm = 'null' then null else cast(srcPreArriveTm as bigint) end as srcPreArriveTm,
case when secondZoneCode = 'null' then null else secondZoneCode end as secondZoneCode,
case when secondPlanReachTm = 'null' then null else cast(secondPlanReachTm as bigint) end as secondPlanReachTm,
case when secondPlanDepartTm = 'null' then null else cast(secondPlanDepartTm as bigint) end as secondPlanDepartTm,
case when secondActualDepartTm = 'null' then null else cast(secondActualDepartTm as bigint) end as secondActualDepartTm,
case when secondPreDepartTm = 'null' then null else cast(secondPreDepartTm as bigint) end as secondPreDepartTm,
case when secondPlanArriveTm = 'null' then null else cast(secondPlanArriveTm as bigint) end as secondPlanArriveTm,
case when secondActualArriveTm = 'null' then null else cast(secondActualArriveTm as bigint) end as secondActualArriveTm,
case when secondPreArriveTm = 'null' then null else cast(secondPreArriveTm as bigint) end as secondPreArriveTm,
case when thirdZoneCode = 'null' then null else thirdZoneCode end as thirdZoneCode,
case when thirdPlanReachTm = 'null' then null else cast(thirdPlanReachTm as bigint) end as thirdPlanReachTm,
case when thirdPlanDepartTm = 'null' then null else cast(thirdPlanDepartTm as bigint) end as thirdPlanDepartTm,
case when thirdActualDepartTm = 'null' then null else cast(thirdActualDepartTm as bigint) end as thirdActualDepartTm,
case when thirdPreDepartTm = 'null' then null else cast(thirdPreDepartTm as bigint) end as thirdPreDepartTm,
case when thirdPlanArriveTm = 'null' then null else cast(thirdPlanArriveTm as bigint) end as thirdPlanArriveTm,
case when thirdActualArriveTm = 'null' then null else cast(thirdActualArriveTm as bigint) end as thirdActualArriveTm,
case when thirdPreArriveTm = 'null' then null else cast(thirdPreArriveTm as bigint) end as thirdPreArriveTm,
case when destZoneCode = 'null' then null else destZoneCode end as destZoneCode,
case when destPlanReachTm = 'null' then null else cast(destPlanReachTm as bigint) end as destPlanReachTm,
case when destPlanDepartTm = 'null' then null else cast(destPlanDepartTm as bigint) end as destPlanDepartTm,
case when destActualDepartTm = 'null' then null else cast(destActualDepartTm as bigint) end as destActualDepartTm,
case when destPreDepartTm = 'null' then null else cast(destPreDepartTm as bigint) end as destPreDepartTm,
case when destPlanArriveTm = 'null' then null else cast(destPlanArriveTm as bigint) end as destPlanArriveTm,
case when destActualArriveTm = 'null' then null else cast(destActualArriveTm as bigint) end as destActualArriveTm,
case when destPreArriveTm = 'null' then null else cast(destPreArriveTm as bigint) end as destPreArriveTm,
case when insertTime = 'null' then null else cast(insertTime as timestamp) end as insertTime,
case when fullLoadWeight = 'null' then null else cast(fullLoadWeight as double) end as fullLoadWeight,
case when srcLoadContnrNos = 'null' then null else srcLoadContnrNos end as srcLoadContnrNos,
case when srcArriveContnrNos = 'null' then null else srcArriveContnrNos end as srcArriveContnrNos,
case when srcUnloadContnrNos = 'null' then null else srcUnloadContnrNos end as srcUnloadContnrNos,
case when secondLoadContnrNos = 'null' then null else secondLoadContnrNos end as secondLoadContnrNos,
case when secondArriveContnrNos = 'null' then null else secondArriveContnrNos end as secondArriveContnrNos,
case when secondUnloadContnrNos = 'null' then null else secondUnloadContnrNos end as secondUnloadContnrNos,
case when thirdLoadContnrNos = 'null' then null else thirdLoadContnrNos end as thirdLoadContnrNos,
case when thirdArriveContnrNos = 'null' then null else thirdArriveContnrNos end as thirdArriveContnrNos,
case when thirdUnloadContnrNos = 'null' then null else thirdUnloadContnrNos end as thirdUnloadContnrNos,
case when destLoadContnrNos = 'null' then null else destLoadContnrNos end as destLoadContnrNos,
case when destArriveContnrNos = 'null' then null else destArriveContnrNos end as destArriveContnrNos,
case when destUnloadContnrNos = 'null' then null else destUnloadContnrNos end as destUnloadContnrNos,
case when srcJobType = 'null' then null else srcJobType end as srcJobType,
case when secondJobType = 'null' then null else secondJobType end as secondJobType,
case when thirdJobType = 'null' then null else thirdJobType end as thirdJobType,
case when destJobType = 'null' then null else destJobType end as destJobType,
case when nextzonecodedynamicprearrivetime = 'null' then null else nextzonecodedynamicprearrivetime end as nextzonecodedynamicprearrivetime,
inc_day
from dm_heavy_cargo.rt_vehicle_task_monitor_for_not_send_detail4
where inc_day between '"""+last30Day+"""' and '"""+ countDate +"""' and lastUpdateTm <= '"""+ countTimeStamp +"""'""")

    val requireTaskDf = requireTaskDf1
    //requireTaskDf.createOrReplaceTempView("car_require_task_info")
    //3.取车辆任务的最新状态
    //Y3.1  近30天未发车辆数据  获取车辆任务的最新状态 new_require_task_info
    import spark.implicits._
    val w = Window.partitionBy($"requireId").orderBy($"lastUpdateTm".desc)
    val newRequireTaskDf = requireTaskDf.withColumn("rn", row_number().over(w)).where($"rn" === 1).drop("rn")
    newRequireTaskDf.createOrReplaceTempView("new_require_task_info")
    spark.sqlContext.cacheTable("new_require_task_info")

    //Y3.2 	实际发车时间为空  1待指派,2已指派,3待执行,4异常,5执行中,6已完成,7取消
    //[src未发车]
    val requireTask301 = spark.sqlContext.sql(
      """
        |select * from new_require_task_info where carStatus in (1,2,3,4,5) and srcActualDepartTm is null""".stripMargin)
    requireTask301.createOrReplaceTempView("require_task_301")
    spark.sqlContext.cacheTable("require_task_301")
    val result1 = spark.sqlContext.sql(
      """select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.srcZoneCode as srcZoneCode,a.secondPlanArriveTm as preArriveTm,a.secondZoneCode as preArriveZoneCode,0 as tickets,0 as weight, 1 as status,'"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,nvl(srcPlanDepartTm,srcpredeparttm) as send_time,lineCode as line_code from require_task_301 a join transit_info_tmp b on a.secondZoneCode = b.deptCode where a.secondZoneCode is not null and a.secondJobType <> '1'""")
    // result1 【未发车】的第一个途径网点在白名单场地内的车辆数据
    val result4 = spark.sqlContext.sql(
      """select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.srcZoneCode as srcZoneCode,  a.destPlanArriveTm as preArriveTm,  a.destZoneCode as preArriveZoneCode,0 as tickets,0 as weight, 1 as status,'"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,nvl(srcPlanDepartTm,srcpredeparttm) as send_time,lineCode as line_code from require_task_301 a join transit_info_tmp b on a.destZoneCode = b.deptCode where destZoneCode is not null""")
    //result4 【未发车】的目的地在白名单内的车辆数据
    val result6 = spark.sqlContext.sql(
      """select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.srcZoneCode as srcZoneCode, a.thirdPlanArriveTm as preArriveTm, a.thirdZoneCode as preArriveZoneCode,0 as tickets,0 as weight, 1 as status,'"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,nvl(srcPlanDepartTm,srcpredeparttm) as send_time,lineCode as line_code from require_task_301 a join transit_info_tmp b on a.thirdZoneCode = b.deptCode where a.thirdZoneCode is not null and a.thirdJobType <> '1' """)
    //result6 【未发车】的第二个途径网点在白名单内的车辆数据
    val lastResult1 = result1.union(result4).union(result6).dropDuplicates("requireId","srcZoneCode","preArriveZoneCode")

    // [second未发车]
    val requireTask302 = spark.sqlContext.sql(
      """
        |select * from new_require_task_info where carStatus in (1,2,3,4,5) and srcActualDepartTm >0 and secondActualDepartTm is null""".stripMargin)
    requireTask302.createOrReplaceTempView("require_task_302")
    spark.sqlContext.cacheTable("require_task_302")
    //result21 【src-second段未发】确保途经点2在白名单,途经点1不为null
    val result21 = spark.sqlContext.sql("""select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.secondZoneCode as srcZoneCode, a.thirdPlanArriveTm as preArriveTm,a.thirdZoneCode as preArriveZoneCode,0 as tickets,0 as weight,1 as status,'"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate ,nvl(secondplandeparttm,secondpredeparttm) as send_time,lineCode as line_code from require_task_302 a join transit_info_tmp b on a.thirdZoneCode = b.deptCode where a.secondZoneCode is not null and a.thirdZoneCode is not null and a.thirdJobType <> '1'""")
    //result23 【src-second段未发】确保目的地在白名单,途经点1不为null
    val result23 = spark.sqlContext.sql("""select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.secondZoneCode as srcZoneCode,  a.destPlanArriveTm as preArriveTm, a.destZoneCode as preArriveZoneCode,0 as tickets,0 as weight, 1 as status,'"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,nvl(secondplandeparttm,secondpredeparttm) as send_time,lineCode as line_code from require_task_302 a join transit_info_tmp b on a.destZoneCode = b.deptCode where a.secondZoneCode is not null and a.destZoneCode is not null""")
    //lastResult2 【src-second段未发】确保途经点2+目的地在白名单
    val lastResult2 = result21.union(result23).dropDuplicates("requireId","srcZoneCode","preArriveZoneCode")
    //[third未发]
    val requireTask303 = spark.sqlContext.sql("""select * from new_require_task_info where carStatus in (1,2,3,4,5) and srcActualDepartTm >0 and secondActualDepartTm >0 and thirdActualDepartTm is null""")
    requireTask303.createOrReplaceTempView("require_task_303")
    //result31 【second-third未发】 目的地在白名单
    val result31 = spark.sqlContext.sql("""select a.requireId as requireId,a.carNo as carNo,a.translevel as transLevel,a.carStatus as carStatus,a.thirdZoneCode as srcZoneCode,a.destPlanArriveTm as preArriveTm,a.destZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,1 as status,'"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,nvl(thirdplandeparttm,thirdpredeparttm) as send_time,lineCode as line_code from require_task_303 a join transit_info_tmp b on a.destZoneCode = b.deptCode where a.thirdZoneCode is not null and a.destZoneCode is not null""")
    val lastResult3 = result31.dropDuplicates("requireId","srcZoneCode","preArriveZoneCode")
    //lr 【全程未发union  0-1-2】 目的地在白名单
    val lr = lastResult1.union(lastResult2).union(lastResult3)
      .selectExpr("requireId","carNo","transLevel","carStatus","srcZoneCode","FROM_UNIXTIME(int(sendTime/1000)) as sendTime","FROM_UNIXTIME(int(preArriveTm/1000)) as preArriveTm",
          "preArriveZoneCode","tickets","weight","status","countTime","countDate","lineCode")
      .where($"srcZoneCode" =!= $"preArriveZoneCode")
    lr.createOrReplaceTempView("pre20minresult")
    val count1 = lr.count()
    print("全程未发数据共 "+count1+" 条")

    //todo 写入hive,按天按20分钟分区  缺少countTime和countDate
    spark.sqlContext.sql("""insert overwrite table dm_heavy_cargo.dwd_t_monitor_in_road_cargo_big partition(inc_day='"""+ countDate +"""') select
        | requireId as require_id,carNo as car_no,transLevel,carStatus as car_status,srcZoneCode as src_zone_code,send_time,
        | preArriveTm as pre_arrive_tm,preArriveZoneCode as pre_arrive_zone_code,tickets,weight,status,countTime as count_time,countDate as count_date,line_code
        | from pre20minresult""".stripMargin)

    //TidbUtil.write("t_monitor_in_road_cargo_big",lr,SaveMode.Overwrite)
    spark.sqlContext.uncacheTable("require_task_301")
    spark.sqlContext.uncacheTable("require_task_302")

    println("1:未发车辆计算完毕")
    println("2:开始计算在途")
    //Y 1.0去重
    val requireTaskInRoad = requireTaskDf1
      .where("inc_day >= '"+last3Day+"'" )
      .withColumn("rn", row_number().over(w))
      .where($"rn" === 1).drop("rn")
    requireTaskInRoad.createOrReplaceTempView("new_require_task_info2")
    //Y 保留近七天数据 in_road_cars 近7天跟新的车辆数据
    val inRoad = spark.sqlContext.sql("" +
      "select * from new_require_task_info2 " +
      "where carStatus in (1,2,3,4,5) and lastUpdateTm > " + last7Day)
    inRoad.createOrReplaceTempView("in_road_cars")
    spark.sqlContext.cacheTable("in_road_cars")
    //in_road_cars_first 【o-1在途】且经过途经点1，途经点2为空，目的地为空
    val inFirst = spark.sqlContext.sql(""" select * from in_road_cars where srcActualDepartTm >0 and secondZoneCode is not null and secondActualArriveTm is null and thirdActualArriveTm is null and destActualArriveTm is null and secondJobType <> '1'""")
    inFirst.createOrReplaceTempView("in_road_cars_first")
    //【o-1在途】 车标
    val inFirstCarNos = spark.sqlContext.sql("""select requireId, adTable.carNo as carNo,translevel,carStatus,srcZoneCode, secondZoneCode as preArriveZoneCode,coalesce(nextzonecodedynamicprearrivetime,secondPreArriveTm,secondPlanArriveTm) as preArriveTm,srcActualDepartTm as send_time,lineCode as line_code from in_road_cars_first  LATERAL VIEW explode(split(secondArriveContnrNos, ',')) adTable AS carNo""")
    //in_road_cars_second 【o-d 不经过途经点的车辆在途数据】
    val inSecond = spark.sqlContext.sql("""select * from in_road_cars where srcActualDepartTm >0 and secondZoneCode is null and secondActualArriveTm is null and thirdActualArriveTm is null and destActualArriveTm is null and destZoneCode is not null""")
    inSecond.createOrReplaceTempView("in_road_cars_second")
    //【o-d在途】 车标
    val inSecondCarNos = spark.sqlContext.sql("""select requireId, adTable.carNo as carNo,translevel,carStatus,srcZoneCode, destZoneCode as preArriveZoneCode ,coalesce(nextzonecodedynamicprearrivetime,destPreArriveTm,destPlanArriveTm) as preArriveTm ,srcActualDepartTm as send_time,lineCode as line_code from in_road_cars_second  LATERAL VIEW explode(split(destArriveContnrNos, ',')) adTable AS carNo""")
    //【1-2在途】 车辆数据
    val inThird = spark.sqlContext.sql("" +
      " select * " +
      " from in_road_cars " +
      " where srcActualDepartTm >0 and secondZoneCode is not null and secondActualDepartTm > 0 " +
      " and thirdZoneCode is not null and thirdActualArriveTm is null and destActualArriveTm is null and thirdJobType <> '1'")
    inThird.createOrReplaceTempView("in_road_cars_third")
    //【1-2在途】 车标
    val inThirdCarNos = spark.sqlContext.sql("""select requireId, adTable.carNo as carNo,translevel,carStatus, secondZoneCode as srcZoneCode,thirdZoneCode as preArriveZoneCode, coalesce(nextzonecodedynamicprearrivetime,thirdPreArriveTm,thirdPlanArriveTm) as preArriveTm ,secondActualDepartTm as send_time,lineCode as line_code from in_road_cars_third LATERAL VIEW explode(split(thirdArriveContnrNos, ',')) adTable AS carNo""")
    //【1-d在途】 车辆数据
    val inForth = spark.sqlContext.sql("" +
      " select * from in_road_cars " +
      " where srcActualDepartTm >0 and secondZoneCode is not null and secondActualDepartTm > 0 " +
      " and thirdZoneCode is null and destActualArriveTm is null and destZoneCode is not null")
    inForth.createOrReplaceTempView("in_road_cars_forth")
    //【1-d在途】 车标
    val inForthCarNos = spark.sqlContext.sql(""" select requireId, adTable.carNo as carNo,translevel,carStatus,secondZoneCode as srcZoneCode,destZoneCode as preArriveZoneCode , coalesce(nextzonecodedynamicprearrivetime,destPreArriveTm,destPlanArriveTm) as preArriveTm ,secondActualDepartTm as send_time,lineCode as line_code from in_road_cars_forth  LATERAL VIEW explode(split(destArriveContnrNos, ',')) adTable AS carNo""")
    //【2-d在途】 车辆数据
    val inFiveth = spark.sqlContext.sql("select * from in_road_cars " +
      " where srcActualDepartTm >0 and thirdZoneCode is not null and thirdActualDepartTm > 0  " +
      " and destActualArriveTm is null and destZoneCode is not null")
    inFiveth.createOrReplaceTempView("in_road_cars_five")
    val inFivethCarNos = spark.sqlContext.sql("" +
      " select requireId, adTable.carNo as carNo,translevel,carStatus,thirdZoneCode as srcZoneCode,destZoneCode as preArriveZoneCode ," +
      " coalesce(nextzonecodedynamicprearrivetime,destPreArriveTm,destPlanArriveTm) as preArriveTm ,thirdActualDepartTm as send_time,lineCode as line_code " +
      " from in_road_cars_five " +
      " LATERAL VIEW explode(split(destArriveContnrNos, ',')) adTable AS carNo")
    val inAllCarNos = inFirstCarNos.union(inSecondCarNos).union(inThirdCarNos).union(inForthCarNos).union(inFivethCarNos)
    inAllCarNos.createOrReplaceTempView("in_all_car_nos")
    //所有白名单车标
    val kyAllCarNos = spark.sqlContext.sql(""" select a.* from in_all_car_nos a join transit_info_tmp b on a.preArriveZoneCode = b.deptCode where carNo is not null and carNo <> '' """)
    val inNotCarNos = spark.sqlContext.sql(""" select a.* from in_all_car_nos a join transit_info_tmp b on a.preArriveZoneCode = b.deptCode where carNo is null or carNo = '' """)

    //TODO hive表关联   dim_freight.dim_container_waybill_info_di 【车标运单关系维表】 --保留15kg+的运单
    val carNoWaybilno = spark.sqlContext
      .sql("""select mainwaybillno,car_number,weight from dim_freight.dim_container_waybill_info_di where inc_day between '""" + DateUtil.getLastDayStringdf3(last30Day, 20) + """' and '""" + countDate + """'""")
      .where("weight>=15 and weight is not null")
      .dropDuplicates("mainwaybillno","car_number")
      .groupBy("car_number")
      .agg(sum("weight") as ("weight"), count("mainwaybillno") as ("tickets"))
      //left join 进行关联
      val f1Df = kyAllCarNos.join(carNoWaybilno, carNoWaybilno("car_number").equalTo(kyAllCarNos("carNo")),"left")
      f1Df.createOrReplaceTempView("f1Df")

    //获取快管修改车辆预计到达时间

    val kgTableName = "(select require_id,zone_code,next_zone_code,prologis_in_tm from t_transportct_info where prologis_in_tm is not null ) as t"
    val kgData = KgMysqlUtil.read(kgTableName,spark.sqlContext)
    kgData.createOrReplaceTempView("kg_data")

    val f1DfAfterProcess = spark.sqlContext.sql("select * from (select requireId,transLevel,carStatus,srcZoneCode,preArriveTm,preArriveZoneCode,sum(tickets) over(partition by requireId,preArriveZoneCode) as tickets,sum(weight) over(partition by requireId,preArriveZoneCode) as weight,row_number() over(partition by requireId,preArriveZoneCode order by preArriveTm desc) as num,send_time,line_code from f1Df )t where t.num = 1").drop("num")
    f1DfAfterProcess.createOrReplaceTempView("in_road_total")
    val inTotal = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel,               carStatus, srcZoneCode, case when b.prologis_in_tm is null then preArriveTm else unix_timestamp(b.prologis_in_tm,'yyyy-MM-dd HH:mm:ss')*1000 end as preArriveTm, preArriveZoneCode,      tickets,      weight, 2 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,send_time,line_code from in_road_total a left join kg_data b on a.requireId = b.require_id and a.srcZoneCode = b.zone_code and a.preArriveZoneCode = b.next_zone_code""")
    inNotCarNos.createOrReplaceTempView("in_not_carno_cars")
    val inTotal2 = spark.sqlContext.sql("""select requireId,"" as carNo, translevel as transLevel, carStatus, srcZoneCode, case when b.prologis_in_tm is null then preArriveTm else unix_timestamp(b.prologis_in_tm,'yyyy-MM-dd HH:mm:ss')*1000 end as preArriveTm, preArriveZoneCode, 0 as tickets, 0 as weight, 2 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,send_time,line_code from in_not_carno_cars  a left join kg_data b on a.requireId = b.require_id and a.srcZoneCode = b.zone_code and a.preArriveZoneCode = b.next_zone_code""").dropDuplicates("requireId","srcZoneCode", "preArriveZoneCode")
    val inTotalAll = inTotal.union(inTotal2).where($"srcZoneCode" =!= $"preArriveZoneCode")
      .selectExpr("requireId","carNo","transLevel","carStatus","srcZoneCode","FROM_UNIXTIME(int(sendTime/1000)) as sendTime","FROM_UNIXTIME(int(preArriveTm/1000)) as preArriveTm",
          "preArriveZoneCode","tickets","weight","status","countTime","countDate","lineCode")
    val count2 = inTotalAll.count()
      inTotalAll.createOrReplaceTempView("inTotalAll")
      //TODO 写入hive表,只写入一个分区
      spark.sqlContext.sql("""insert into table dm_heavy_cargo.dwd_t_monitor_in_road_cargo_big partition(inc_day='"""+ countDate +
        """')
          |select
          | requireId as require_id,carNo as car_no,transLevel,carStatus as car_status,srcZoneCode as src_zone_code,send_time,
          | preArriveTm as pre_arrive_tm,preArriveZoneCode as pre_arrive_zone_code,tickets,weight,status,countTime as count_time,countDate as count_date,line_code from inTotalAll""".stripMargin)

    //TidbUtil.write("t_monitor_in_road_cargo_big",inTotalAll,SaveMode.Append)
    spark.sqlContext.uncacheTable("in_road_cars")
    println("3:在途货量计算完毕")

    println("4:开始计算已到达")
    //TODO 读取离线hive表的数据,按照按到达时间分区dm_heavy_cargo.big_has_arrive_cargo_new  近3天的数据 [时间格式问题]
    val hasArriveTaskDf = spark.sqlContext.sql("""select * from dm_heavy_cargo.big_has_arrive_cargo_new where inc_day='"""+ last4Date +"""' and arrive_time <= '"""+ countTime +"""'""")
    hasArriveTaskDf.createOrReplaceTempView("has_arrive_cars")

    val hasArriveTotalPre = spark.sqlContext.sql("select * from " +
      " (select require_id as requireId,translevel as translevel, 6 as carstatus,src_zone_code as srcZoneCode,send_time,arrive_time as preArriveTm," +
      " dest_zone_code as preArriveZoneCode," +
      " sum(tickets) over(partition by require_id,dest_zone_code) as tickets," +
      " sum(weight) over(partition by require_id,dest_zone_code) as weight," +
      " row_number() over(partition by require_id,dest_zone_code order by arrive_time) as num,line_code" +
      " from has_arrive_cars " +
      " )t where t.num = 1").drop("num")
    hasArriveTotalPre.createOrReplaceTempView("has_arrive_total")
    val hasArriveTotal = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus, srcZoneCode,send_time, preArriveTm, preArriveZoneCode, tickets, weight, 3 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate, line_code from has_arrive_total """)
    //补充已到达车辆没有车标的情况
    requireTaskDf1.withColumn("rn", row_number().over(w)).where($"rn" === 1).drop("rn").createOrReplaceTempView("last_day_car_info")
    val hasArrive1 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus,                  srcZoneCode, secondActualArriveTm as preArriveTm,secondZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,    srcActualDepartTm as send_time ,lineCode as line_code from last_day_car_info where (carNo is null or carNo = '') and srcActualDepartTm > 0 and secondActualArriveTm > 0 and secondActualDepartTm is null""")
    val hasArrive2 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus,secondZoneCode as srcZoneCode,  thirdActualArriveTm as preArriveTm, thirdZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate, secondActualDepartTm as send_time ,lineCode as line_code from last_day_car_info where (carNo is null or carNo = '') and secondActualDepartTm > 0 and thirdActualArriveTm > 0 and thirdActualDepartTm is null""")
    val hasArrive3 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus, thirdZoneCode as srcZoneCode,   destActualArriveTm as preArriveTm,  destZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,  thirdActualDepartTm as send_time ,lineCode as line_code from last_day_car_info where (carNo is null or carNo = '') and thirdActualDepartTm > 0 and destActualArriveTm > 0 """)
    val hasArrive4 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus,secondZoneCode as srcZoneCode,   destActualArriveTm as preArriveTm,  destZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate, secondActualDepartTm as send_time ,lineCode as line_code from last_day_car_info where (carNo is null or carNo = '') and secondActualDepartTm > 0 and thirdZoneCode is null and destActualArriveTm > 0""")
    val hasArrive5 = spark.sqlContext.sql("""select requireId,"" as carNo, transLevel, carStatus,                  srcZoneCode,   destActualArriveTm as preArriveTm,  destZoneCode as preArriveZoneCode,0 as tickets, 0 as weight,3 as status, '"""+countTime+"""' as countTime,'"""+countDate+"""' as countDate,    srcActualDepartTm as send_time ,lineCode as line_code from last_day_car_info where (carNo is null or carNo = '') and srcActualDepartTm > 0 and secondZoneCode is null and thirdZoneCode is null and destActualArriveTm > 0 """)
    val hasArriveTotalPre2 = hasArrive1.union(hasArrive2).union(hasArrive3).union(hasArrive4).union(hasArrive5).dropDuplicates("requireId","preArriveZoneCode")
    hasArriveTotalPre2.createOrReplaceTempView("has_arrive_total_pre2")

    val hasArriveTotal2 = spark.sqlContext.sql("""select a.* from has_arrive_total_pre2 a join transit_info_tmp b on a.preArriveZoneCode = b.deptCode""")
      .selectExpr("requireId","carNo","transLevel","carStatus","srcZoneCode","FROM_UNIXTIME(int(sendTime/1000)) as sendTime","FROM_UNIXTIME(int(preArriveTm/1000)) as preArriveTm",
          "preArriveZoneCode","tickets","weight","status","countTime","countDate","lineCode")

    hasArriveTotal.union(hasArriveTotal2).createOrReplaceTempView("has_arrive_all")
    val hasArriveResult = spark.sqlContext.sql("""select t.* from (select a.*,row_number() over(partition by requireId,preArriveZoneCode order by weight desc) as rn from has_arrive_all a)t where t.rn = 1 """).drop("rn").where($"srcZoneCode" =!= $"preArriveZoneCode")
    println("4:已到达货量计算完毕")
    val count3 = hasArriveResult.count()
    hasArriveResult.createOrReplaceTempView("hasArriveResult")
    //todo 写入hive
    //TODO 写入hive表
    spark.sqlContext.sql("""insert into table dm_heavy_cargo.dwd_t_monitor_in_road_cargo_big partition(inc_day='"""+ countDate + """') select
        | requireId as require_id,carNo as car_no,transLevel,carStatus as car_status,srcZoneCode as src_zone_code,send_time,
        | preArriveTm as pre_arrive_tm,preArriveZoneCode as pre_arrive_zone_code,tickets,weight,status,countTime as count_time,countDate as count_date,line_code
        | from hasArriveResult""".stripMargin)

  }
}

