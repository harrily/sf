package com.sf.realtime.spark.sql

import com.sf.realtime.common.utils.DateUtil
import com.sf.realtime.spark.utils.{SqlUtil, TidbOldUtil, TidbUtil}
import org.apache.spark.sql.{DataFrame, SQLContext}

object CarInfo {
  def getCarInfo(sc: SQLContext,dateCondition:Long,beforeDay:Integer):DataFrame = {
    val predicates =
      SqlUtil.getReadMysqlPartitionByHourTime(dateCondition, 24, beforeDay).map {
        case (start, end) =>
          s"operateTime > $start and operateTime <= $end"
      }
    val sql = """(select * from tbl_car_info_data_new where operateTime > """ + dateCondition + """) as t"""
    TidbUtil.read(sql, sc, predicates)
  }

  def getRequireTaskInfo(sc: SQLContext,dateCondition:Long,beforeDay:Integer):DataFrame = {
    val sql = """(select * from ts_require_task_info where lastUpdateTm > """ + dateCondition + """) as t"""

    val predicates = SqlUtil.getReadMysqlPartitionByHourTime(dateCondition,24,beforeDay).map{case (start, end) =>
      s"lastUpdateTm > $start and lastUpdateTm <= $end"}
    TidbUtil.read(sql, sc, predicates)
  }

  def getRequireTaskInfo2(sc: SQLContext,dateCondition:Long,beforeDay:Integer):DataFrame = {
    val sql = """(select * from ts_car_require_carno_info where lastUpdateTm > """ + dateCondition + """) as t"""

    val predicates = SqlUtil.getReadMysqlPartitionByHourTime(dateCondition,24,beforeDay).map{case (start, end) =>
      s"lastUpdateTm > $start and lastUpdateTm <= $end"}
    TidbUtil.read(sql, sc, predicates)
  }

  def getCarRequireTaskInfo(sc: SQLContext,dateCondition:Long,beforeDay:Integer):DataFrame ={
    val sql = """(select * from ts_car_require_task_info) as t"""

    val predicates = SqlUtil.getReadMysqlPartitionByHourTime(dateCondition,24,beforeDay).map{case (start, end) =>
      s"lastUpdateTm > $start and lastUpdateTm <= $end"}
    TidbUtil.read(sql, sc, predicates)
  }

  def getVehicleNotSendTaskInfo(sc: SQLContext,dateCondition:Long,beforeDay:Integer):DataFrame ={
    val sql = """(select * from rt_vehicle_task_monitor_for_not_send_detail) as t"""

    val predicates = SqlUtil.getReadMysqlPartitionByHourTime(dateCondition,24,beforeDay).map{case (start, end) =>
      s"lastUpdateTm > $start and lastUpdateTm <= $end"}
    TidbUtil.read(sql, sc, predicates)
  }

  def getVehicleNotSendTaskInfo(sc: SQLContext,dateCondition:Long,beforeDay:Integer,isOldTidb:Boolean):DataFrame ={
    if(isOldTidb){
      val sql = """(select * from rt_vehicle_task_monitor_for_not_send_detail) as t"""

      val predicates = SqlUtil.getReadMysqlPartitionByHourTime(dateCondition,24,beforeDay).map{case (start, end) =>
        s"lastUpdateTm > $start and lastUpdateTm <= $end"}
      TidbOldUtil.read(sql, sc, predicates)
    }else{
      val sql = """(select * from rt_vehicle_task_monitor_for_not_send_detail) as t"""

      val predicates = SqlUtil.getReadMysqlPartitionByHourTime(dateCondition,24,beforeDay).map{case (start, end) =>
        s"lastUpdateTm > $start and lastUpdateTm <= $end"}
      TidbUtil.read(sql, sc, predicates)
    }
  }

  def getVehicleHasArriveTaskInfo(sc: SQLContext,dateCondition:Long,beforeDay:Integer):DataFrame ={
    val sql = """(select * from vt_has_arrive_cars) as t"""

    val predicates = SqlUtil.getReadMysqlPartitionByHourTime(dateCondition,24,beforeDay).map{case (start, end) =>
      s"actualTime > $start and actualTime <= $end"}
    TidbUtil.read(sql, sc, predicates)
  }
  def getVehicleHasArriveBatchTaskInfo(sc: SQLContext,dateCondition:String,beforeDay:Integer):DataFrame ={
    val sql = """(select * from vt_has_arrive_cars_batch) as t"""

    val predicates = SqlUtil.getReadMysqlPartitionByHourString(dateCondition,24,beforeDay).map{case (start, end) =>
      s"actualTime > '"+start+"' and actualTime <= '"+end+"'"}
    TidbUtil.read(sql, sc, predicates)
  }

  def getVehicleInRoadBatchTaskInfo(sc: SQLContext,dateCondition:Long,beforeDay:Integer):DataFrame ={
    val sql = """(select * from t_monitor_in_road_cargo_new) as t"""

    val predicates = SqlUtil.getReadMysqlPartitionByHourTime(dateCondition,24,beforeDay).map{case (start, end) =>
      s"preArriveTm > $start and preArriveTm <= $end"}
    TidbUtil.read(sql, sc, predicates)
  }

  def getVehicleHasArriveTaskInfo7Day(sc: SQLContext,dateCondition:Long,beforeDay:Integer):DataFrame ={
    val sql = """(select * from vt_has_arrive_cars) as t"""

    val predicates = SqlUtil.getReadMysqlPartitionByHourTime(dateCondition,24*7,beforeDay).map{case (start, end) =>
      s"actualTime > $start and actualTime <= $end"}
    TidbUtil.read(sql, sc, predicates)
  }

  def getVehicleBigHasArriveTaskInfo(sc: SQLContext,dateCondition:Long,beforeDay:Integer):DataFrame ={
    val sql = """(select * from vt_has_arrive_cars_big) as t"""

    val predicates = SqlUtil.getReadMysqlPartitionByHourTime(dateCondition,24,beforeDay).map{case (start, end) =>
      s"actualTime > $start and actualTime <= $end"}
    TidbUtil.read(sql, sc, predicates)
  }

  def getFullLoadWeight(sc:SQLContext, dateCondition:Long):DataFrame ={
    val predicates =
      SqlUtil.getReadMysqlPartitionByHourTime(dateCondition, 24, 1).map{
        case(start, end) =>
          s"lastUpdateTm > $start and lastUpdateTm <= $end"
      }
    val sql = """(select * from ts_require_task_info where lastUpdateTm > """ + dateCondition + """) as t"""
    TidbUtil.read(sql, sc, predicates)
  }

  def main(args: Array[String]): Unit = {
    val predicates =  SqlUtil.getReadMysqlPartitionByHourTime(DateUtil.getLastTimeStamp("2022-08-24 12:00:00".substring(0, 10).concat(" 00:00:00"),3),24,8).map { case (start, end) =>
      s"actualTime > '" + start + "' and actualTime <= '" + end + "'"}
    for (elem <- predicates) {println(elem)}
  }
}
