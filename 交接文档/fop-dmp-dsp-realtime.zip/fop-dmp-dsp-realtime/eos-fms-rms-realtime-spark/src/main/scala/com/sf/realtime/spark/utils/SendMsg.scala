package com.sf.realtime.spark.utils

object SendMsg {
  val url = "http://bdp.sf-express.com/monitor/notice/send"
  def send(subject:String,content:String,reciver:String,channel:String):Unit={
    val postText = s"""{"members": "${reciver}","alertMode": "${channel}","subject": "${subject}","content": "${content}"}"""
    HttpUtil.post(url, postText) 
  }
}