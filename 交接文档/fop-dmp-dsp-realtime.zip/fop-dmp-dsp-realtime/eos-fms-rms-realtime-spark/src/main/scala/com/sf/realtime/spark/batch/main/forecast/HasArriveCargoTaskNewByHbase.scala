package com.sf.realtime.spark.batch.main.forecast

import com.alibaba.fastjson.JSON
import com.sf.realtime.common.utils.DateUtil
import com.sf.realtime.hbase.HbaseUtil
import com.sf.realtime.hbase.common.ColumnType
import com.sf.realtime.spark.context.Context
import com.sf.realtime.spark.sql.DeptInfo
import org.apache.commons.lang.StringUtils
import org.apache.hadoop.hbase.CellUtil
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

import java.util
import java.util.UUID
import scala.collection.JavaConverters._
import scala.collection.mutable.ArrayBuffer

object HasArriveCargoTaskNewByHbase {

  def main(args: Array[String]): Unit = {
    val spark = Context.getContext(true)
   val allArrive = spark.sqlContext.sql(""" SELECT require_id ,car_no,translevel,src_zone_code,dest_zone_code,arrive_time,send_time,car_status FROM tmp_ordi_predict.tmp_all_arrive_before_hbase_553293 """.stripMargin)
    val requireCarNoDetail = allArrive.rdd.repartition(2500).filter(r=>r.getAs[String]("car_no")!= null && !r.getAs[String]("car_no").equals("") ).mapPartitions(f=>{
      val hbase = HbaseUtil.getInstance()
      f.map(r=>{
        val requireId = r.getAs[String]("require_id")
        val translevel = r.getAs[Integer]("translevel")
        val carNo = r.getAs[String]("car_no")
        val srcZoneCode = r.getAs[String]("src_zone_code")
        val destZoneCode = r.getAs[String]("dest_zone_code")
        val arriveTime = r.getAs[Long]("arrive_time")
        val sendTime = r.getAs[Long]("send_time")
        val carStatus = r.getAs[Integer]("car_status")
        val rowKey = carNo.reverse
        val rtContrnRes = hbase.getRow("rt_container_waybill_relation", Bytes.toBytes(rowKey))
        var listRow = new ArrayBuffer[Row]()
        if (rtContrnRes != null && !rtContrnRes.isEmpty) {
          val cells = rtContrnRes.listCells().asScala
          val getList = new util.ArrayList[String]()
          var columns = new util.HashMap[String,ColumnType]()
          for(cell <- cells){
            val waybillNo = Bytes.toString(CellUtil.cloneQualifier(cell))
            val waybillJson = JSON.parseObject(Bytes.toString(CellUtil.cloneValue(cell)))
            val jobType = waybillJson.getString("jobType")
            if (StringUtils.isNotEmpty(waybillNo)&& waybillJson.getInteger("isDeleted") == 0){
              //val get = new Get(Bytes.toBytes(waybillNo.reverse))
              //get.addColumn(Bytes.toBytes("baseInfo"), Bytes.toBytes("packageMeterageWeightQty"))
              getList.add(waybillNo)
              columns.put("packageMeterageWeightQty",ColumnType.DOUBLE)
            }
          }
          //val result = hbase.getList("wb_info_data",getList.toList.asJava)
          val hrs = hbase.getListSpecialForWbInfo(getList, columns);
          for(waybillResult <- hrs.entrySet().asScala; if hrs!=null && !hrs.isEmpty) {
            var weight = 0D
            var ticket = 0L
            var waybillNo = ""
            if (waybillResult != null) {
              waybillNo = waybillResult.getKey
              val wCells = waybillResult.getValue
              for (wCell <- wCells.entrySet().asScala) {
                weight = wCell.getValue.asInstanceOf[Double]
                if (weight > 1000000D) {
                  weight = 1000000D
                }
                ticket = 1L
              }
            }
            listRow += Row(requireId, carNo, srcZoneCode, destZoneCode, sendTime, arriveTime, ticket, weight, waybillNo, translevel.toString, carStatus.toString)
           }
          }else{
              listRow += Row(requireId,carNo,srcZoneCode,destZoneCode,sendTime,arriveTime,0L,0D,null,translevel.toString,carStatus.toString)
          }
          listRow.toArray
        }).flatMap(r=>r.iterator)
      })
    val structFields = Array(StructField("require_id", StringType, true),
      StructField("car_no", StringType, true),
      StructField("src_zone_code", StringType, true),
      StructField("dest_zone_code", StringType, true),
      StructField("send_time", LongType, true),
      StructField("arrive_time", LongType, true),
      StructField("tickets", LongType, true),
      StructField("weight", DoubleType, true),
      StructField("waybill_no", StringType, true),
      StructField("translevel", StringType, true),
      StructField("car_status", StringType, true)
    )
    val id = UUID.randomUUID.toString
    val structType = StructType(structFields)
    val requireCarNoDetailDf = spark.createDataFrame(requireCarNoDetail, structType).dropDuplicates("waybill_no","dest_zone_code")
    requireCarNoDetailDf.createOrReplaceTempView("requireCarNoDetailDf")
    // 结果写入临时表
    spark.sqlContext.sql("""drop table if exists tmp_ordi_predict.tmp_all_arrive_behind_hbase_553293;""")
    spark.sqlContext.sql(
      """create table tmp_ordi_predict.tmp_all_arrive_behind_hbase_553293
        |stored as parquet as
        | select require_id,car_no,src_zone_code,dest_zone_code,send_time,arrive_time,tickets,weight,waybill_no,translevel,car_status
        | from requireCarNoDetailDf""".stripMargin)
  }
}
