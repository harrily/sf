package com.sf.realtime.spark.sql

import com.sf.realtime.spark.utils.CloudTidbUtil2
import org.apache.spark.sql.{DataFrame, SQLContext}

object DeptInfo {
  val sql  = """(select
                dept_code as deptCode,
                dept_type as deptType,
                dept_name as deptName,
                division_code as divisionCode,
                division_name as divisionName,
                area_code as areaCode,
                area_name as areaName,
                hq_code as hqCode,
                hq_name as hqName,
                is_mix_ground as isMixGround,
                ground_improve_weight as groundImproveWeight
                from dim_heavy_dept where dept_type='快运中转场') as t"""

  val allDeptSql = """(select dept_code as deptCode,dept_name as deptName from dim_department where dept_transfer_flag = '1') as t"""

  def getDeptInfo(sc: SQLContext):DataFrame = {
    //TidbUtil.read(sql, sc).dropDuplicates("deptCode")
    CloudTidbUtil2.read(sql, sc).dropDuplicates("deptCode")
  }

  def getAllDeptInfo(sc: SQLContext):DataFrame = {
    CloudTidbUtil2.read(allDeptSql, sc).dropDuplicates("deptCode")
  }

  def getZoneInfo(sc:SQLContext):DataFrame = {
    val depSql ="""(SELECT dept_code, dept_transfer_flag
         FROM fmsrms.dim_heavy_dept) as t"""
    CloudTidbUtil2.read(depSql, sc).dropDuplicates("dept_code")
  }

  @deprecated
  def getKyTransitDeptInfo(sc:SQLContext):DataFrame = {
    val sql = """(select * from dim_department where dept_type_name = '快运中转场' and delete_flg = '0' and deldate is null and dept_name not like '【SX】%') as t"""
    CloudTidbUtil2.read(sql, sc).dropDuplicates("dept_code")
  }

  def getKyTransitDeptInfo2(sc:SQLContext):DataFrame = {
    val sql = """(select * from dim_heavy_transit_info) as t"""
    CloudTidbUtil2.read(sql, sc).dropDuplicates("dept_code")
  }

  def getKyJPZDeptInfo(sc:SQLContext):DataFrame = {
    val sql = """(select dept_code from dim_department where dept_type_code='DB05-JPZ' and delete_flg='0' and dept_name not like '【SX】%') as t"""
    CloudTidbUtil2.read(sql, sc).dropDuplicates("dept_code")
  }

  def getKyNewDeptInfo(sc:SQLContext):DataFrame = {
    val sql = """(select dept_code as deptCode from dim_heavy_transit_info) as t"""
    CloudTidbUtil2.read(sql, sc).dropDuplicates("deptCode")
  }

  /**
   * 获取速运场地 测试使用'021WG','755W','769XG'三个网点进行测试
   * @param sc
   * @return
   */
  def getBigNewDeptInfo(sc:SQLContext):DataFrame = {
    val sql = """(select dept_code as deptCode from dim_heavy_transit_info_big) as t"""
    CloudTidbUtil2.read(sql, sc).dropDuplicates("deptCode")
    }

  /**
   * 获取速运场地 155个小件场地网点进行测试
   * @param sc
   * @return
   */
  def get155BigNewDeptInfo(sc:SQLContext):DataFrame = {
    val sql = """(select dept_code as deptCode from dim_heavy_transit_info_big_155) as t"""
    CloudTidbUtil2.read(sql, sc).dropDuplicates("deptCode")
  }
}
