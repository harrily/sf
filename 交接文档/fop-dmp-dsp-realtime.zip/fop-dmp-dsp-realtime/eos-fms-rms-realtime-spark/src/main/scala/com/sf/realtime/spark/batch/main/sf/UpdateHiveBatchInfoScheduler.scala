package com.sf.realtime.spark.batch.main.sf

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{concat, lit}
import org.elasticsearch.spark.sql.EsSparkSQL

/**
 * @Author 01419728
 * @Date 2022/4/29 10:56
 */
object UpdateHiveBatchInfoScheduler {



  def main(args:Array[String]):Unit = {
    val spark = Context.spark
    import spark.implicits._
//    System.setProperty("hadoop.home.dir", "D:\\Program Files\\hadoop-2.7.7");

    val currentTime = args(0) //20220422
    val deptCode: String = args(1)//dim_heavy_transi_info
   /* val frame = spark.read.format("csv")
      .option("sep", "\t")
      .option("header", "true")
      .load("D:\\user\\01419728\\Downloads\\sf_batch_info_0429.csv")*/

    val sfBbatchInfo = spark.sqlContext.sql(
      """
   select
        zonecode,workday, 0 batch_date,batch_code,start_tm,end_tm,valid_dt,invld_dt,
        lag(last_arr_tm,1,last_vv) over(partition by zonecode,workday order by last_arr_tm) start_last_arr_tm,
        last_arr_tm
   from
        (select
            zonecode,batch_code,start_tm,end_tm,work_day,valid_dt,invld_dt,
            max(last_arr_tm) over(partition by zonecode,workday) last_vv,
            last_arr_tm,
            workday
        from
            (select
             *
            from
                (select * from bdp.dm_ordi_predict.batch_info
                where inc_day='"""+ currentTime +"""')t1
                left join (SELECT dept_code FROM ky.dim_freight."""+deptCode+""") t2
                on zonecode=dept_code
                where dept_code is not null)t3
        lateral view explode(split(work_day,'')) tmp as workday
        where workday <>'')aa
        """)
    sfBbatchInfo.createOrReplaceTempView("sfBatchInfo")
    val frame = spark.sqlContext.sql(
      """
    select
        zonecode,if((int(workday)+1<=7),int(workday)+1,1) arrive_date, workday,-1 batch_date,batch_code,start_tm,end_tm,valid_dt,invld_dt,
        '0000' start_last_arr_tm,
        last_arr_tm
    from sfBatchInfo
    where start_last_arr_tm>=last_arr_tm
 union
    select
        zonecode,workday arrive_date,workday, 0 batch_date,batch_code,start_tm,end_tm,valid_dt,invld_dt,
        start_last_arr_tm,
        if(start_last_arr_tm>last_arr_tm,'2400',last_arr_tm) last_arr_tm
    from  sfBatchInfo
        """).orderBy("zonecode","arrive_date","start_last_arr_tm")

//    println("sql:"+sql)
    frame.selectExpr("zonecode",
      "arrive_date",
      "cast(workday as int) workday",
      "batch_date",
      "batch_code",
      "start_tm",
      "end_tm",
      "valid_dt",
      "invld_dt",
      "cast(start_last_arr_tm as int) start_last_arr_tm",
      "cast(last_arr_tm as int) last_arr_tm")




    val result = frame.withColumn("id",concat($"zonecode",lit("_"),$"arrive_date",lit("_"),$"batch_date",lit("_"),$"batch_code"))
    result.show()

    EsSparkSQL.saveToEs(result,"dim_sf_batch_info/dim_sf_batch_info",
      Map("es.mapping.id" -> "id","es.resource"->"dim_sf_batch_info/dim_sf_batch_info"))
  }

  object Context {
    val conf = new SparkConf()
//    conf.set("es.nodes","10.202.116.33,10.202.116.34,10.202.116.35")                 //测试环境
    conf.set("es.nodes","10.117.106.60,10.117.106.61,10.117.106.62")                   //生产环境
    conf.set("es.port","9200")
    conf.set("es.nodes.wan.only","true")
    val spark = SparkSession.builder()
      .config(conf)
      .enableHiveSupport()
//      .master("local[2]")                                                            //测试环境
      .getOrCreate()
  }
}