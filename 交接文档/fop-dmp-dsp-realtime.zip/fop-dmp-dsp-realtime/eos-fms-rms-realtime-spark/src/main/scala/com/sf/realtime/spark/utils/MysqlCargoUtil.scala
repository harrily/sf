package com.sf.realtime.spark.utils

import com.sf.realtime.common.config.Config
import org.apache.spark.sql.{DataFrame, SQLContext, SaveMode}

import java.sql.{Connection, DriverManager}
import java.util.Properties

object MysqlCargoUtil {
  val config = Config.getConfig
  val jdbcUrl = config.getString("mysql.cargo.jdbc.url")
  val user = config.getString("mysql.cargo.user")
  val passwd = config.getString("mysql.cargo.passwd")

  val prop =new Properties()
  prop.setProperty("user",user)
  prop.setProperty("password",passwd)

  def read(tableName:String,sqlContext:SQLContext,predicates:Array[String]):DataFrame={
    val df = sqlContext.read.option("driver", "com.mysql.cj.jdbc.Driver")
      .jdbc(jdbcUrl, tableName, predicates, prop)
    df
  }

  def read(tableName:String,sqlContext:SQLContext):DataFrame={
    val df = sqlContext.read.option("driver", "com.mysql.cj.jdbc.Driver")
      .jdbc(jdbcUrl, tableName, prop)
    df
  }

  def write(tableName:String,data:DataFrame):Unit={
    write(tableName,data,SaveMode.Append)
  }

  def write(tableName:String,data:DataFrame,mode:SaveMode) = mode match {
    case SaveMode.Overwrite =>
      data.write.option("driver", "com.mysql.cj.jdbc.Driver")
        .option("isolationLevel", "NONE")
        .option("truncate", true)
        .mode(mode)
        .jdbc(jdbcUrl, tableName, prop)
    case _ =>
      data.write.option("driver", "com.mysql.cj.jdbc.Driver")
        .option("isolationLevel", "NONE")
        .mode(mode)
        .jdbc(jdbcUrl, tableName, prop)
  }

  def getConn(): Connection = {
    Class.forName("com.mysql.cj.jdbc.Driver")
    val connection = DriverManager.getConnection(jdbcUrl, user, passwd)
    connection
  }
}
