package com.test.es;

import com.alibaba.fastjson.JSONObject;
import io.searchbox.client.JestClient;
import io.searchbox.client.JestClientFactory;
import io.searchbox.client.config.HttpClientConfig;
import io.searchbox.core.Search;
import io.searchbox.core.SearchResult;
import lombok.val;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Author 01419728
 * @Date 2022/5/4 22:58
 */
public class EsRead {
    public static void main(String[] args) throws Exception {
        String zonecode = "755W";
        String arrTime = "2022-04-16 23:30:30";
        DateTimeFormatter df2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        DateTimeFormatter df3 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime start = LocalDate.parse(arrTime, df2).atStartOfDay();
        String lastDay = start.minusDays(1).format(df3);

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = formatter.parse(arrTime);
        String arrTmDay = arrTime.substring(0, 10);//2022-02-22
        String arrTmHHmm = arrTime.substring(11, 13).concat(arrTime.substring(14, 16));//1550
        //工作日判断
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int week_index = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (week_index < 0) {
            week_index = 0;
        }

        //1.创建ES客户端连接池
        JestClientFactory factory = new JestClientFactory();

        //2.创建ES客户端连接地址
        HttpClientConfig httpClientConfig = new HttpClientConfig.Builder("http://10.202.116.33:9200").build();

        //3.设置ES连接地址
        factory.setHttpClientConfig(httpClientConfig);

        //4.获取ES客户端连接
        JestClient jestClient = factory.getObject();

        //5.构建查询数据对象
        Search search = new Search.Builder("{\"query\":{\"bool\":{\"must\":[" +
                "{\"term\":{\"zonecode\":\""+zonecode+"\"}}," +
                "{\"term\":{\"arrive_date\":\""+week_index+"\"}}," +
                "{\"range\":{\"start_last_arr_tm\":{\"lte\":"+arrTmHHmm+"}}}," +
                "{\"range\":{\"last_arr_tm\":{\"gte\":"+arrTmHHmm+"}}}]}}, \"_source\": [\"batch_code\",\"batch_date\"]}").addIndex("dim_sf_batch_info").addType("dim_sf_batch_info").build();

        //6.执行查询操作
        SearchResult searchResult = jestClient.execute(search);

        //7.解析查询结果
        System.out.println(searchResult.getTotal());
        List<SearchResult.Hit<Map, Void>> hits = searchResult.getHits(Map.class);
        for (SearchResult.Hit<Map, Void> hit : hits) {
            System.out.println(hit.index + "--" + hit.id);
            System.out.println(hit.source);
            Map source = hit.source;
            System.out.println("batch_code: "+source.get("batch_code"));
        }

        Map source = searchResult.getHits(Map.class).get(0).source;
        Object batch_code = source.get("batch_code");
        Object batch_date = source.get("batch_date");
        System.out.println("batch_info"+batch_code+"         "+"batch_date"+batch_date);

        //8.关闭连接
        jestClient.shutdownClient();
    }
}
