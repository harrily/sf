package com.sf.resltime.test

/**
 * @Author 01419728
 * @Date 2022/4/24 14:53
 */
case class BatchInfo (batch_code:String,
                      start_tm:String,
                      end_tm:String,
                      work_day:String,
                      valid_dt:String,
                      invld_dt:String,
                      last_arr_tm:String) {

}
