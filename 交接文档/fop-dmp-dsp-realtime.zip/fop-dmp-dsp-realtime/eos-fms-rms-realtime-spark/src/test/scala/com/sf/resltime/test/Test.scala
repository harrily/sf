package com.sf.resltime.test

import com.alibaba.fastjson.{JSON, JSONArray}
import com.sf.realtime.common.config.Config
import com.sf.realtime.common.utils.{DateUtil, MD5Util}
import com.sf.realtime.spark.context.Context
import com.sf.realtime.spark.utils.SqlUtil
import org.apache.http.HttpHost
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.catalyst.expressions.Round
import org.apache.spark.sql.functions.udf

import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import java.time.{LocalDate, LocalDateTime}
import java.util
import java.util.{ArrayList, List, UUID}
import com.sf.realtime.spark.utils.{CacheUtil, TidbUtil}

import com.sf.realtime.common.utils.DateUtil
import com.sf.realtime.spark.context.Context
import com.sf.realtime.spark.sql.{CarInfo, DeptInfo}
import com.sf.realtime.spark.utils.{CacheUtil, TidbUtil}
import org.apache.spark.sql.functions.{lit, max, min, sum}
import org.apache.spark.sql.{DataFrame, Dataset, Row}

/**
 * @Author 01419728
 * @Date 2022/2/15 18:22
 */
object Test {




  def main(args: Array[String]): Unit = {
    //val ss = Context.getContext(true)
    //    println("hahah")
//    println("389238368046".reverse)

    /*    val startDay = "20220111"
    val endDay = "20220219"
    val oneday= 1000*60*60*24L
    val partitionDay = "20220111"

    var start = DateUtil.getLastTime3(endDay, 124) //1018--1634486400000
    var end = DateUtil.getLastTime3(endDay, 100) //1111--1636560000000
    println(start)
    println(end)
    println(DateUtil.getTime3(endDay))//0219--1645200000000

    while(end<DateUtil.getTime3(endDay)){
      start += oneday
      end += oneday
      println("start:   "+DateUtil.timestamptoDate(start))
      println("end:   "+DateUtil.timestamptoDate(end))
    }*/
    // println(DateUtil.getLastDayStringdf3("20220219", 3))
    //    val carNo = "390221744494"//494447122093
    //    val carNo2 = "781108782089"
    //    val rowkey= carNo2.reverse //
    //    println(rowkey) //494447122093
    //    val waybill = "SF1134920023521"
    //    val waybill2 = "SF2007352062382"
    //    println(MD5Util.getMD5(waybill)) //D362F60BF3229C0C4E2D5C27D6CE4C26
    //    println(new StringBuffer(waybill2).reverse().toString)//E01C516568387153D98F9178B7145EAE
    //    println("SF1134065491866"+" ==>"+MD5Util.getMD5("SF1134065491866"))
    //    println("SF1141923050427"+" ==>"+MD5Util.getMD5("SF1141923050427"))
    //    println("SF1141923050436"+" ==>"+MD5Util.getMD5("SF1141923050436"))
    //    println("SF2021196032002"+" ==>"+MD5Util.getMD5("SF2021196032002"))
    //    println("SF1406904427559"+" ==>"+MD5Util.getMD5("SF1406904427559"))
    //    println("SF1141923050454"+" ==>"+MD5Util.getMD5("SF1141923050454"))
    //    println("SF1145662356594"+" ==>"+MD5Util.getMD5("SF1145662356594"))
    //    println("SF1424944005112"+" ==>"+MD5Util.getMD5("SF1424944005112"))
    //    println("SF1141923050463"+" ==>"+MD5Util.getMD5("SF1141923050463"))
    //    println("SF1147625649139"+" ==>"+MD5Util.getMD5("SF1147625649139"))
    //    println("SF1366929651376"+" ==>"+MD5Util.getMD5("SF1366929651376"))
    //    println("SF1400914424059"+" ==>"+MD5Util.getMD5("SF1400914424059"))
    //    println("SF2021196013755"+" ==>"+MD5Util.getMD5("SF2021196013755"))
//    println("SF2007585100379" + " ==>" + MD5Util.getMD5("SF2007585100379"))
    //val currentDay = "20220222"
    /*    val timeStamp =1645681393000L  //2022-02-24 13:43:13-->2022-02-24 13:40:00--1645681200000
    val l = timeStamp / (1000*60*20)

    1371401*60*20
    val oneday= 1000*60*60*24L
    println(DateUtil.getTimeWithHms("2022-02-24 13:43:13"))*/
    //println(DateUtil.df2Todf3("2022-03-18 22:40:00"))

    /*  val str =
      """
        |[{"batch_code":"010AA01D","start_tm":"1720","end_tm":"0800","work_day":"1234567","valid_dt":"2022-02-07","invld_dt":"9999-12-31","last_arr_tm":"0800"}
        |            ,{"batch_code":"010AA02D","start_tm":"0800","end_tm":"1005","work_day":"1234567","valid_dt":"2022-02-08","invld_dt":"9999-12-31","last_arr_tm":"1005"}
        |            ,{"batch_code":"010AA03D","start_tm":"1005","end_tm":"1310","work_day":"1234567","valid_dt":"2022-02-08","invld_dt":"9999-12-31","last_arr_tm":"1310"}
        |            ,{"batch_code":"010AA04D","start_tm":"1310","end_tm":"1600","work_day":"1234567","valid_dt":"2022-02-07","invld_dt":"9999-12-31","last_arr_tm":"1600"}
        |            ,{"batch_code":"010AA05D","start_tm":"1600","end_tm":"1720","work_day":"1234567","valid_dt":"2022-04-06","invld_dt":"9999-12-31","last_arr_tm":"1720"}]
        |
        |""".stripMargin
      val array: JSONArray = JSON.parseArray(str)

      println(array)*/

    /*  val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    //要转换的时间格式
    val sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


    val predicates = SqlUtil.getReadMysqlPartitionByHourTime( DateUtil.getLastHoursTime(24*30),24,30).map{case (start, end) =>
      println(start/1000,end/1000)
      println("actualTime > "+sdf.format(start/1000)+" and actualTime <= "+sdf.format(end/1000)+"")
      s"actualTime > $start and actualTime <= $end"

    }
*/
    /*  val hostsarray: util.ArrayList[String] = new util.ArrayList[String]
    val hosts: List[String] = Config.getConfig.getStringList("es.product.host") //生产环境
    val httpHosts: Array[HttpHost] = new Array[HttpHost](hosts.size)
    for (i <- 0 until hosts.size) {
      httpHosts(i) = new HttpHost(hosts.get(i), Config.getConfig.getInt("es.product.port")) //生产环境
    }
    httpHosts.foreach(t=>{
      println(t.toString)
    })*/
    /*
val predicates =  SqlUtil.getReadMysqlPartitionByHourTime(DateUtil.getLastHoursTime("2023-02-17 17:00:00",24*3),24,4)
  .map { case (start, end) =>
  s"actualTime > '" + start + "' and actualTime <= '" + end + "'"}
    for (elem <- predicates) {println(elem)}
  }
    **/

/**
    val countDate = DateUtil.getDateStringWithoutHMS(0)
    val countTime = DateUtil.getTimestamp(0)
    println("countDate:"+countDate)
    println("countTime:"+countTime)
    **/

//    val t_7 = DateUtil.getTime(7);
//    println("t_7:"+t_7)
//
//    val getLastHoursTime_1 = DateUtil.getLastHoursTime(24)
//    println("getLastHoursTime_1:"+getLastHoursTime_1)
//DateUtil.getLastHoursTime(currentDate,24*3)
//    val predicates = SqlUtil.getReadMysqlPartitionByHourTime(DateUtil.getLastHoursTime("2023-09-26 17:00:00",24*3),24,4).map{case (start, end) =>
//      s"actualTime > $start and actualTime <= $end"}
//    println("predicates:"+predicates)

//
////    val last30Day = args(0)
//    val currentDate = "2023-09-26 14:00:00" //业务时间  $[time(yyyy-MM-dd HH:mm:ss)]
////    val last3Day = args(2)
//    val incDay = DateUtil.df2Todf3(currentDate)
//    println("incDay:"+incDay)
//    val incHour = currentDate.substring(11, 13).concat(currentDate.substring(14, 16))
//    println("incHour:"+incHour)
//    //可回刷使用lastUpdateTm进行控制
//    val countTimeStamp = DateUtil.getTimeWithHms(currentDate) //统计时间"yyyy-MM-dd HH:mm:ss"
//    println("countTimeStamp:"+countTimeStamp)
//    val next7DaytTimeStamp = DateUtil.getLastTimeStamp(currentDate,-4) //统计时间"yyyy-MM-dd HH:mm:ss" 取00:00:00
//    println("next7DaytTimeStamp:"+next7DaytTimeStamp)
//    val last7DayTimeStamp = DateUtil.getLastTimeStamp(currentDate,3) //统计时间"yyyy-MM-dd HH:mm:ss"取00:00:00
//    println("last7DayTimeStamp:"+last7DayTimeStamp)
//    val last8Day = DateUtil.getLastDayStringdf3(DateUtil.df2Todf3(currentDate), 4)
//    println("last8Day:"+last8Day)
//    val next8Day = DateUtil.getLastDayStringdf3(DateUtil.df2Todf3(currentDate), -5)
//    println("next8Day:"+next8Day)
//    val countDate = currentDate.substring(0, 10)
//    println("countDate:"+countDate)
//    val countTime = currentDate
//    println("countTime:"+countTime)
//
//    val countDate_else = DateUtil.getDateStringWithoutHMS(0)
//    val countTime_els = DateUtil.getTimestamp(0)
//    println("countDate_else:"+countDate_else)
//    println("countTime_els:"+countTime_els)


//      val startDay = "$[time(yyyyMMdd,-3d)]"
//      val endDay = "$[time(yyyyMMdd)]"
//      val currentDate = "2023-09-27 18:00:00" //业务时间  $[time(yyyy-MM-dd HH:mm:ss)]
//      val incDay = DateUtil.df2Todf3(currentDate)
//      println("incDay:"+incDay)
//      val incHour = currentDate.substring(11, 13).concat(currentDate.substring(14, 16))
//      println("incHour:"+incHour)
//      //可回刷使用lastUpdateTm进行控制
//      val last8Day = DateUtil.getLastDayStringdf3(DateUtil.df2Todf3(currentDate), 4)
//      println("last8Day:"+last8Day)
//      val next8Day = DateUtil.getLastDayStringdf3(DateUtil.df2Todf3(currentDate), -5)
//      println("next8Day:"+next8Day)
//    val idUdf: ((String) => String) = (code: String) => {UUID.randomUUID().toString()}
//    val addId = udf(idUdf)
//    println("addId:"+addId)

//写入tidb
//判断是版本号是哪个   版本控制表 pub_table_sync_version
val tableName = "dws_sx_vehicle_sum"
val spark = Context.getContext(true)
val versionDf = TidbUtil.read("pub_table_sync_version", spark.sqlContext)
    var versionId = versionDf.where("table_name='"+tableName+"' ")
      .collect()(0).getAs("version_id").asInstanceOf[Long]
    println("versionId:"+versionId)
    System.setProperty("hadoop.home.dir", "D:\\soft\\hadoop-common")
    //println("表dws_sf_dept_sx_vehicle_sum写入前最新版本号是: "+versionId)
    //如果当前版本是1,  删除版本为2的数据 则写入数据为version=2
    if (1L == versionId) {
      versionId = 2L
    } else {
      versionId = 1L
    }
    println("versionId:"+versionId)
  }
}
