package com.sf.resltime.test

import com.sf.realtime.common.utils.{DateUtil, MD5Util}
import com.sf.realtime.spark.utils.SqlUtil

import java.text.SimpleDateFormat
import java.util.Calendar
import scala.collection.mutable.ArrayBuffer

/**
 * @Author 01419728
 * @Date 2022/2/15 18:22
 */
object Test2 {


  def main(args: Array[String]): Unit = {
//    def getReadMysqlPartitionByHourString(startTime:String, numPartitions:Int, beforeDays:Int):Array[(String,String)]={
//      val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
//      val partitionArray = new ArrayBuffer[(String,String)]
//      val incHour = (24*beforeDays) / numPartitions
//      val c = Calendar.getInstance()
//      val start1 = startTime
//      val startDate = sdf.parse(start1)
//      println("startDate>>>"+startDate)
//      c.setTime(startDate)
//      var start = start1
//      for(i<- 1 to numPartitions){
//        c.add(Calendar.HOUR_OF_DAY, incHour)
//        val end = sdf.format(c.getTime)
//        println("end>>>"+end)
//        partitionArray.+=(start -> end)
//        start = end
//        println("start>>>"+start)
//      }
//      partitionArray.toArray
//    }
//    val dateCondition = DateUtil.getLastStringTime("2023-09-06 14:00:00",30)
//    println("dateCondition==="+dateCondition) //2023-08-07 14:00:00
//    val beforeDay = 30
//    val predicates = getReadMysqlPartitionByHourString(dateCondition,24,beforeDay)
//      .map{case (start, end) =>
//        s"actualTime > '"+start+"' and actualTime <= '"+end+"'"}
//    println("----->>"+predicates)
//
//
//    val countTime = "2023-09-06 14:00:00" //业务时间,也就是每20分钟  统计时间"yyyy-MM-dd HH:mm:ss"
//    val countDate = DateUtil.df2Todf3(countTime) //统计时间"yyyyMMdd"
//    val incDay = DateUtil.df2Todf3(countTime)
//    val incHour = countTime.substring(11, 13).concat(countTime.substring(14, 16))
//    val last14Day = DateUtil.getLastDayStringdf3(countDate, 14)
//    val next4Day = DateUtil.getLastStringTime(countTime,-5).substring(0, 10).concat(" 00:00:00") //统计时间"yyyy-MM-dd HH:mm:ss" 取00:00:00
//    val last3Day = DateUtil.getLastStringTime(countTime,3).substring(0, 10).concat(" 00:00:00") //统计时间"yyyy-MM-dd HH:mm:ss"取00:00:00
//    val last8Day = DateUtil.getLastDayStringdf3(DateUtil.df2Todf3(countTime), 4)
//    val next8Day = DateUtil.getLastDayStringdf3(DateUtil.df2Todf3(countTime), -5)
//    println("countDate="+countDate)
//    println("incDay="+incDay)
//    println("incHour="+incHour)
//    println("last14Day="+last14Day)
//    println("next4Day="+next4Day)
//    println("last3Day="+last3Day)
//    println("last8Day="+last8Day)
//    println("next8Day="+next8Day)
    println("DateUtil.getDateString(0)="+DateUtil.getDateString(0))

  }
}
