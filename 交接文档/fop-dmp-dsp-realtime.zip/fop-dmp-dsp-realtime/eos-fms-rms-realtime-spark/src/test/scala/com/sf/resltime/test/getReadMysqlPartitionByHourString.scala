package com.sf.resltime.test

object getReadMysqlPartitionByHourString {

}
