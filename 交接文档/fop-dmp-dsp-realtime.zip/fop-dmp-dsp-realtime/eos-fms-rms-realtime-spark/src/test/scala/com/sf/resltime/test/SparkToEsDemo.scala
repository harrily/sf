package com.sf.resltime.test


import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.elasticsearch.spark.sql._
/**
 * @Author 01419728
 * @Date 2022/4/29 11:15
 */
object SparkToEsDemo {
  def main(args: Array[String]): Unit = {

/*    val spark = SparkSession
      .builder()
      .master("local[1]")
      .enableHiveSupport()
      .getOrCreate()*/



    //DataFrameReader/
    //read
    val conf = new SparkConf()
    conf.set("es.nodes","10.202.116.33,10.202.116.34,10.202.116.35")                                                 //测试环境
    conf.set("es.port","9200")
    conf.set("es.mapping.date.rich","true")
    conf.set("es.nodes.wan.only","true")
    conf.set("es.internal.es.version","5.4.1")
    conf.set("es.internal.es.cluster.name","bdp-eos-fms-rms-ssd")
    conf.set("es.input.max.docs.per.partition","10000000")
    conf.set("spark.sql.shuffle.partitions", "100")
    conf.set("spark.default.parallelism", "100")
    conf.set("spark.shuffle.file.buffer", "64")
    conf.set("spark.sql.caseSensitive","true")
    conf.set("es.mapping.date.rich","false")
    val sparkRead = SparkSession.builder()
      .config(conf)
      .enableHiveSupport()
      .master("local[4]")                                                            //测试环境
      .getOrCreate()

    val options = Map(
      "es.nodes" -> "10.202.116.33,10.202.116.34,10.202.116.35",
      "es.port" -> "9200",
      "es.nodes.wan.only" -> "true"
      //  "" -> ""
    )
  /*  spark
      .read
      .format("es")
      .options(options)
      .load("cemp_large_ac_waybill/cemp_large_ac_waybill")
      .show(10)*/
    //DataFrameWriter
    //write
   /* val df = spark
      .read
      .format("csv")
      .option("sep", "\t")
      .option("header", "true")
      .load("D:\\user\\01419728\\Downloads\\batch_info_0425_1.csv")

    df.write
      .format("org.elasticsearch.spark.sql")
      .options(options)
      .mode(SaveMode.Append)
      .save("index2/docs2")*/
    //使用EsSparkSQL  read
    /**
     * resource:
     * query:DSL查询语句
     * cfg:es配置
     */
    EsSparkSQL.esDF(sparkRead,"risp_waybills_v2/risp_waybills_v2").show(5)

    //使用EsSparkSQL  write
    /*
     * resource:
     * query:es配置
     * cfg: DSL查询语句
    */
   // df.saveToEs("index4/doc4",options)



  }




}
