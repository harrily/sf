package com.sf.resltime.test

import com.sf.realtime.common.utils.DateUtil
import com.sf.realtime.spark.utils.SqlUtil
import com.sf.realtime.spark.utils.{CacheUtil, KgMysqlUtil, TidbUtil}
import java.time.format.DateTimeFormatter
import java.time.{LocalDateTime, ZoneOffset}
import com.sf.realtime.spark.context.Context
/**
 * @Author 01419728
 * @Date 2022/6/15 18:11
 */
object  ReadMysqlDFTest {
  def main(args: Array[String]): Unit = {
    val  startDate = "2022-06-01 00:00:00"
    val beforDay = "7".toInt
    val df2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
   // val startTm = LocalDateTime.parse(startDate, df2).toInstant(ZoneOffset.of("+8")).toEpochMilli
//    val startTm = LocalDateTime.parse(currentTime, df2).minusDays(beforDay).toInstant(ZoneOffset.of("+8")).toEpochMilli
   // println(LocalDateTime.now().format(df2))
val spark = Context.getContext(true)
  val kgTableName = "(select require_id,zone_code,next_zone_code,prologis_in_tm from t_transportct_info where prologis_in_tm is not null ) as t"
    val kgData = KgMysqlUtil.read(kgTableName,spark.sqlContext)
  println("-----")

    //println(startTm)
   // val array = SqlUtil.getReadMysqlPartitionByHourTime(startTm, 24 , beforDay)
   // for (elem <- array.toArray) {
     // println("start-->end: "+elem._1+"-->"+elem._2)
   // }
  }

}
