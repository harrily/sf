package com.sf.resltime.test

import org.apache.spark.sql.hive.HiveContext

/**
 * @Author 01419728
 * @Date 2022/4/21 19:17
 */
object sparkReadHive {
  def main(args: Array[String]): Unit = {
//    val hivectx = new HiveContext()
  }

}
