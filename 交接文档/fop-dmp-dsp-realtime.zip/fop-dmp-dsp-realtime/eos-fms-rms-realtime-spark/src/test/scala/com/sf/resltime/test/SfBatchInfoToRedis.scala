package com.sf.resltime.test

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.realtime.common.utils.{MD5Util, RedisClusterPool}
import com.sf.realtime.hbase.HbaseUtil
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import redis.clients.jedis.JedisCluster

/**
 * Spark --->HBase;  hbase班次表,dim_sf_batch_info,rowkey的设计,MD5Util.getMD5("dim_sf_batch_info" + "_" + zonecode)
 * hbase表的设计:
 * rowkey                        baseInfo: batch_code_work_day                     baseInfo:
 * dim_sf_batch_info_755W             {"invld_dt":"9999-12-31", "valid_dt""=2022-02-07", "last_arr_tm"="0925", "start_tm"="0925","end_tm"="0924"}
 */
object SfBatchInfoToRedis {
  def main(args: Array[String]): Unit = {
    System.setProperty("hadoop.home.dir", "D:\\Program Files\\hadoop-2.7.7");

    //val currentTime = args(0) //20220422
    val currentTime = "20220424"
    //val spark: SparkSession = Context.getContext(true)
    val spark = SparkSession.builder().master("local[1]").getOrCreate()
    val frame = spark.read.format("csv")
      .option("sep", "\t")
      .option("header", "true")
      .load("D:\\user\\01419728\\Downloads\\batch_info_0425_1.csv")

    /*    val sql: String =
    """
        select zonecode,collect_set(aa) batchinfo
        from
          (select
              zonecode,
              named_struct('batch_code',batch_code,'start_tm',start_tm,'end_tm',end_tm,'work_day',work_day,'valid_dt',valid_dt,'invld_dt',invld_dt,'last_arr_tm',last_arr_tm) aa,
              last_arr_tm
          FROM dm_ordi_predict.batch_info
          where inc_day = '"""+ currentTime +"""'
          DISTRIBUTE BY zonecode SORT BY zonecode,last_arr_tm asc) t1
        group by zonecode
            """*/
    //    val frame: DataFrame = spark.sqlContext.sql(sql)
    frame.show(5)


    frame.toJSON.foreachPartition((it: Iterator[String]) => {
      if (it.nonEmpty) {
        val jedis: JedisCluster = RedisClusterPool.getConn
        var j:Long=0L
        it.foreach(f = (data: String) => {
          var i:Long=0L
          if (data.nonEmpty) {
            val content: JSONObject = JSON.parseObject(data)
            val zonecode: String = content.getString("zonecode")
            val workday: String = content.getString("workday")
            val redisKey = "dim_sf_batch_info"+"_" + zonecode
            val field = workday
            val batchinfo: String = content.getString("batchinfo")
            i = jedis.hset(redisKey, field, batchinfo)
          }
          if (i>0L) {
            j=j+1
          }
          println("共写入redis"+j+"条数据")
        })
      }
    })
    spark.stop()
  }
}


