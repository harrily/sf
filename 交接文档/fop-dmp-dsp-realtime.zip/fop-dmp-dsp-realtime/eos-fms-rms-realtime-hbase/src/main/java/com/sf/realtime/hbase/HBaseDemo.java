package com.sf.realtime.hbase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.realtime.common.utils.MD5Util;
import com.sf.realtime.common.utils.RedisClusterPool;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.compress.Compression;
import org.apache.hadoop.hbase.util.Bytes;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;


public class HBaseDemo {

    //声明表的管理类
    private HBaseAdmin admin = null;
    //声明表的数据的CRUD的类对象
    private HTable table = null;
    //表名
    private String tableName = "dim_sf_batch_info";
//    @Before
    @Test
    public void init() throws IOException {
        //System.setProperty("hadoop.home.dir", "D:\\Program Files\\hadoop-2.7.7");

        Configuration conf = new Configuration();
        Config config = ConfigFactory.load();
        // zookeeper集群的URL配置信息
        conf.set("hbase.zookeeper.quorum", config.getString("hbase.zk.quorum"));
        // 客户端连接zookeeper端口
        conf.set("hbase.zookeeper.property.clientPort", config.getString("hbase.zk.client.port" ));
        //实例化admin对象
        admin = new HBaseAdmin(conf);
        //实例化table对象
        table = new HTable(conf,tableName.getBytes());
    }
//    @After
    @Test
    public void close() throws IOException {
        if(table!=null)
            table.close();
        if(admin!=null)
            admin.close();
    }
    /**
     * 创建表
     */
    @Test
    public void createTable() throws IOException {
        //定义表描述符对象
        HTableDescriptor desc = new HTableDescriptor(TableName.valueOf(tableName));
        //指定列族名字以及压缩格式
        HColumnDescriptor famliy = new HColumnDescriptor("baseInfo".getBytes()).setCompactionCompressionType(Compression.Algorithm.GZ);

        //将列族的描述符对象添加到表描述符中
        desc.addFamily(famliy);
        //判断表是否存在，如果存在，删除之前的表

        //System.out.println(admin);
        if(admin.tableExists(tableName)){
            //先禁用表
            admin.disableTable(tableName);
            //删除表
            admin.deleteTable(tableName);
        }
        admin.createTable(desc);
    }
    @Test
    public void truncateTable(){
        try {
            admin.disableTable(TableName.valueOf(tableName));
            admin.truncateTable(TableName.valueOf(tableName), true);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    @Test
    public void read(){
        String zonecode = "318CE";
        HbaseUtil hbaseUtil = null;
        try {
            hbaseUtil = HbaseUtil.getInstance();
            String rowkey = MD5Util.getMD5("dim_sf_batch_info" + "_" + zonecode);
            Result row = hbaseUtil.getRow(tableName, Bytes.toBytes(rowkey), Bytes.toBytes("baseInfo"),Bytes.toBytes(zonecode));
            byte[] baseInfos = row.getValue(Bytes.toBytes("baseInfo"), Bytes.toBytes(zonecode));
            System.out.println(Bytes.toString(baseInfos));
            //System.out.println(row);
//            String rowkey = MD5Util.getMD5("dim_sf_batch_info" + "_" + zonecode);
//            Result r = hbaseUtil.getRow("dim_sf_batch_info", Bytes.toBytes(rowkey), Bytes.toBytes("baseInfo"), Bytes.toBytes(zonecode));
//            System.out.println(r);
//            hbaseUtil.scan("dim_sf_batch_info");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}