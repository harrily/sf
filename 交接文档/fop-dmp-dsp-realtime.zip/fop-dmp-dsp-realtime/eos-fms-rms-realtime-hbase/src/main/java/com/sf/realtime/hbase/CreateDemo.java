package com.sf.realtime.hbase;

import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.HBaseAdmin;

/**
 * @Author 01419728
 * @Date 2022/7/27 11:19
 */
public class CreateDemo {
    public static void main(String[] args) throws Exception {
        Connection conn = HbaseUtil.getConn();
        Admin admin = conn.getAdmin();


        String tableName="oewm_warned_waybillNO_vehicleNo";

        if (!admin.isTableAvailable(TableName.valueOf(tableName))) {
            HTableDescriptor hbaseTable = new HTableDescriptor(TableName.valueOf(tableName));
            hbaseTable.addFamily(new HColumnDescriptor("baseInfo"));
            admin.createTable(hbaseTable);

        }
    }
}
