package com.sf.realtime.hbase.common;

public enum ColumnType {
    STRING,DOUBLE,LONG,INTEGER;
}
