package com.sf.realtime.hbase;

import com.sf.realtime.hbase.common.ColumnType;
import com.typesafe.config.Config;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.*;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Hbase2Util implements Serializable{
	private static Connection connection;
	private static Configuration configuration;
	private volatile static Hbase2Util hbaseUtil;
	private HBaseAdmin admin = null;

	private Hbase2Util() {
	}

	@SuppressWarnings("deprecation")
	public void init() throws Exception {
		Config config = com.sf.realtime.common.config.Config.getConfig();
		if (configuration == null) {
			configuration = HBaseConfiguration.create();
		}
		try {
			// zookeeper集群的URL配置信息
			configuration.set("hbase.zookeeper.quorum", config.getString("hbase2.zk.quorum"));
			// 客户端连接zookeeper端口
			configuration.set("hbase.zookeeper.property.clientPort", config.getString("hbase2.zk.client.port"));
			// hbase集群模式
			configuration.set("zookeeper.znode.parent", "/com/sf/realtime/hbase");
			// HBase RPC请求超时时间，默认60s(60000)
			configuration.setInt("hbase.rpc.timeout", 120000);
			// 客户端重试最大次数，默认35
			configuration.setInt("hbase.client.retries.number", 10);
			// 客户端发起一次操作数据请求直至得到响应之间的总超时时间，可能包含多个RPC请求，默认为2min
			configuration.setInt("hbase.client.operation.timeout", 360000);
			// 客户端发起一次scan操作的rpc调用至得到响应之间的总超时时间
			configuration.setInt("hbase.client.scanner.timeout.period", 200000);
			// 获取hbase连接对象
			if (connection == null || connection.isClosed()) {
				connection = ConnectionFactory.createConnection(configuration);
			}
			admin = new HBaseAdmin(configuration);
		} catch (Exception e) {
			throw e;
		}
	}

	public static void close() {
		try {
			if (connection != null)
				connection.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConn() throws Exception {
		if (connection != null){
			return connection;
		}else{
			getInstance();
			return connection;
		}

	}

	public static void batchFlush(String tableName,List<Put> puts) throws IOException {
		BufferedMutatorParams params = new BufferedMutatorParams(TableName.valueOf(tableName));
		params.writeBufferSize(5*1024*1024);
		BufferedMutator mutator = connection.getBufferedMutator(params);
		mutator.mutate(puts);
		mutator.flush();
		System.out.println("完成提交（success submit）："+mutator.getWriteBufferSize());
		puts.clear();
	}

	public static Hbase2Util getInstance() throws Exception {
		if (hbaseUtil == null) {
			synchronized (Hbase2Util.class) {
				if (hbaseUtil == null) {
					hbaseUtil = new Hbase2Util();
					hbaseUtil.init();
				}
			}
		}
		return hbaseUtil;
	}

	public void save(String tableName, List<Put> puts) throws IOException {
		Table table = connection.getTable(TableName.valueOf(tableName));
		table.put(puts);
		table.close();
	}
	
	public void truncate(String tableName) throws IOException {
		admin.disableTable(TableName.valueOf(tableName));
		admin.truncateTable(TableName.valueOf(tableName), true);
	}

	public void scan(String tableName)throws IOException{
		Table table = null;
		Result result = null;
		try {
			table = connection.getTable(TableName.valueOf(tableName));
			Scan scan = new Scan();
			ResultScanner scanner = table.getScanner(scan);
			while ((result = scanner.next()) != null){
				List<Cell> cells = result.listCells();
				for (Cell cell : cells) {
					// 打印rowkey,family,qualifier,value
					System.out.println(Bytes.toString(CellUtil.cloneRow(cell))
							+ "==> " + Bytes.toString(CellUtil.cloneFamily(cell))
							+ "{" + Bytes.toString(CellUtil.cloneQualifier(cell))
							+ ":" + Bytes.toString(CellUtil.cloneValue(cell)) + "}");
				}
			}
		}finally {
            if(table != null){
            	table.close();
			}
		}
	}

	public boolean checkExist(String tablename, String rowKey) throws IOException {
		Table table = null;
		Result result = null;
		try {
			table = connection.getTable(TableName.valueOf(tablename));
			Get get = new Get(Bytes.toBytes(rowKey));
			get.setCheckExistenceOnly(true);
			result = table.get(get);
		} finally {
			table.close();
		}
		return result.getExists();
	}

	public Result getRow(String tablename, byte[] row) throws IOException {
		Table table = null;
		Result result = null;
		try {
		    if(connection == null || connection.isClosed()){
		        getConn();
            }
			table = connection.getTable(TableName.valueOf(tablename));
			Get get = new Get(row);
			result = table.get(get);
		} catch (Exception e) {
            e.printStackTrace();
        } finally {
		    if(table != null) {
                table.close();
            }
		}
		return result;
	}

	public Result[] getList(String tableName, List<Get> gets) throws Exception{
		Table table = null;
		Result[] results = null;
		try{
			if(connection==null){
				synchronized (Hbase2Util.class){
					if(connection == null)
						init();
				}
			}
			table = connection.getTable(TableName.valueOf(tableName));
			results = table.get(gets);
		}finally {
			if(table!=null)
				table.close();
		}
		return results;
	}

	public Map<String,Object> getResult(String tableName, String rowKey, String familyName) throws Exception {
		Table table = connection.getTable(TableName.valueOf(tableName));
		// 获得一行
		Get get = new Get(Bytes.toBytes(rowKey));
		get.addFamily(Bytes.toBytes(familyName));
		Result set = table.get(get);
		Map<String,Object> map = new HashMap<>();
		if(set != null && set.listCells() != null) {
			for (Cell cell : set.listCells()) {
				long timestamp = cell.getTimestamp();
				String family = Bytes.toString(CellUtil.cloneFamily(cell));
				String qualifier = Bytes.toString(CellUtil.cloneQualifier(cell));
				if(qualifier.equals("packageMeterageWeightQty") || qualifier.equals("meterageWeightQty")){
					Double value = Bytes.toDouble(CellUtil.cloneValue(cell));
					map.put(qualifier, value);
				}else{
					String value = Bytes.toString(CellUtil.cloneValue(cell));
					map.put(qualifier, value);
				}
			}
		}
		table.close();
		return map;
	}

	public Object getResult(String tableName, String rowKey, String family, String columnName, ColumnType type) throws Exception {
		if(connection==null || connection.isClosed()){
			synchronized (Hbase2Util.class){
				if(connection == null)
					init();
			}
		}
		Table table = connection.getTable(TableName.valueOf(tableName));
		// 获得一行
		Get get = new Get(Bytes.toBytes(rowKey));
		get.addColumn(Bytes.toBytes(family),Bytes.toBytes(columnName));
		Result set = table.get(get);
		List<Object> values = new ArrayList<>();
		if(set != null && set.listCells() != null) {
			for (Cell cell : set.listCells()) {
				long timestamp = cell.getTimestamp();
				String familyName = Bytes.toString(CellUtil.cloneFamily(cell));
				String qualifier = Bytes.toString(CellUtil.cloneQualifier(cell));
				Object value;
				switch (type) {
					case STRING:
						value = Bytes.toString(CellUtil.cloneValue(cell));
						break;
					case DOUBLE:
						value = Bytes.toDouble(CellUtil.cloneValue(cell));
                        break;
					case LONG:
						value = Bytes.toLong(CellUtil.cloneValue(cell));
                        break;
					case INTEGER:
						value = Bytes.toInt(CellUtil.cloneValue(cell));
                        break;
					default:
						value = Bytes.toString(CellUtil.cloneValue(cell));
						break;
				}
				values.add(value);
			}
		}
		table.close();
		return values.size()==0?null:values.get(0);
	}

	public Map<String,Object> getResult(String tableName, String rowKey, String family, List<String> columnNames, ColumnType type) throws Exception {
		if(connection==null || connection.isClosed()){
			synchronized (Hbase2Util.class){
				if(connection == null)
					init();
			}
		}
		Table table = connection.getTable(TableName.valueOf(tableName));
		// 获得一行
		Get get = new Get(Bytes.toBytes(rowKey));
		for(String columnName : columnNames){
			get.addColumn(Bytes.toBytes(family),Bytes.toBytes(columnName));
		}

		Result set = table.get(get);
		Map<String,Object> values = new HashMap<>();
		if(set != null && set.listCells() != null) {
			for (Cell cell : set.listCells()) {
				long timestamp = cell.getTimestamp();
				String familyName = Bytes.toString(CellUtil.cloneFamily(cell));
				String qualifier = Bytes.toString(CellUtil.cloneQualifier(cell));
				Object value;
				switch (type) {
					case STRING:
						value = Bytes.toString(CellUtil.cloneValue(cell));
						break;
					case DOUBLE:
						value = Bytes.toDouble(CellUtil.cloneValue(cell));
						break;
					case LONG:
						value = Bytes.toLong(CellUtil.cloneValue(cell));
						break;
					case INTEGER:
						value = Bytes.toInt(CellUtil.cloneValue(cell));
						break;
					default:
						value = Bytes.toString(CellUtil.cloneValue(cell));
						break;
				}
				values.put(qualifier,value);
			}
		}
		table.close();
		return values;
	}

	public List<String> getAllTables() {
		List<String> tables = null;
		if (admin != null) {
			try {
				HTableDescriptor[] allTable = admin.listTables();
				if (allTable.length > 0)
					tables = new ArrayList<String>();
				for (HTableDescriptor hTableDescriptor : allTable) {
					tables.add(hTableDescriptor.getNameAsString());
					System.out.println(hTableDescriptor.getNameAsString());
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return tables;
	}

	/**
	 * 根据表名，rowKey，列族名，列名得到一行数据
	 * @param tableName 表名
	 * @param rowKey rowKey
	 * @param cfName 列族名
	 * @param qualifier 列名
	 * @return Result
	 * @throws IOException
	 */
	public Result getRow(String tableName, byte[] rowKey, byte[] cfName, byte[] qualifier)throws IOException{
		Table table = null;
		Result result = null;
		try{
			table = connection.getTable(TableName.valueOf(tableName));
			Get get = new Get(rowKey);
			get.addColumn(cfName, qualifier);
			result = table.get(get);
		}finally {
			if(table!= null)
				table.close();
		}
		return result;
	}

	public Map<String,Object> getResult(String tableName, String rowKey, String family, List<String> columnNames, Map<String,ColumnType> types) throws Exception {
		if(connection==null || connection.isClosed()){
			synchronized (Hbase2Util.class){
				if(connection == null)
					init();
			}
		}
		Table table = connection.getTable(TableName.valueOf(tableName));
		// 获得一行
		Get get = new Get(Bytes.toBytes(rowKey));
		for(String columnName : columnNames){
			get.addColumn(Bytes.toBytes(family),Bytes.toBytes(columnName));
		}

		Result set = table.get(get);
		Map<String,Object> values = new HashMap<>();
		if(set != null && set.listCells() != null) {
			for (Cell cell : set.listCells()) {
				long timestamp = cell.getTimestamp();
				String familyName = Bytes.toString(CellUtil.cloneFamily(cell));
				String qualifier = Bytes.toString(CellUtil.cloneQualifier(cell));
				Object value;
				switch (types.get(qualifier)) {
					case STRING:
						value = Bytes.toString(CellUtil.cloneValue(cell));
						break;
					case DOUBLE:
						value = Bytes.toDouble(CellUtil.cloneValue(cell));
						break;
					case LONG:
						value = Bytes.toLong(CellUtil.cloneValue(cell));
						break;
					case INTEGER:
						value = Bytes.toInt(CellUtil.cloneValue(cell));
						break;
					default:
						value = Bytes.toString(CellUtil.cloneValue(cell));
						break;
				}
				values.put(qualifier,value);
			}
		}
		table.close();
		return values;
	}

	/**
	 * HBase 插入一条数据
	 * @param tablename 表名
	 * @param rowKey 唯一标识
	 * @param cfName 列族名
	 * @param qualifier 列标识
	 * @param data 数据
	 * @return 是否插入成功
	 * @throws IOException
	 */
	public boolean putRow(String tablename, byte[] rowKey, byte[] cfName, byte[] qualifier, byte[] data) throws IOException {
		Table table = null;
		try{
			table = connection.getTable(TableName.valueOf(tablename));
			Put put = new Put(rowKey);
			put.addColumn(cfName, qualifier, data);
			table.put(put);
		}finally{
			table.close();
		}
		return true;
	}

	public boolean putList(String tablename, List<Put> puts) throws IOException {
		Table table = null;
		try{
			table = connection.getTable(TableName.valueOf(tablename));
			table.put(puts);
		}finally{
			if(table!=null)
				table.close();
		}
		return true;
	}

	/**
	 * Append value to one or multiple columns
	 * @param tablename
	 * @param append
	 * @return
	 * @throws IOException
	 */
	public boolean appendRow(String tablename, Append append) throws IOException{
		Table table = null;
		try{
			table = connection.getTable(TableName.valueOf(tablename));
			table.append(append);
		}finally{
			if(table!=null)
				table.close();
		}
		return true;
	}

	/**
     * Method that does a batch call on Deletes, Gets, Puts, Increments and Appends.
	 * The ordering of execution of the actions is not defined. Meaning if you do a Put and a
	 * Get in the same call, you will not necessarily be
	 * guaranteed that the Get returns what the Put had put.
	 * @param tableName
	 * @param actions
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public Object[] actBatch(String tableName, final List<? extends Row> actions) throws Exception {
		Table table = null;
		Object[] results = new Object[actions.size()];
		try {
			if(connection == null){
				synchronized (Hbase2Util.class){
					if(connection == null){
						init();
					}
				}
			}
			table = connection.getTable(TableName.valueOf(tableName));
			table.batch(actions, results);
		} finally{
			if(table!=null)
				table.close();
		}
		return results;
	}
	
	public static void main(String[] args) throws Exception {
		System.out.println(Hbase2Util.getInstance().getResult("wb_info_data",new StringBuffer("SF7000302890512").reverse().toString(),"baseInfo"));
	}
}
