package com.sf.realtime.hbase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.realtime.common.utils.RedisClusterPool;
import org.junit.Test;
import redis.clients.jedis.Jedis;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;


public class BatchInfoFromRedis {
    public static void main(String[] args) throws Exception {
        //HbaseUtil hbaseUtil = HbaseUtil.getInstance();
        //获取rowkey
        String zonecode = "755W";
        String arrTime = "2022-04-16 23:30:30";

        DateTimeFormatter df2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        DateTimeFormatter df3 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime start = LocalDate.parse(arrTime, df2).atStartOfDay();
        String lastDay = start.minusDays(1).format(df3);
        String nextDay = start.minusDays(-1).format(df3);

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = formatter.parse(arrTime);
        String arrTmDay = arrTime.substring(0, 10);
        String arrTmHHmm = arrTime.substring(11, 13).concat(arrTime.substring(14, 16));
        //工作日判断
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int week_index = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (week_index < 0) {
            week_index = 0;
        }
        int lastDayWeek = week_index - 1;
        if (lastDayWeek == 0) {
            lastDayWeek = 7;
        }
        //从redis读取
        String redisKey = "dim_sf_batch_info";
        String field = zonecode + "_" + week_index;
        System.out.println("到达时间为:" + arrTime + "arrTmHHmm:" + arrTmHHmm+"  周"+week_index);

        Jedis jedis = new Jedis("H3B8ed-1.cachesit.sfcloud.local");
        String batchinfo = jedis.hget(redisKey, field);
        //String batchinfo = RedisClusterPool.getConn().hget(redisKey, field);
        String batch_date;
        if (!batchinfo.isEmpty()) {
            JSONArray batchArray = JSON.parseArray(batchinfo);
            int size = batchArray.size();
            if (size > 0) {
                for (int i = 0; i < size; i++) {
                    JSONObject batchObj = JSON.parseObject(batchArray.toArray()[i].toString());
                    //当天的第一个班次
                    JSONObject firstBatch = JSON.parseObject(batchArray.toArray()[0].toString());
                    String min_start_last_arr_tm = firstBatch.getString("start_last_arr_tm");
                    String invld_dt = batchObj.getString("invld_dt");
                    String last_arr_tm = batchObj.getString("last_arr_tm");
                    String valid_dt = batchObj.getString("valid_dt");
                    String batch_code = batchObj.getString("batch_code");
                    String start_last_arr_tm = batchObj.getString("start_last_arr_tm");
                    //0.判断有效性
                    if (invld_dt.compareTo(arrTmDay) > 0 && valid_dt.compareTo(arrTmDay) <= 0) {
                        //处理跨天班次情况
                        // 判断是否是属于前一天的班次  或者当天的班次
                        if (Integer.valueOf(arrTmHHmm) > Integer.valueOf(min_start_last_arr_tm)) {
                            if (Integer.valueOf(start_last_arr_tm) >= Integer.valueOf(last_arr_tm)) {
                                last_arr_tm = "2400";
                            }
                            //  属于当天的班次
                            //2.匹配当天的班次--->  arr_tm between start_last_arr_tm and last_arr_tm
                            if (Integer.valueOf(arrTmHHmm) < Integer.valueOf(last_arr_tm) && Integer.valueOf(arrTmHHmm) > Integer.valueOf(start_last_arr_tm)) {
                                System.out.println("匹配的班次是:" + batch_code + ":" + batchObj);
                                batch_date = arrTmDay;
                                System.out.println("匹配的班次日期是[当天]:" + batch_date);
                                //第一个取到的是就是
                                break;
                            }
                        }
                        if (i==size-1){
                            //属于昨天的班次
                            String field2 = zonecode + "_" + lastDayWeek;

                            String lastDayBatch = jedis.hget(redisKey, field2);
                            //String lastDayBatch = RedisClusterPool.getConn().hget(redisKey, field2);
                            if (!lastDayBatch.isEmpty()) {
                                JSONArray lastDayBatchArray = JSON.parseArray(lastDayBatch);
                                int size1 = lastDayBatchArray.size();
                                if (size1 > 0) {
                                    for (int j = (size1 - 1); j >= 0; j--) {
                                        batchObj = JSON.parseObject(lastDayBatchArray.toArray()[j].toString());
                                        //当天的第一个班次
                                        invld_dt = batchObj.getString("invld_dt");
                                        last_arr_tm = batchObj.getString("last_arr_tm");
                                        valid_dt = batchObj.getString("valid_dt");
                                        batch_code = batchObj.getString("batch_code");
                                        start_last_arr_tm = batchObj.getString("start_last_arr_tm");
                                        //判断有效性,取分区跨天的分区
                                        //0.判断有效性
                                        if (invld_dt.compareTo(arrTmDay) > 0 && valid_dt.compareTo(arrTmDay) <= 0) {
                                            //处理跨天班次情况
                                            if (Integer.valueOf(start_last_arr_tm) >= Integer.valueOf(last_arr_tm)) {
                                                start_last_arr_tm = "0000";
                                                if (Integer.valueOf(arrTmHHmm) < Integer.valueOf(last_arr_tm) && Integer.valueOf(arrTmHHmm) > Integer.valueOf(start_last_arr_tm)) {
                                                    System.out.println("匹配的班次是:" + batch_code + ":" + batchObj);
                                                    batch_date = lastDay;
                                                    System.out.println("匹配的班次日期是[前一天]:" + batch_date);
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    @Test
    public void deleteRedisData (){
        String redisKey = "dim_sf_batch_info";
        RedisClusterPool.getConn().del(redisKey);
    }
    @Test
    public void redisScan(){
        String redisKey = "dim_sf_batch_info";
        String zonecode = "351Q";
        String field = zonecode + "_" + "6";
        String arrTime = "2022-04-16 12:30:30";

        String batchinfo = RedisClusterPool.getConn().hget(redisKey,field);
        JSONArray batchArray = JSON.parseArray(batchinfo);
        for (int i = 0; i < batchArray.size(); i++) {
            System.out.println(batchArray.toArray()[i].toString());
        }
    }
}