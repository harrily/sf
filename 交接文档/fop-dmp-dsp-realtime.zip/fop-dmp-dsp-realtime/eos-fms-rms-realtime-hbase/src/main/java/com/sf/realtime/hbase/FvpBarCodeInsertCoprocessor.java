package com.sf.realtime.hbase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.coprocessor.BaseRegionObserver;
import org.apache.hadoop.hbase.coprocessor.ObserverContext;
import org.apache.hadoop.hbase.coprocessor.RegionCoprocessorEnvironment;
import org.apache.hadoop.hbase.regionserver.wal.WALEdit;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;
import java.net.URI;
import java.util.List;
import java.util.NavigableMap;

public class FvpBarCodeInsertCoprocessor extends BaseRegionObserver {

    /**
     * 此方法在真正的put方法调用之前进行调用
     * @param e RegionCoprocessorEnvironment
     * @param put 原本要插入的那条数据
     * @param edit
     * @param durability
     * @throws IOException
     */
    @Override
    public void prePut(ObserverContext<RegionCoprocessorEnvironment> e, Put put, WALEdit edit, Durability durability) throws IOException {
//        String uri = "hdfs://";
//        String dir = uri+"/tmp/sc/test1";
        String dir = "hdfs:///tmp/sc/test1";
        Configuration conf = new Configuration();
        FileSystem fs = FileSystem.get(URI.create(dir),conf);
        if(!fs.exists(new Path(dir))){
            fs.mkdirs(new Path(dir));
        }
        fs.close();

        String tbName = "wb_fvp_bar_data";
        byte[] columnFamily = Bytes.toBytes("baseInfo");
        Table table = e.getEnvironment().getTable(TableName.valueOf(tbName));
        //获取put对象里面的rowkey
        byte[] rowKey = put.getRow();
        NavigableMap<byte[], List<Cell>> cols   = put.getFamilyCellMap();
        List<Cell> list = cols.get(columnFamily);
        Cell putCell = list.get(0);
        //获取put对象里面的列名和列值
        byte[] colName  = CellUtil.cloneQualifier(putCell);
        byte[] value    = CellUtil.cloneValue(putCell);
        String valueStr = new String(value);
        //根据rowKey到HBase查找已存在的列，准备做append
        Get get = new Get(rowKey);
        get.addColumn(columnFamily,colName);
        Result result = table.get(get);
        JSONArray zoneCodes = JSON.parseArray("[]");
        JSONObject newZoneCode = JSON.parseObject(valueStr);
        //如果源数据并无该列存在，则直接将新得zoneCode加到一个空的JSONArray， 并返回该JSONArray的JSONString
        //如果源数据存在该列，取出，并append JSONObject
        Put put1 = new Put(rowKey);
        if(result.isEmpty()){
            zoneCodes.add(newZoneCode);
        }else {
            Cell[] cells = result.rawCells();
            Cell cell = cells[0];
            byte[] bytes = CellUtil.cloneValue(cell);
            String s = new String(bytes);
            zoneCodes = JSON.parseArray(s);
            zoneCodes.add(newZoneCode);
        }
        put1.addColumn(Bytes.toBytes("baseInfo"), colName, Bytes.toBytes(zoneCodes.toJSONString()));
        table.put(put1);
        table.close();
    }
}
