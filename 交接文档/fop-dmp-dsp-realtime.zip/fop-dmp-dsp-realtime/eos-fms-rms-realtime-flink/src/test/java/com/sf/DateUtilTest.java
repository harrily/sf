package com.sf;

import com.sf.realtime.common.utils.DateUtil;
import com.sf.realtime.flink.common.KafkaDataPreProcess;
import com.sf.realtime.flink.common.SqlUtil;
import com.sf.realtime.flink.schema.VehicleHasArriveBatchTaskSchema;
import lombok.val;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

/**
 * @Author 01419728
 * @Date 2022/7/16 16:58
 */
public class DateUtilTest {
    public static void main(String[] args) {
        /*System.out.println("定时调度的日期: "+DateUtil.getTimeWithHms(DateUtil.getDateString1(-1) + " 03:00:00"));
        System.out.println("获取明天的日期yyyy-MM-dd: "+DateUtil.getDateString1(-1));
        System.out.println("获取明天的调度时间日期yyyy-MM-dd: "+DateUtil.getDateString1(-1) + " 03:00:00");
        System.out.println("定时调度的间隔时间(ms): "+(DateUtil.getTimeWithHms(DateUtil.getDateString1(-1) + " 03:00:00") - System.currentTimeMillis()));*/
      /*  System.out.println(SqlUtil.getInsertByReplaceSql(new VehicleHasArriveBatchTaskSchema()));
        int[] types = KafkaDataPreProcess.getTypes(new VehicleHasArriveBatchTaskSchema());
        for (int type : types) {
            System.out.println(type);
        }*/
        String currentDate="2022-07-22 11:21:47";

        val last8Day = DateUtil.getLastDayStringdf3(DateUtil.df2Todf3(currentDate), 8);
        val next8Day = DateUtil.getLastDayStringdf3(DateUtil.df2Todf3(currentDate), -8);
        //可回刷使用lastUpdateTm进行控制
        val countTimeStamp = DateUtil.getTimeWithHms(currentDate); //统计时间"yyyy-MM-dd HH:mm:ss"
        val next7DaytTimeStamp = DateUtil.getLastTimeStamp(currentDate,-7); //统计时间"yyyy-MM-dd HH:mm:ss"
        val last7DayTimeStamp = DateUtil.getLastTimeStamp(currentDate,7);
        System.out.println(countTimeStamp);
        //System.out.println("countTimeStamp: "+last8Day+" next7DaytTimeStamp:"+next8Day+" last7DayTimeStamp:"+last7DayTimeStamp);
        //System.out.println(KafkaDataPreProcess.getTypes(new VehicleHasArriveBatchTaskSchema()));
    }
}
