package com.sf;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @Author 01419728
 * @Date 2022/2/19 11:37
 */
public class Test {
    public static void main(String[] args) throws Exception {
     String a  = "[\n" +
             "  {\n" +
             "    \"passZoneCode\": \"P025CDA\",\n" +
             "    \"sortNum\": 1,\n" +
             "    \"jobType\": 1,\n" +
             "    \"loadContnrNos\": \"389212010994,389212010985\",\n" +
             "    \"actualPassZoneCode\": \"P025CDA\"\n" +
             "  },\n" +
             "  {\n" +
             "    \"passZoneCode\": \"P571CDA\",\n" +
             "    \"arriveContnrNos\": \"389212010985\",\n" +
             "    \"sortNum\": 2,\n" +
             "    \"unloadContnrNos\": \"389212010985\",\n" +
             "    \"jobType\": 3,\n" +
             "    \"loadContnrNos\": \"389212011007\",\n" +
             "    \"actualPassZoneCode\": \"P571CDA\"\n" +
             "  },\n" +
             "  {\n" +
             "    \"passZoneCode\": \"P020CDD\",\n" +
             "    \"arriveContnrNos\": \"389212011007,389212010994\",\n" +
             "    \"sortNum\": 3,\n" +
             "    \"jobType\": 2\n" +
             "  }\n" +
             "]";
        System.out.println(a);


        JSONArray ja = JSONArray.parseArray(a);
        int length = ja.toArray().length;
        List<JSONObject> passZoneList = new ArrayList();
        for(int i=1;i<=length;i++){
            for(Object o:ja.toArray()){
                JSONObject j = (JSONObject) o;
                int sort = j.getInteger("sortNum");
                if(sort == i && StringUtils.isNotEmpty(j.getString("actualPassZoneCode"))){
                    passZoneList.add(j);
                    break;
                }
            }
        }

        int passSize = passZoneList.size();
        for (JSONObject jsonObject : passZoneList) {
            System.out.println(jsonObject);
            System.out.println("-----------");
        }

        HashMap<String, String> loadCarCode = new HashMap<String, String>();

        for(int i = 0;i<passSize-1;i++){
            //            始发+目的地+车标
            //获取始发
            String srcZoneCode = passZoneList.get(i).getString("actualPassZoneCode")==null? passZoneList.get(i).getString("passZoneCode"): passZoneList.get(i).getString("actualPassZoneCode");
            System.out.println("始发网点："+srcZoneCode);
            //根据始发网点的装车车标,判断车标在哪个网点应到
            //2. 获取当前网点装车车标
            String loadContnrNos=passZoneList.get(i).getString("loadContnrNos");
            String[] loadCars = loadContnrNos.split(",");
            for (int i1 = 0; i1 < loadCars.length; i1++) {
                loadCarCode.put(loadCars[i],srcZoneCode);
            }
            //3. 获取
            String secondJobType=passZoneList.get(i+1).getString("jobType");
//            判断secondJobType
//
//            为1,只装不卸的网点--->     (发车网点+车标+后续网点)、                          (当前网点+车标+后续网点)
//            为2,只卸不装的经停网点     (发车网点+车标+后续网点)、(发车网点+车标+当前网点)
//            220609128061295 为3,装卸                   (发车网点+车标+后续网点)、(发车网点+车标+当前网点)、(当前网点+车标+后续网点)
//            "actualPassZoneCode": "P025CDA", 									"loadContnrNos": "389212010994,389212010985",
//                    "actualPassZoneCode": "P571CDA", "arriveContnrNos": "389212010985","loadContnrNos": "389212011007","unloadContnrNos": "389212010985",
//                    "passZoneCode": "P020CDD",       "arriveContnrNos": "389212011007,389212010994",

        }
        System.out.println("网点+装车车标"+loadCarCode);
        }
}
