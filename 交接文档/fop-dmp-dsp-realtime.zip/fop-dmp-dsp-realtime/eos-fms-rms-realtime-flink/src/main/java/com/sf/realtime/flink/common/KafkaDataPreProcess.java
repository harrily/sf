package com.sf.realtime.flink.common;

import com.alibaba.fastjson.JSONObject;
import com.sf.realtime.flink.field.Field;
import com.sf.realtime.flink.field.Types;
import com.sf.realtime.flink.schema.Schema;
import org.apache.flink.types.Row;

import java.sql.Timestamp;

public class KafkaDataPreProcess {
    public static Row getRow(Schema schema, JSONObject pre){
        Row r = new Row(schema.getFields().size());
        for(int i=0;i<schema.getFields().size();i++){
            Field f = schema.getFields().get(i);
            Types type = f.getType();
            switch (type){
                case DECIMAL:
                    r.setField(i,pre.getBigDecimal(f.getName()));
                    break;
                case INTEGER:
                    r.setField(i,pre.getInteger(f.getName()));
                    break;
                case STRING:
                    r.setField(i,pre.getString(f.getName()));
                    break;
                case LONG:
                    r.setField(i,pre.getLong(f.getName()));
                    break;
                case DOUBLE:
                    r.setField(i,pre.getDouble(f.getName()));
                    break;
                case BOOLEAN:
                    r.setField(i,pre.getBoolean(f.getName()));
                    break;
                case TIMESTAMP: //NOSONAR
                    if(f.getName().equalsIgnoreCase("insertTime")){
                        r.setField(i,new Timestamp(System.currentTimeMillis()));
                    }else{
                        r.setField(i,pre.getTimestamp(f.getName()));
                    }
                    break;
                case DATE:
                    r.setField(i,pre.getDate(f.getName()));
                    break;
                default:

            }
        }
        return r;
    }

    public static int[] getTypes(Schema schema){
        int[] types = new int[schema.getFields().size()];
        for(int i=0;i<schema.getFields().size();i++){
            Field f = schema.getFields().get(i);
            switch(f.getType()){
                case INTEGER:
                    types[i] = java.sql.Types.INTEGER;
                    break;
                case STRING:
                    types[i] = java.sql.Types.VARCHAR;
                    break;
                case LONG:
                    types[i] = java.sql.Types.BIGINT;
                    break;
                case DOUBLE:
                    types[i] = java.sql.Types.DOUBLE;
                    break;
                case BOOLEAN:
                    types[i] = java.sql.Types.BOOLEAN;
                    break;
                case TIMESTAMP:
                    types[i] = java.sql.Types.TIMESTAMP;
                    break;
                default:
            }
        }
        return types;
    }

}
