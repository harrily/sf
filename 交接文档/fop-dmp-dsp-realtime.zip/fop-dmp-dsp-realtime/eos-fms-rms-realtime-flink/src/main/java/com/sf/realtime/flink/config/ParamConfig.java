package com.sf.realtime.flink.config;

import com.sf.realtime.common.config.Config;

import java.util.Properties;

public class ParamConfig {

    public static Properties configByKafka(String kafkaClusterName,String taskName){
        Properties props = new Properties();
        props.put("bootstrap.servers", Config.getConfig().getString(kafkaClusterName+".kafka.bootstrap.servers"));
        props.put("zookeeper.connect", Config.getConfig().getString(kafkaClusterName+".kafka.zookeeper.connect"));
        props.put("group.id",  Config.getConfig().getString(kafkaClusterName+".kafka."+taskName+".task.group.id"));
        props.put("enable.auto.commit", "true");
        props.put("auto.commit.interval.ms", "1000");
        props.put("auto.offset.reset", Config.getConfig().getString(kafkaClusterName+".kafka.auto.offset.reset"));
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        return props;
    }
}
