package com.sf.realtime.flink.main;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.realtime.common.config.Config;
import com.sf.realtime.common.utils.DateUtil;
import com.sf.realtime.flink.common.KafkaDataPreProcess;
import com.sf.realtime.flink.common.SqlUtil;
import com.sf.realtime.flink.config.ParamConfig;
import com.sf.realtime.flink.dto.BigVehicleHasArriveDto;
import com.sf.realtime.flink.schema.BigVehicleHasArriveTaskSchema;
import com.sf.realtime.flink.schema.Schema;
import com.sf.realtime.flink.sink.BigVehicleHasArriveSink;
import com.sf.realtime.flink.sink.MysqlSink;
import com.sf.realtime.flink.util.JDBCUtil;
import com.sf.realtime.hbase.HbaseUtil;
import com.sf.realtime.hbase.common.ColumnType;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer08;
import org.apache.flink.streaming.util.serialization.SimpleStringSchema;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

public class BigHasArriveCarTask {
    private static final String topic = Config.getConfig().getString("other2.kafka.car.require.task.topic");
    private static final String taskName = "car.require";
    private static final String kafkaClusterName = "other2";
    //TODO 写入表 vt_has_arrive_cars_big
    private static final Schema schema = new BigVehicleHasArriveTaskSchema();
    private static final int HBASE_BATCH_QUERY_SIZE = 1000;

    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.enableCheckpointing(1000);
        env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        env.setParallelism(16);
        String filterTime1 = args[0];
        String filterTime2 = args[1];
        String filterTime = filterTime1 + " "+filterTime2;

        Set<String> deptInfo = new HashSet<>();
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try {
            conn = JDBCUtil.getConn();
            //TODO 修改白名单
            String sql = "select * from dim_heavy_transit_info_big";
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
//                System.out.println(rs.getString("dept_code"));
                deptInfo.add(rs.getString("dept_code"));
            }
        } catch (SQLException e) {
        }finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }



        //加载快运网点数据
        DataStream<String> data;
        Properties props = ParamConfig.configByKafka(kafkaClusterName,taskName);
        props.replace("group.id","eos-fms-rms-realtime-flink-vechile-has-arrive-big");
        props.replace("auto.offset.reset","smallest");
        data = env.addSource(new FlinkKafkaConsumer08<String>(topic, new SimpleStringSchema(), props)).name("big-vechile-has-arrive").setParallelism(4);
        data.rebalance().map((MapFunction<String, JSONObject>) src->{
            return JSON.parseObject(src);
        }).filter((FilterFunction<JSONObject>) json-> {
//            System.out.println("======1====="+DateUtil.getTimeWithHms(filterTime));
//            System.out.println("======2====="+json.getLongValue("createTm"));
//            System.out.println("======3====="+json.getLong("createTm"));
            return StringUtils.isNotEmpty(json.getString("lineRequireId")) && DateUtil.getTimeWithHms(filterTime)<json.getLongValue("lastUpdateTm");
        }).map(new MapFunction<JSONObject, Set<JSONObject>>() {
            @Override
            public Set<JSONObject> map(JSONObject jsonObject) throws Exception {
                Set<JSONObject> js = new HashSet<JSONObject>();
                Integer transoportLevel = jsonObject.getInteger("transoportLevel");
                Integer carStatus = jsonObject.getInteger("carStatus");
                String lineCode = jsonObject.getString("lineCode");
                JSONArray ja = jsonObject.getJSONArray("passZoneList");
                int length = ja.toArray().length;
                //获取经过的网点
                List<JSONObject> passZoneList = new ArrayList();
                for(int i=1;i<=length;i++){
                    for(Object o:ja.toArray()){
                        JSONObject j = (JSONObject) o;
                        int sort = j.getInteger("sortNum");
                        if(sort == i && StringUtils.isNotEmpty(j.getString("actualPassZoneCode"))){
                            passZoneList.add(j);
                            break;
                        }
                    }
                }
                int passSize = passZoneList.size();
                for(int i = 0;i<passSize-1;i++){
                    String srcZoneCode = passZoneList.get(i).getString("actualPassZoneCode");
                    String destZoneCode = passZoneList.get(i+1).getString("actualPassZoneCode");
                    if(deptInfo.contains(destZoneCode)){
                        JSONObject jo = passZoneList.get(i+1);
                        Integer jobType = jo.getInteger("jobType");
                        String requireId = jo.getString("lineRequireId");
                        //获取发车时间
                        JSONObject j = passZoneList.get(i);
                        Long sendTime = j.getLong("actualDepartTm")==null?
                                (j.getLong("preDepartTm")==null?j.getLong("planDepartTm"):j.getLong("preDepartTm"))
                                :j.getLong("actualDepartTm");
                        //获取到达时间
                        Long actualArriveTime = jo.getLong("actualArriveTm")==null?
                                (jo.getLong("preArriveTm")==null?jo.getLong("planArriveTm"):jo.getLong("preArriveTm"))
                                :jo.getLong("actualArriveTm");
                        Boolean flag = jobType==null?false:(jobType == 2) || (jobType == 3);
                        if(flag){
                            String carNos = jo.getString("unloadContnrNos");
                            if((i+1)==(passSize-1)) {
                                if (StringUtils.isEmpty(carNos)) {
                                    carNos = jo.getString("arriveContnrNos");
                                }
                                if (StringUtils.isEmpty(carNos)) {
                                    carNos = jo.getString("attr2");
                                }
                            }
                          if(StringUtils.isNotEmpty(carNos)){
                              for(String carNo:carNos.split(",")){
                                  JSONObject rj = new JSONObject();
                                  rj.put("requireId",requireId);
                                  rj.put("carNo",carNo);
                                  rj.put("srcZoneCode",srcZoneCode);
                                  rj.put("destZoneCode",destZoneCode);
                                  rj.put("actualArriveTime",actualArriveTime);
                                  rj.put("transoportLevel",transoportLevel);
                                  rj.put("carStatus",carStatus);
                                  rj.put("sendTime",sendTime);
                                  rj.put("lineCode",lineCode);
                                  js.add(rj);
                              }
                          }
                        }

                    }
                }
                return js;
            }
        }).map(new MapFunction<Set<JSONObject>, List<BigVehicleHasArriveDto>>() {
            @Override
            public  List<BigVehicleHasArriveDto> map(Set<JSONObject> jsonObjects) throws Exception {
                HbaseUtil hbase = HbaseUtil.getInstance();
                List<BigVehicleHasArriveDto> rList = new ArrayList<>();
                for(JSONObject j : jsonObjects){
                    BigVehicleHasArriveDto dto = new BigVehicleHasArriveDto();
                    Double weights = 0D;
                    Long tickets = 0L;
                    Long tm = 0L;
                    Double wt = 0D;
                    String carNo = j.getString("carNo");
                    String  destZoneCode = j.getString("destZoneCode");
                    //获取车标运单的关系
                    Result r =  hbase.getRow("rt_container_waybill_relation", Bytes.toBytes(new StringBuffer(carNo).reverse().toString()));
                    if (r != null && !r.isEmpty()) {
                        List<Cell> cells = r.listCells();
                        List getList = new ArrayList();
                        Map<String, ColumnType> columns = new HashMap<>();
                        for (Cell cell : cells) {
                            String waybillNo = Bytes.toString(CellUtil.cloneQualifier(cell));
                            //String redisKey = waybillNo+"_" + destZoneCode + "_has_arrive_big";
                            //运单车标关系在Redis中读取
                            //String isExsits = RedisClusterPool.getConn().get(redisKey);
                            //if((StringUtils.isEmpty(isExsits) || isExsits.equals(carNo))&&StringUtils.isNotEmpty(destZoneCode)){
                                if (StringUtils.isNotEmpty(waybillNo)&&StringUtils.isNotEmpty(destZoneCode)) {
                                    //Get get = new Get(Bytes.toBytes(new StringBuffer(waybillNo).reverse().toString()));
                                   // get.addColumn(Bytes.toBytes("baseInfo"), Bytes.toBytes("packageMeterageWeightQty"));
                                    getList.add(waybillNo);
                                    columns.put("packageMeterageWeightQty",ColumnType.DOUBLE);
                                    //RedisClusterPool.getConn().set(redisKey,carNo);
                                    //RedisClusterPool.getConn().expire(redisKey,24*60*60);
                               // }
                            }
                        }
                        //获取数据库中已有的件数，如果件数没有变化则不去查询hbase 表更新件数和重量
                        Connection conn = JDBCUtil.getConn();
                        // See the simple. http://secwiki.sf-express.com/fix/%E6%BC%8F%E6%B4%9E%E4%BB%A3%E7%A0%81%E4%BF%AE%E5%A4%8D%E7%A4%BA%E4%BE%8B/SQL%E6%B3%A8%E5%85%A5.html
                        String sql = "select * from vt_has_arrive_cars_big where carNo = '" + carNo + "'";
                        Statement st = null;
                        ResultSet rs = null;
                        try {
                            st = conn.createStatement();
                            rs = st.executeQuery(sql);
                            while (rs.next()) {
                                tm = rs.getLong("ticket");
                                wt = rs.getDouble("weight");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        } finally {
                            if(rs != null){
                                rs.close();
                            }
                            if(st != null){
                                st.close();
                            }
                            if(conn != null){
                                conn.close();
                            }
                        }
                        if (tm != getList.size() && getList.size() > 0) {
                            int loop = 0;
                            if (getList.size() % HBASE_BATCH_QUERY_SIZE == 0) {
                                loop = getList.size() / HBASE_BATCH_QUERY_SIZE;
                            } else {
                                loop = getList.size() / HBASE_BATCH_QUERY_SIZE + 1;
                            }
                            for (int i = 0; i < loop; i++) {
                                int start = i * HBASE_BATCH_QUERY_SIZE;
                                int end = (i + 1) * HBASE_BATCH_QUERY_SIZE > getList.size() ? getList.size() : (i + 1) * HBASE_BATCH_QUERY_SIZE;
                                List subList = getList.subList(start, end);
                                Map<String,Map<String,Object>> hrs = hbase.getListSpecialForWbInfo(subList,columns);
//                                Result[] results = hbase.getList("wb_info_data", subList);
//                                if (results != null) {
//                                    for (Result rt : results) {
//                                        if (rt != null && !rt.isEmpty()) {
//                                            List<Cell> cell2s = rt.listCells();
//                                            for (Cell cell : cell2s) {
//                                                weights += Bytes.toDouble(CellUtil.cloneValue(cell))>10000D?10000D:Bytes.toDouble(CellUtil.cloneValue(cell));
//                                                tickets++;
//                                            }
//                                        }
//                                    }
//                                }
                                for(Map.Entry<String,Map<String,Object>> entry : hrs.entrySet()){
                                    //TODO 保留15kg+ 的运单数据
                                    Double weightQty = (Double) entry.getValue().get("packageMeterageWeightQty");
                                    if (weightQty>15D){
                                        weights += (weightQty)>10000D?10000D:(weightQty);
                                        //tickets++;
                                        tickets ++;
                                    }
                                }
                            }
                        }else{
                            weights = wt;
                            tickets = tm;
                        }
                    }
                    dto.setRequireId(j.getString("requireId"));
                    dto.setIdKey(UUID.randomUUID().toString());
                    dto.setCarNo(carNo);
                    //transoportLevel 超过边界
                    dto.setTransLevel(j.getInteger("transoportLevel").toString().length()>2?3:j.getInteger("transoportLevel"));
                    if (j.getInteger("transoportLevel").toString().length()>2) {
                        System.out.println("requireId:"+j.getString("requireId")+",  transoportLevel:"+j.getInteger("transoportLevel"));
                    }
                    dto.setCarStatus(j.getInteger("carStatus"));
                    dto.setSrcZoneCode(j.getString("srcZoneCode"));
                    dto.setDestZoneCode(j.getString("destZoneCode"));
                    dto.setActualTime(j.getLong("actualArriveTime"));
                    dto.setWeight(weights);
                    dto.setTicket(tickets);
                    dto.setSendTime(j.getLong("sendTime"));
                    dto.setLineCode(j.getString("lineCode"));
                    rList.add(dto);
                }
                return rList;
            }
        }).flatMap(new FlatMapFunction<List<BigVehicleHasArriveDto>, BigVehicleHasArriveDto>() {
            @Override
            public void flatMap(List<BigVehicleHasArriveDto> bigVehicleHasArriveDtos, Collector<BigVehicleHasArriveDto> collector) throws Exception {
                bigVehicleHasArriveDtos.stream().forEach(j->collector.collect(j));
            }
        }).addSink(new BigVehicleHasArriveSink());
/*
                .map((MapFunction<BigVehicleHasArriveDto, Row>) t2->{
            return KafkaDataPreProcess.getRow(schema,(JSONObject) JSON.toJSON(t2));
        }).writeUsingOutputFormat(MysqlSink.getJDBCOutputFormat(SqlUtil.getInsertByReplaceSql(schema), KafkaDataPreProcess.getTypes(schema)));
*/

        env.execute("Flink Streaming Java API Skeleton");
    }
}
