package com.sf.realtime.flink.function.query;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.realtime.common.utils.ElasticSearchUtil;
import com.sf.realtime.common.utils.RedisClusterPool;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

/**
 * @Author 01419728
 * @Date 2022/4/26 9:48
 */
public class SfBatchInfo {
    private String batchCode;
    private String startTm;
    private String endTm;
    private String workDay;
    private String validDt;
    private String invldDt;
    private String startLastArrTm;
    private String lastArrTm;

    public String getBatchCode() {
        return batchCode;
    }

    public void setBatchCode(String batchCode) {
        this.batchCode = batchCode;
    }

    public String getStartTm() {
        return startTm;
    }

    public void setStartTm(String startTm) {
        this.startTm = startTm;
    }

    public String getEndTm() {
        return endTm;
    }

    public void setEndTm(String endTm) {
        this.endTm = endTm;
    }

    public String getWorkDay() {
        return workDay;
    }

    public void setWorkDay(String workDay) {
        this.workDay = workDay;
    }

    public String getValidDt() {
        return validDt;
    }

    public void setValidDt(String validDt) {
        this.validDt = validDt;
    }

    public String getInvldDt() {
        return invldDt;
    }

    public void setInvldDt(String invldDt) {
        this.invldDt = invldDt;
    }

    public String getStartLastArrTm() {
        return startLastArrTm;
    }

    public void setStartLastArrTm(String startLastArrTm) {
        this.startLastArrTm = startLastArrTm;
    }

    public String getLastArrTm() {
        return lastArrTm;
    }

    public void setLastArrTm(String lastArrTm) {
        this.lastArrTm = lastArrTm;
    }



    private static SfBatchInfo getBatchInfoFromEs(String zonecode, String arrTime) {
        DateTimeFormatter df2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        DateTimeFormatter df3 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime start = LocalDate.parse(arrTime, df2).atStartOfDay();
        String lastDay = start.minusDays(1).format(df3);

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = formatter.parse(arrTime);
        } catch (ParseException e) {
            e.printStackTrace();
            System.out.println("arrTime格式错误");
        }
        String arrTmDay = arrTime.substring(0, 10);//2022022
        String arrTmHHmm = arrTime.substring(11, 13).concat(arrTime.substring(14, 16));//1550
        Integer arrt = Integer.valueOf(arrTmHHmm);
        System.out.println(arrt);
        //工作日判断
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int week_index = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (week_index < 0) {
            week_index = 0;
        }

        String esIndes = "dim_sf_batch_info";
        String query = "{\"query\":{\"bool\":{\"must\":[" +
                "{\"term\":{\"zonecode\":\""+zonecode+"\"}}," +
                "{\"term\":{\"arrive_date\":\""+week_index+"\"}}," +
                "{\"range\":{\"start_last_arr_tm\":{\"lte\":"+arrTmHHmm+"}}}," +
                "{\"range\":{\"last_arr_tm\":{\"gte\":"+arrTmHHmm+"}}}]}}}";
        String searchResult = ElasticSearchUtil.queryDSL(esIndes, query, true);
        JSONObject resultJson = JSON.parseObject(searchResult);
        JSONObject hits1 = resultJson.getJSONObject("hits");
        JSONArray hits = hits1.getJSONArray("hits");
        JSONObject hit = JSON.parseObject(hits.get(0).toString());
        String id = hit.getString("_id");
        String result = hit.getString("_source");
        SfBatchInfo BatchInfoResult = JSON.parseObject(result, SfBatchInfo.class);
        System.out.println(id+"场地_到达星期_跨天情况_班次名称");
        ElasticSearchUtil.close();
        return BatchInfoResult;
    }


    private static JSONObject getBatchInfofromRedis(String zonecode, String arrTime) {
        JSONObject result = new JSONObject();

        DateTimeFormatter df2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        DateTimeFormatter df3 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime start = LocalDate.parse(arrTime, df2).atStartOfDay();
        String lastDay = start.minusDays(1).format(df3);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = formatter.parse(arrTime);
        } catch (ParseException e) {
            e.printStackTrace();
            System.out.println("arrTime格式错误");
        }
        String arrTmDay = arrTime.substring(0, 10);
        String arrTmHHmm = arrTime.substring(11, 13).concat(arrTime.substring(14, 16));
        //工作日判断
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int week_index = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (week_index < 0) {
            week_index = 0;
        }
        int lastDayWeek = week_index - 1;
        if (lastDayWeek == 0) {
            lastDayWeek = 7;
        }
        //从redis读取
        String redisKey = "dim_sf_batch_info";
        String field = zonecode + "_" + week_index;
        String batchinfo = RedisClusterPool.getConn().hget(redisKey, field);
        String batchDate = null;
        String batchCode = null;
        if (!batchinfo.isEmpty()) {
            JSONArray batchArray = JSON.parseArray(batchinfo);
            int size = batchArray.size();
            if (size > 0) {
                for (int i = 0; i < size; i++) {
                    SfBatchInfo batchObj = JSON.parseObject(batchArray.toArray()[i].toString(), SfBatchInfo.class);
                    //当天的第一个班次
                    SfBatchInfo firstBatch = JSON.parseObject(batchArray.toArray()[0].toString(), SfBatchInfo.class);
                    String minStartLastArrTm = firstBatch.startLastArrTm;

                    String lastArrTm = batchObj.lastArrTm;
                    String startLastArrTm = batchObj.startLastArrTm;

                    //0.判断有效性
                    if (batchObj.invldDt.compareTo(arrTmDay) > 0 && batchObj.validDt.compareTo(arrTmDay) <= 0) {
                        //处理跨天班次情况
                        // 判断是否是属于前一天的班次  或者当天的班次
                        if (Integer.valueOf(arrTmHHmm) > Integer.valueOf(minStartLastArrTm)) {
                            if (Integer.valueOf(startLastArrTm) >= Integer.valueOf(lastArrTm)) {
                                lastArrTm = "2400";
                            }
                            //  属于当天的班次
                            //2.匹配当天的班次--->  arr_tm between start_last_arr_tm and last_arr_tm
                            if (Integer.valueOf(arrTmHHmm) < Integer.valueOf(lastArrTm) && Integer.valueOf(arrTmHHmm) > Integer.valueOf(startLastArrTm)) {
                                batchCode=batchObj.batchCode;
                                System.out.println("匹配的班次是:" + batchCode + ":" + batchinfo);
                                batchDate = arrTmDay;
                                System.out.println("匹配的班次日期是[当天]:" + batchDate);
                                //第一个取到的是就是
                                break;
                            }
                        }
                        if (i == size - 1) {
                            //属于昨天的班次
                            String field2 = zonecode + "_" + lastDayWeek;
                            String lastDayBatch = RedisClusterPool.getConn().hget(redisKey, field2);
                            if (!lastDayBatch.isEmpty()) {
                                JSONArray lastDayBatchArray = JSON.parseArray(lastDayBatch);
                                int size1 = lastDayBatchArray.size();
                                if (size1 > 0) {
                                    for (int j = (size1 - 1); j >= 0; j--) {
                                        batchObj = JSON.parseObject(lastDayBatchArray.toArray()[j].toString(), SfBatchInfo.class);
                                        //当天的第一个班次
                                        startLastArrTm = batchObj.startLastArrTm;
                                        lastArrTm = batchObj.lastArrTm;
                                        //判断有效性,取分区跨天的分区
                                        //0.判断有效性
                                        if (batchObj.invldDt.compareTo(arrTmDay) > 0 && batchObj.validDt.compareTo(arrTmDay) <= 0) {
                                            //处理跨天班次情况
                                            if (Integer.valueOf(batchObj.startLastArrTm) >= Integer.valueOf(batchObj.lastArrTm)) {
                                                startLastArrTm = "0000";
                                                if (Integer.valueOf(arrTmHHmm) < Integer.valueOf(lastArrTm) && Integer.valueOf(arrTmHHmm) > Integer.valueOf(startLastArrTm)) {
                                                    System.out.println("匹配的班次是:" + batchCode + ":" + batchObj);
                                                    batchDate = lastDay;
                                                    batchCode=batchObj.batchCode;
                                                    System.out.println("匹配的班次日期是[前一天]:" + batchDate);
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        result.put("batchDate",batchDate);
        result.put("batchCode",batchCode);
        return result;
    }
}
