package com.sf.realtime.flink.field;

public enum Types {
    INTEGER("integer"),
    STRING("string"),
    BOOLEAN("boolean"),
    LONG("long"),
    DOUBLE("double"),
    TIMESTAMP("timestamp"),
    DATE("date"),
    DECIMAL("decimal");

    private Types(String name){
        this.name = name;
    }
    private String name;
    public String getName(){
        return this.name;
    }
}
