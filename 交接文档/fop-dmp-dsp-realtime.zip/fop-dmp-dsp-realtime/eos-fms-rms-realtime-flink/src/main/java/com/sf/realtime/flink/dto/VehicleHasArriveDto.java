package com.sf.realtime.flink.dto;

public class VehicleHasArriveDto {
    private String idKey;
    private String requireId;
    private Integer transLevel;
    private String carNo;
    private Integer carStatus;
    private String srcZoneCode;
    private String destZoneCode;
    private double weight;
    private Long ticket;
    private Long actualTime;

    public String getIdKey() {
        return idKey;
    }

    public void setIdKey(String idKey) {
        this.idKey = idKey;
    }

    public String getRequireId() {
        return requireId;
    }

    public void setRequireId(String requireId) {
        this.requireId = requireId;
    }

    public Integer getTransLevel() {
        return transLevel;
    }

    public void setTransLevel(Integer transLevel) {
        this.transLevel = transLevel;
    }

    public String getCarNo() {
        return carNo;
    }

    public void setCarNo(String carNo) {
        this.carNo = carNo;
    }

    public Integer getCarStatus() {
        return carStatus;
    }

    public void setCarStatus(Integer carStatus) {
        this.carStatus = carStatus;
    }

    public String getSrcZoneCode() {
        return srcZoneCode;
    }

    public void setSrcZoneCode(String srcZoneCode) {
        this.srcZoneCode = srcZoneCode;
    }

    public String getDestZoneCode() {
        return destZoneCode;
    }

    public void setDestZoneCode(String destZoneCode) {
        this.destZoneCode = destZoneCode;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public Long getTicket() {
        return ticket;
    }

    public void setTicket(Long ticket) {
        this.ticket = ticket;
    }

    public Long getActualTime() {
        return actualTime;
    }

    public void setActualTime(Long actualTime) {
        this.actualTime = actualTime;
    }
}
