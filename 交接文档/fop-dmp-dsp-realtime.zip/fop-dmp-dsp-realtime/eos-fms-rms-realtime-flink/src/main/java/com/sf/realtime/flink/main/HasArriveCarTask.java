package com.sf.realtime.flink.main;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.realtime.common.config.Config;
import com.sf.realtime.common.utils.DateUtil;
import com.sf.realtime.common.utils.RedisClusterPool;
import com.sf.realtime.flink.common.KafkaDataPreProcess;
import com.sf.realtime.flink.common.SqlUtil;
import com.sf.realtime.flink.config.ParamConfig;
import com.sf.realtime.flink.dto.VehicleHasArriveDto;
import com.sf.realtime.flink.schema.Schema;
import com.sf.realtime.flink.schema.VehicleHasArriveTaskSchema;
import com.sf.realtime.flink.sink.MysqlSink;
import com.sf.realtime.flink.sink.VehicleHasArriveSink;
import com.sf.realtime.flink.util.JDBCUtil;
import com.sf.realtime.hbase.HbaseUtil;
import com.sf.realtime.hbase.common.ColumnType;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.contrib.streaming.state.RocksDBStateBackend;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer08;
import org.apache.flink.streaming.util.serialization.SimpleStringSchema;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

public class HasArriveCarTask {
    private static final String topic = Config.getConfig().getString("other2.kafka.car.require.task.topic");
    private static final String taskName = "car.require";
    private static final String kafkaClusterName = "other2";
    private static Schema schema = new VehicleHasArriveTaskSchema();
    private static final int HBASE_BATCH_QUERY_SIZE = 1000;

    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.enableCheckpointing(25 * 60 * 1000L);// 设置checkpoint的周期
        env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        env.getCheckpointConfig().setMinPauseBetweenCheckpoints(25 * 60 * 1000L);
        env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);// 同一时间只允许进行一个检查点
        env.getCheckpointConfig().setCheckpointTimeout(5 * 60 * 1000L);
        String ckDir = System.getProperty("ckDir");
        env.setStateBackend(new RocksDBStateBackend(ckDir, true));
        env.setParallelism(16);
        String filterTime1 = args[0];
        String filterTime2 = args[1];
        String filterTime = filterTime1 + " "+filterTime2;

        //schema.setTableName("vt_has_arrive_cars_yz");

        Set<String> deptInfo = new HashSet<>();
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try {
            conn = JDBCUtil.getConn();
            String sql = "select * from dim_heavy_transit_info";
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                deptInfo.add(rs.getString("dept_code"));
            }
        } catch (SQLException e) {
        }finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }



        //加载快运网点数据
        DataStream<String> data;
        Properties props = ParamConfig.configByKafka(kafkaClusterName,taskName);
        props.replace("group.id","eos-fms-rms-realtime-flink-vechile-has-arrive-new-tidb");
        props.replace("auto.offset.reset","smallest");
        data = env.addSource(new FlinkKafkaConsumer08<String>(topic, new SimpleStringSchema(), props)).name("vechile-has-arrive").setParallelism(4);


        SingleOutputStreamOperator<Tuple2<String,JSONObject>> filterStream = data.rebalance().map((MapFunction<String, JSONObject>) src -> {
            return JSON.parseObject(src);
        }).filter((FilterFunction<JSONObject>) json -> {
            //System.out.println("======1====="+DateUtil.getTimeWithHms(filterTime));
            //System.out.println("======2====="+json.getLongValue("createTm"));
            //System.out.println("======3====="+json.getLong("createTm"));
            return StringUtils.isNotEmpty(json.getString("lineRequireId")) && DateUtil.getTimeWithHms(filterTime) < json.getLongValue("lastUpdateTm");
        }).map(new MapFunction<JSONObject, Tuple2<String, JSONObject>>() {
            @Override
            public Tuple2<String, JSONObject> map(JSONObject jsonObject) throws Exception {
                return new Tuple2<>(jsonObject.getString("lineRequireId"),jsonObject);
            }
        })
                .name("has_arrive_filter").uid("has_arrive_filter")
                .setParallelism(16);

        SingleOutputStreamOperator singleOutputStreamOperator = filterStream.keyBy(0)
                .timeWindow(Time.seconds(5))
                .reduce(new ReduceFunction<Tuple2<String, JSONObject>>() {
                    @Override
                    public Tuple2<String, JSONObject> reduce(Tuple2<String, JSONObject> t1, Tuple2<String, JSONObject> t2) throws Exception {
                        return t2;
                    }
                })
                .name("has_arrive_window").uid("has_arrive_window")
                .setParallelism(16);

        SingleOutputStreamOperator<VehicleHasArriveDto> processStream =
                singleOutputStreamOperator.keyBy(0).map(new MapFunction<JSONObject, Set<JSONObject>>() {
            @Override
            public Set<JSONObject> map(JSONObject jsonObject) throws Exception {
                Set<JSONObject> js = new HashSet<JSONObject>();
                Integer transoportLevel = jsonObject.getInteger("transoportLevel");
                Integer carStatus = jsonObject.getInteger("carStatus");
                JSONArray ja = jsonObject.getJSONArray("passZoneList");
                int length = ja.toArray().length;
                //获取经过的网点
                List<JSONObject> passZoneList = new ArrayList();
                for (int i = 1; i <= length; i++) {
                    for (Object o : ja.toArray()) {
                        JSONObject j = (JSONObject) o;
                        int sort = j.getInteger("sortNum");
                        if (sort == i) {
                            if (sort == 1) {
                                if (StringUtils.isNotEmpty(j.getString("actualPassZoneCode"))) {
                                    passZoneList.add(j);
                                } else if (StringUtils.isNotEmpty(j.getString("actualSendBatch")) && StringUtils.isNotEmpty(j.getString("passZoneCode"))) {
                                    j.put("actualPassZoneCode", j.getString("passZoneCode"));
                                    passZoneList.add(j);
                                }
                            } else {
                                if (StringUtils.isNotEmpty(j.getString("actualPassZoneCode"))) {
                                    passZoneList.add(j);
                                } else if (StringUtils.isNotEmpty(j.getString("actualArriveBatch")) && StringUtils.isNotEmpty(j.getString("passZoneCode"))) {
                                    j.put("actualPassZoneCode", j.getString("passZoneCode"));
                                    passZoneList.add(j);
                                }
                            }
                            break;
                        }
                    }
                }

                int passSize = passZoneList.size();

                for (int i = 0; i < passSize - 1; i++) {
                    String srcZoneCode = passZoneList.get(i).getString("actualPassZoneCode");
                    String destZoneCode = passZoneList.get(i + 1).getString("actualPassZoneCode");
                    if (deptInfo.contains(destZoneCode)) {
                        JSONObject jo = passZoneList.get(i + 1);
                        Integer jobType = jo.getInteger("jobType");
                        String requireId = jo.getString("lineRequireId");
                        Long actualArriveTime = jo.getLong("actualArriveTm") == null ? (jo.getLong("preArriveTm") == null ? jo.getLong("planArriveTm") : jo.getLong("preArriveTm")) : jo.getLong("actualArriveTm");
                        Boolean flag = jobType == null ? false : (jobType == 2) || (jobType == 3);
                        if (flag) {
                            String carNos = jo.getString("unloadContnrNos");
                            if ((i + 1) == (passSize - 1)) {
                                if (StringUtils.isEmpty(carNos)) {
                                    carNos = jo.getString("arriveContnrNos");
                                }
                                if (StringUtils.isEmpty(carNos)) {
                                    carNos = jo.getString("attr2");
                                }
                            }
                            if (StringUtils.isNotEmpty(carNos)) {
                                for (String carNo : carNos.split(",")) {
                                    JSONObject rj = new JSONObject();
                                    rj.put("requireId", requireId);
                                    rj.put("carNo", carNo);
                                    rj.put("srcZoneCode", srcZoneCode);
                                    rj.put("destZoneCode", destZoneCode);
                                    rj.put("actualArriveTime", actualArriveTime);
                                    rj.put("transoportLevel", transoportLevel);
                                    rj.put("carStatus", carStatus);
                                    js.add(rj);
                                }
                            }
                        }

                    }
                }
                return js;
            }
        }).map(new MapFunction<Set<JSONObject>, List<VehicleHasArriveDto>>() {
            @Override
            public List<VehicleHasArriveDto> map(Set<JSONObject> jsonObjects) throws Exception {
                HbaseUtil hbase = HbaseUtil.getInstance();
                List<VehicleHasArriveDto> rList = new ArrayList<>();
                for (JSONObject j : jsonObjects) {
                    VehicleHasArriveDto dto = new VehicleHasArriveDto();
                    Double weights = 0D;
                    Long tickets = 0L;
                    Long tm = 0L;
                    Double wt = 0D;
                    String carNo = j.getString("carNo");
                    String destZoneCode = j.getString("destZoneCode");
                    //获取车标运单的关系
                    Result r = hbase.getRow("rt_container_waybill_relation", Bytes.toBytes(new StringBuffer(carNo).reverse().toString()));
                    if (r != null && !r.isEmpty()) {
                        List<Cell> cells = r.listCells();
                        List getList = new ArrayList();
                        Map<String, ColumnType> columns = new HashMap<>();
                        for (Cell cell : cells) {
                            String waybillNo = Bytes.toString(CellUtil.cloneQualifier(cell));
                            String redisKey = waybillNo + "_" + destZoneCode + "_has_arrive";
                            String isExsits = RedisClusterPool.getConn().get(redisKey);
                            if ((StringUtils.isEmpty(isExsits) || isExsits.equals(carNo)) && StringUtils.isNotEmpty(destZoneCode)) {
                                if (StringUtils.isNotEmpty(waybillNo)) {
                                    //Get get = new Get(Bytes.toBytes(new StringBuffer(waybillNo).reverse().toString()));
                                    // get.addColumn(Bytes.toBytes("baseInfo"), Bytes.toBytes("packageMeterageWeightQty"));
                                    getList.add(waybillNo);
                                    columns.put("packageMeterageWeightQty", ColumnType.DOUBLE);
                                    RedisClusterPool.getConn().set(redisKey, carNo);
                                    RedisClusterPool.getConn().expire(redisKey, 24 * 60 * 60);
                                }
                            }
                        }
                        //获取数据库中已有的件数，如果件数没有变化则不去查询hbase 表更新件数和重量
//                        Connection conn = JDBCUtil.getConn();
//                        String sql = "select * from vt_has_arrive_cars where carNo = '" + carNo + "'";
//                        Statement st = null;
//                        ResultSet rs = null;
//                        try {
//                            st = conn.createStatement();
//                            rs = st.executeQuery(sql);
//                            while (rs.next()) {
//                                tm = rs.getLong("ticket");
//                                wt = rs.getDouble("weight");
//                            }
//                        } catch (SQLException e) {
//                            e.printStackTrace();
//                        } finally {
//                            if(rs != null){
//                                rs.close();
//                            }
//                            if(st != null){
//                                st.close();
//                            }
//                            if(conn != null){
//                                conn.close();
//                            }
//                        }
                        String key = j.getString("requireId") + "_" + carNo + "_" + "has_arrive_wt";
                        Map<String, String> rm = RedisClusterPool.getConn().hgetAll(key);
                        System.out.println("======" + rm.get("ticket"));
                        if (rm != null && rm.get("ticket") != null && rm.get("weight") != null) {
                            tm = Long.parseLong(rm.get("ticket"));
                            wt = Double.parseDouble(rm.get("weight"));
                        }
                        if (tm != getList.size() && getList.size() > 0) {
                            int loop = 0;
                            if (getList.size() % HBASE_BATCH_QUERY_SIZE == 0) {
                                loop = getList.size() / HBASE_BATCH_QUERY_SIZE;
                            } else {
                                loop = getList.size() / HBASE_BATCH_QUERY_SIZE + 1;
                            }
                            for (int i = 0; i < loop; i++) {
                                int start = i * HBASE_BATCH_QUERY_SIZE;
                                int end = (i + 1) * HBASE_BATCH_QUERY_SIZE > getList.size() ? getList.size() : (i + 1) * HBASE_BATCH_QUERY_SIZE;
                                List subList = getList.subList(start, end);
                                Map<String, Map<String, Object>> hrs = hbase.getListSpecialForWbInfo(subList, columns);
//                                Result[] results = hbase.getList("wb_info_data", subList);
//                                if (results != null) {
//                                    for (Result rt : results) {
//                                        if (rt != null && !rt.isEmpty()) {
//                                            List<Cell> cell2s = rt.listCells();
//                                            for (Cell cell : cell2s) {
//                                                weights += Bytes.toDouble(CellUtil.cloneValue(cell))>10000D?10000D:Bytes.toDouble(CellUtil.cloneValue(cell));
//                                                tickets++;
//                                            }
//                                        }
//                                    }
//                                }
                                for (Map.Entry<String, Map<String, Object>> entry : hrs.entrySet()) {
                                    weights += ((Double) entry.getValue().get("packageMeterageWeightQty")) > 50000D ? 50000D : ((Double) entry.getValue().get("packageMeterageWeightQty"));
                                    tickets++;
                                }
                            }
                        } else {
                            weights = wt;
                            tickets = tm;
                        }
                    }
                    dto.setRequireId(j.getString("requireId"));
                    dto.setIdKey(UUID.randomUUID().toString());
                    dto.setCarNo(carNo);
                    dto.setTransLevel(j.getInteger("transoportLevel"));
                    dto.setCarStatus(j.getInteger("carStatus"));
                    dto.setSrcZoneCode(j.getString("srcZoneCode"));
                    dto.setDestZoneCode(j.getString("destZoneCode"));
                    dto.setActualTime(j.getLong("actualArriveTime"));
                    dto.setWeight(weights);
                    dto.setTicket(tickets);
                    rList.add(dto);
                }
                return rList;
            }
        }).flatMap(new FlatMapFunction<List<VehicleHasArriveDto>, VehicleHasArriveDto>() {
            @Override
            public void flatMap(List<VehicleHasArriveDto> vehicleHasArriveDtos, Collector<VehicleHasArriveDto> collector) throws Exception {
                vehicleHasArriveDtos.stream().forEach(j -> collector.collect(j));
            }
        }).map((MapFunction<VehicleHasArriveDto, VehicleHasArriveDto>) t2 -> {
            String key = t2.getRequireId() + "_" + t2.getCarNo() + "_" + "has_arrive_wt";
            RedisClusterPool.getConn().hset(key, "ticket", t2.getTicket() + "");
            RedisClusterPool.getConn().hset(key, "weight", t2.getWeight() + "");
            RedisClusterPool.getConn().expire(key, 7 * 24 * 60 * 60);
            return t2;
        }) .name("has_arrive_tidb_process").uid("has_arrive_tidb_process")
                        .setParallelism(16);
        processStream.addSink(new VehicleHasArriveSink())
                .name("has_arrive_tidb_sink").uid("has_arrive_tidb_sink")
                .setParallelism(16);
//        ;
//                .writeUsingOutputFormat(MysqlSink.getJDBCOutputFormat(SqlUtil.getInsertByReplaceSql(schema), KafkaDataPreProcess.getTypes(schema)));

        env.execute("Flink Streaming Java API Skeleton ");
    }
}
