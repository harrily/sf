package com.sf.realtime.flink.schema;

public class VehicleHasArriveBatchTaskSchema extends Schema {
    public VehicleHasArriveBatchTaskSchema() {
        super("VehicleHasArriveBatchTaskSchema");
    }
}