package com.sf.realtime.flink.schema;

import com.sf.realtime.common.config.Config;
import com.sf.realtime.flink.field.Field;
import com.sf.realtime.flink.field.Types;

import java.util.ArrayList;
import java.util.List;

public abstract class Schema {
    protected String tableName;
    protected List<Field> fields;
    public Schema(String tableName,ArrayList<Field> fields){ //NOSONAR
        this.tableName = tableName;
        this.fields = fields;
    }
    public Schema(String schemaName){
        String tableName = Config.getSchemaConfig().getString(schemaName+".tableName"); //NOSONAR
        List<Field> fields = new ArrayList<>(); //NOSONAR
        for (com.typesafe.config.Config c :Config.getSchemaConfig().getConfigList(schemaName+".fields")) {
            Field f = new Field();
            f.setName(c.getString("name"));
            if(Types.STRING.getName().equalsIgnoreCase(c.getString("type"))){
                f.setType(Types.STRING);
            }else if(Types.INTEGER.getName().equalsIgnoreCase(c.getString("type"))){
                f.setType(Types.INTEGER);
            }else if(Types.LONG.getName().equalsIgnoreCase(c.getString("type"))){
                f.setType(Types.LONG);
            }else if(Types.DOUBLE.getName().equalsIgnoreCase(c.getString("type"))){
                f.setType(Types.DOUBLE);
            }else if(Types.BOOLEAN.getName().equalsIgnoreCase(c.getString("type"))){
                f.setType(Types.BOOLEAN);
            }else if(Types.TIMESTAMP.getName().equalsIgnoreCase(c.getString("type"))){
                f.setType(Types.TIMESTAMP);
            }else if(Types.DATE.getName().equalsIgnoreCase(c.getString("type"))){
                f.setType(Types.DATE);
            }
            f.setComment(c.getString("comment"));
            f.setNone(c.getBoolean("isNone"));
            fields.add(f);
        }
        this.tableName = tableName;
        this.fields = fields;
    }

    public String getTableName() {
        return tableName;
    }

    public List<Field> getFields() {
        return fields;
    }
}
