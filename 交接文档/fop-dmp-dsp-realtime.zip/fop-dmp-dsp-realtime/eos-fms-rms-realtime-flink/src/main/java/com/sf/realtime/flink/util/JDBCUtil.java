package com.sf.realtime.flink.util;

import com.sf.realtime.common.config.Config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.LinkedList;

public class JDBCUtil {
    private static LinkedList<Connection> connectionQueue;
    private static String url = Config.getConfig().getString("tidb.jdbc.url");
    private static String username = Config.getConfig().getString("tidb.user");
    private static String password = Config.getConfig().getString("tidb.passwd");

    public synchronized static Connection getConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            if (connectionQueue == null) {
                connectionQueue = new LinkedList<Connection>();
                for (int i = 0;i < 50;i ++) {
                    Connection conn = DriverManager.getConnection(
                            url,
                            username,
                            password
                    );
                    connectionQueue.push(conn);
                }
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        if(connectionQueue.size()<=0){
            Connection conn = null;
            try {
                 conn = DriverManager.getConnection(
                        url,
                        username,
                        password
                );
            }catch (Exception e) {
                e.printStackTrace();
            }
            return conn;
        }else{
            return connectionQueue.poll();
        }

    }

    public static void returnConnection(Connection conn) {
        connectionQueue.push(conn);
    }

    public static Connection getConn() throws SQLException {
        Connection conn = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(
                    url,
                    username,
                    password
            );
        }catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }
}
