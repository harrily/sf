package com.sf.realtime.flink.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.sf.realtime.common.utils.ElasticSearchUtil;
import com.sf.realtime.flink.function.query.BatchInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * @Author 01419728
 * @Date 2022/7/15 15:01
 */
public class CacheContainer {
    private static Logger log = LoggerFactory.getLogger(CacheContainer.class);
    /**
     * 并发数
     */
    private static final int CURRENCY_LEVEL = 10;
    private static CacheContainer instance;
    private final Cache<String, Optional<BatchInfo>> batchInfoCache;
    private CacheContainer() {
        this.batchInfoCache = CacheBuilder.newBuilder()
                .initialCapacity(200000)
                .maximumSize(200000)
                .concurrencyLevel(CURRENCY_LEVEL)
                .expireAfterWrite(25, TimeUnit.HOURS)
                .build();
    }
    public synchronized static CacheContainer getInstance() {
        if (instance == null) {
            instance = new CacheContainer();
        }
        return instance;
    }
    public long initBatchInfoCacheFromEs() {
        long total = 0;
        String indexName = "dim_sf_batch_info";
        String typeName = "dim_sf_batch_info";
        String searchResult = ElasticSearchUtil.queryIndexAll(indexName);
        JSONObject resultJson = JSON.parseObject(searchResult);
        JSONObject hits1 = resultJson.getJSONObject("hits");
        JSONArray hits = hits1.getJSONArray("hits");
        for (Object hit : hits) {
            JSONObject hitJson = JSON.parseObject(hit.toString());
            String id = hitJson.getString("_id");
            String source = hitJson.getString("_source");
            JSONObject sourceResult = JSON.parseObject(source);
            Optional<BatchInfo> batchInfo = Optional.of(new BatchInfo(sourceResult));
            batchInfoCache.put(id, batchInfo);
            total++;
        }
        return total;
    }

//
        public static Object nullOptionalToEmpty(Object obj) {
            if(obj == null) {
                return Optional.empty();
            }
            return obj;
        }

        public BatchInfo getBatchInfo(String zonecode,String arrTime){
            DateTimeFormatter df2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            DateTimeFormatter df3 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime start = LocalDate.parse(arrTime, df2).atStartOfDay();
            String lastDay = start.minusDays(1).format(df3);
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = null;
            try {
                date = formatter.parse(arrTime);
            } catch (ParseException e) {
                e.printStackTrace();
                System.out.println("arrTime格式错误");
            }
            String arrTmDay = arrTime.substring(0, 10);
            String arrTmHHmm = arrTime.substring(11, 13).concat(arrTime.substring(14, 16));
            //工作日判断
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            int week_index = cal.get(Calendar.DAY_OF_WEEK) - 1;
            if (week_index < 0) {
                week_index = 0;
            }
            // arrtime-->"zonecode",lit("_"),$"arrive_date",lit("_"),$"batch_date",lit("_"),$"batch_code"
            String id = zonecode + "_" + week_index + "_";
            Optional<BatchInfo> batchInfoCacheIfPresent = batchInfoCache.getIfPresent(id);

            if (!batchInfoCacheIfPresent.isPresent()){

            }
//            return batchInfoCacheIfPresent;
            return  null;
        }
}
