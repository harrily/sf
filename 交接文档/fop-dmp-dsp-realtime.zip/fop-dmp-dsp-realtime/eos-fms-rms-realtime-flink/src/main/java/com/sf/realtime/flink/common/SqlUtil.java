package com.sf.realtime.flink.common;

import com.sf.realtime.flink.field.Field;
import com.sf.realtime.flink.schema.Schema;

public class SqlUtil {
    public static String getInsertByReplaceSql(Schema schema){
        StringBuilder sb = new StringBuilder("replace into "+schema.getTableName());
        sb.append("(");
        int i= 1;
        StringBuilder values = new StringBuilder(" values(");
        for (Field f:schema.getFields()) {
            if(i == schema.getFields().size()){
                sb.append(f.getName()+")");
                values.append("?)");
            }else{
                sb.append(f.getName()+",");
                values.append("?,");
            }
            i++;
        }
        sb.append(values);
        return sb.toString();
    }

    public static String getInsertByInsertSql(Schema schema){
        StringBuilder sb = new StringBuilder("insert into "+schema.getTableName());
        sb.append("(");
        int i= 1;
        StringBuilder values = new StringBuilder(" values(");
        for (Field f:schema.getFields()) {
            if(i == schema.getFields().size()){
                sb.append(f.getName()+")");
                values.append("?)");
            }else{
                sb.append(f.getName()+",");
                values.append("?,");
            }
            ++i;
        }
        sb.append(values);
        return sb.toString();
    }

}
