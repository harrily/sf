package com.sf.realtime.flink.dto;

import java.io.Serializable;
import java.sql.Timestamp;

public class VehicleNotSendDto implements Serializable {
    private String idKey;
    private String requireId;
    private Integer translevel;
    private String carNo;
    private String lineCode;
    private Integer carStatus;
    private Long lastUpdateTm;
    private String srcZoneCode;
    private Long srcPlanReachTm;
    private Long srcPlanDepartTm;
    private Long srcActualDepartTm;
    private Long srcPreDepartTm;
    private Long srcPlanArriveTm;
    private Long srcActualArriveTm;
    private Long srcPreArriveTm;
    private String secondZoneCode;
    private Long secondPlanReachTm;
    private Long secondPlanDepartTm;
    private Long secondActualDepartTm;
    private Long secondPreDepartTm;
    private Long secondPlanArriveTm;
    private Long secondActualArriveTm;
    private Long secondPreArriveTm;
    private String thirdZoneCode;
    private Long thirdPlanReachTm;
    private Long thirdPlanDepartTm;
    private Long thirdActualDepartTm;
    private Long thirdPreDepartTm;
    private Long thirdPlanArriveTm;
    private Long thirdActualArriveTm;
    private Long thirdPreArriveTm;
    private String destZoneCode;
    private Long destPlanReachTm;
    private Long destPlanDepartTm;
    private Long destActualDepartTm;
    private Long destPreDepartTm;
    private Long destPlanArriveTm;
    private Long destActualArriveTm;
    private Long destPreArriveTm;
    private Timestamp insertTime;
    private Double fullLoadWeight;

    private String srcLoadContnrNos;
    private String srcArriveContnrNos;
    private String srcUnloadContnrNos;
    private String secondLoadContnrNos;
    private String secondArriveContnrNos;
    private String secondUnloadContnrNos;
    private String thirdLoadContnrNos;
    private String thirdArriveContnrNos;
    private String thirdUnloadContnrNos;
    private String destLoadContnrNos;
    private String destArriveContnrNos;
    private String destUnloadContnrNos;
    private String currentOpZoneCode;
    private String srcJobType;
    private String secondJobType;
    private String thirdJobType;
    private String destJobType;
    private Long  nextZoneCodeDynamicPreArriveTime;
    private String vehicleType;
    private String requireCategory;
    private String lineRequireType;
    private String stopOver;

    public String getIdKey() {
        return idKey;
    }

    public void setIdKey(String idKey) {
        this.idKey = idKey;
    }

    public String getRequireId() {
        return requireId;
    }

    public void setRequireId(String requireId) {
        this.requireId = requireId;
    }

    public Integer getTranslevel() {
        return translevel;
    }

    public void setTranslevel(Integer translevel) {
        this.translevel = translevel;
    }

    public String getCarNo() {
        return carNo;
    }

    public void setCarNo(String carNo) {
        this.carNo = carNo;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public Integer getCarStatus() {
        return carStatus;
    }

    public void setCarStatus(Integer carStatus) {
        this.carStatus = carStatus;
    }

    public Long getLastUpdateTm() {
        return lastUpdateTm;
    }

    public void setLastUpdateTm(Long lastUpdateTm) {
        this.lastUpdateTm = lastUpdateTm;
    }

    public String getSrcZoneCode() {
        return srcZoneCode;
    }

    public void setSrcZoneCode(String srcZoneCode) {
        this.srcZoneCode = srcZoneCode;
    }

    public Long getSrcPlanReachTm() {
        return srcPlanReachTm;
    }

    public void setSrcPlanReachTm(Long srcPlanReachTm) {
        this.srcPlanReachTm = srcPlanReachTm;
    }

    public Long getSrcPlanDepartTm() {
        return srcPlanDepartTm;
    }

    public void setSrcPlanDepartTm(Long srcPlanDepartTm) {
        this.srcPlanDepartTm = srcPlanDepartTm;
    }

    public Long getSrcActualDepartTm() {
        return srcActualDepartTm;
    }

    public void setSrcActualDepartTm(Long srcActualDepartTm) {
        this.srcActualDepartTm = srcActualDepartTm;
    }

    public Long getSrcPreDepartTm() {
        return srcPreDepartTm;
    }

    public void setSrcPreDepartTm(Long srcPreDepartTm) {
        this.srcPreDepartTm = srcPreDepartTm;
    }

    public Long getSrcPlanArriveTm() {
        return srcPlanArriveTm;
    }

    public void setSrcPlanArriveTm(Long srcPlanArriveTm) {
        this.srcPlanArriveTm = srcPlanArriveTm;
    }

    public Long getSrcActualArriveTm() {
        return srcActualArriveTm;
    }

    public void setSrcActualArriveTm(Long srcActualArriveTm) {
        this.srcActualArriveTm = srcActualArriveTm;
    }

    public Long getSrcPreArriveTm() {
        return srcPreArriveTm;
    }

    public void setSrcPreArriveTm(Long srcPreArriveTm) {
        this.srcPreArriveTm = srcPreArriveTm;
    }

    public String getSecondZoneCode() {
        return secondZoneCode;
    }

    public void setSecondZoneCode(String secondZoneCode) {
        this.secondZoneCode = secondZoneCode;
    }

    public Long getSecondPlanReachTm() {
        return secondPlanReachTm;
    }

    public void setSecondPlanReachTm(Long secondPlanReachTm) {
        this.secondPlanReachTm = secondPlanReachTm;
    }

    public Long getSecondPlanDepartTm() {
        return secondPlanDepartTm;
    }

    public void setSecondPlanDepartTm(Long secondPlanDepartTm) {
        this.secondPlanDepartTm = secondPlanDepartTm;
    }

    public Long getSecondActualDepartTm() {
        return secondActualDepartTm;
    }

    public void setSecondActualDepartTm(Long secondActualDepartTm) {
        this.secondActualDepartTm = secondActualDepartTm;
    }

    public Long getSecondPreDepartTm() {
        return secondPreDepartTm;
    }

    public void setSecondPreDepartTm(Long secondPreDepartTm) {
        this.secondPreDepartTm = secondPreDepartTm;
    }

    public Long getSecondPlanArriveTm() {
        return secondPlanArriveTm;
    }

    public void setSecondPlanArriveTm(Long secondPlanArriveTm) {
        this.secondPlanArriveTm = secondPlanArriveTm;
    }

    public Long getSecondActualArriveTm() {
        return secondActualArriveTm;
    }

    public void setSecondActualArriveTm(Long secondActualArriveTm) {
        this.secondActualArriveTm = secondActualArriveTm;
    }

    public Long getSecondPreArriveTm() {
        return secondPreArriveTm;
    }

    public void setSecondPreArriveTm(Long secondPreArriveTm) {
        this.secondPreArriveTm = secondPreArriveTm;
    }

    public String getThirdZoneCode() {
        return thirdZoneCode;
    }

    public void setThirdZoneCode(String thirdZoneCode) {
        this.thirdZoneCode = thirdZoneCode;
    }

    public Long getThirdPlanReachTm() {
        return thirdPlanReachTm;
    }

    public void setThirdPlanReachTm(Long thirdPlanReachTm) {
        this.thirdPlanReachTm = thirdPlanReachTm;
    }

    public Long getThirdPlanDepartTm() {
        return thirdPlanDepartTm;
    }

    public void setThirdPlanDepartTm(Long thirdPlanDepartTm) {
        this.thirdPlanDepartTm = thirdPlanDepartTm;
    }

    public Long getThirdActualDepartTm() {
        return thirdActualDepartTm;
    }

    public void setThirdActualDepartTm(Long thirdActualDepartTm) {
        this.thirdActualDepartTm = thirdActualDepartTm;
    }

    public Long getThirdPreDepartTm() {
        return thirdPreDepartTm;
    }

    public void setThirdPreDepartTm(Long thirdPreDepartTm) {
        this.thirdPreDepartTm = thirdPreDepartTm;
    }

    public Long getThirdPlanArriveTm() {
        return thirdPlanArriveTm;
    }

    public void setThirdPlanArriveTm(Long thirdPlanArriveTm) {
        this.thirdPlanArriveTm = thirdPlanArriveTm;
    }

    public Long getThirdActualArriveTm() {
        return thirdActualArriveTm;
    }

    public void setThirdActualArriveTm(Long thirdActualArriveTm) {
        this.thirdActualArriveTm = thirdActualArriveTm;
    }

    public Long getThirdPreArriveTm() {
        return thirdPreArriveTm;
    }

    public void setThirdPreArriveTm(Long thirdPreArriveTm) {
        this.thirdPreArriveTm = thirdPreArriveTm;
    }

    public String getDestZoneCode() {
        return destZoneCode;
    }

    public void setDestZoneCode(String destZoneCode) {
        this.destZoneCode = destZoneCode;
    }

    public Long getDestPlanReachTm() {
        return destPlanReachTm;
    }

    public void setDestPlanReachTm(Long destPlanReachTm) {
        this.destPlanReachTm = destPlanReachTm;
    }

    public Long getDestPlanDepartTm() {
        return destPlanDepartTm;
    }

    public void setDestPlanDepartTm(Long destPlanDepartTm) {
        this.destPlanDepartTm = destPlanDepartTm;
    }

    public Long getDestActualDepartTm() {
        return destActualDepartTm;
    }

    public void setDestActualDepartTm(Long destActualDepartTm) {
        this.destActualDepartTm = destActualDepartTm;
    }

    public Long getDestPreDepartTm() {
        return destPreDepartTm;
    }

    public void setDestPreDepartTm(Long destPreDepartTm) {
        this.destPreDepartTm = destPreDepartTm;
    }

    public Long getDestPlanArriveTm() {
        return destPlanArriveTm;
    }

    public void setDestPlanArriveTm(Long destPlanArriveTm) {
        this.destPlanArriveTm = destPlanArriveTm;
    }

    public Long getDestActualArriveTm() {
        return destActualArriveTm;
    }

    public void setDestActualArriveTm(Long destActualArriveTm) {
        this.destActualArriveTm = destActualArriveTm;
    }

    public Long getDestPreArriveTm() {
        return destPreArriveTm;
    }

    public void setDestPreArriveTm(Long destPreArriveTm) {
        this.destPreArriveTm = destPreArriveTm;
    }

    public Timestamp getInsertTime() {
        return insertTime;
    }

    public void setInsertTime(Timestamp insertTime) {
        this.insertTime = insertTime;
    }

    public Double getFullLoadWeight() {
        return fullLoadWeight;
    }

    public void setFullLoadWeight(Double fullLoadWeight) {
        this.fullLoadWeight = fullLoadWeight;
    }

    public String getSrcLoadContnrNos() {
        return srcLoadContnrNos;
    }

    public void setSrcLoadContnrNos(String srcLoadContnrNos) {
        this.srcLoadContnrNos = srcLoadContnrNos;
    }

    public String getSrcArriveContnrNos() {
        return srcArriveContnrNos;
    }

    public void setSrcArriveContnrNos(String srcArriveContnrNos) {
        this.srcArriveContnrNos = srcArriveContnrNos;
    }

    public String getSrcUnloadContnrNos() {
        return srcUnloadContnrNos;
    }

    public void setSrcUnloadContnrNos(String srcUnloadContnrNos) {
        this.srcUnloadContnrNos = srcUnloadContnrNos;
    }

    public String getSecondLoadContnrNos() {
        return secondLoadContnrNos;
    }

    public void setSecondLoadContnrNos(String secondLoadContnrNos) {
        this.secondLoadContnrNos = secondLoadContnrNos;
    }

    public String getSecondArriveContnrNos() {
        return secondArriveContnrNos;
    }

    public void setSecondArriveContnrNos(String secondArriveContnrNos) {
        this.secondArriveContnrNos = secondArriveContnrNos;
    }

    public String getSecondUnloadContnrNos() {
        return secondUnloadContnrNos;
    }

    public void setSecondUnloadContnrNos(String secondUnloadContnrNos) {
        this.secondUnloadContnrNos = secondUnloadContnrNos;
    }

    public String getThirdLoadContnrNos() {
        return thirdLoadContnrNos;
    }

    public void setThirdLoadContnrNos(String thirdLoadContnrNos) {
        this.thirdLoadContnrNos = thirdLoadContnrNos;
    }

    public String getThirdArriveContnrNos() {
        return thirdArriveContnrNos;
    }

    public void setThirdArriveContnrNos(String thirdArriveContnrNos) {
        this.thirdArriveContnrNos = thirdArriveContnrNos;
    }

    public String getThirdUnloadContnrNos() {
        return thirdUnloadContnrNos;
    }

    public void setThirdUnloadContnrNos(String thirdUnloadContnrNos) {
        this.thirdUnloadContnrNos = thirdUnloadContnrNos;
    }

    public String getDestLoadContnrNos() {
        return destLoadContnrNos;
    }

    public void setDestLoadContnrNos(String destLoadContnrNos) {
        this.destLoadContnrNos = destLoadContnrNos;
    }

    public String getDestArriveContnrNos() {
        return destArriveContnrNos;
    }

    public void setDestArriveContnrNos(String destArriveContnrNos) {
        this.destArriveContnrNos = destArriveContnrNos;
    }

    public String getDestUnloadContnrNos() {
        return destUnloadContnrNos;
    }

    public void setDestUnloadContnrNos(String destUnloadContnrNos) {
        this.destUnloadContnrNos = destUnloadContnrNos;
    }

    public String getCurrentOpZoneCode() {
        return currentOpZoneCode;
    }

    public void setCurrentOpZoneCode(String currentOpZoneCode) {
        this.currentOpZoneCode = currentOpZoneCode;
    }

    public String getSrcJobType() {
        return srcJobType;
    }

    public void setSrcJobType(String srcJobType) {
        this.srcJobType = srcJobType;
    }

    public String getSecondJobType() {
        return secondJobType;
    }

    public void setSecondJobType(String secondJobType) {
        this.secondJobType = secondJobType;
    }

    public String getThirdJobType() {
        return thirdJobType;
    }

    public void setThirdJobType(String thirdJobType) {
        this.thirdJobType = thirdJobType;
    }

    public String getDestJobType() {
        return destJobType;
    }

    public void setDestJobType(String destJobType) {
        this.destJobType = destJobType;
    }

    public Long getNextZoneCodeDynamicPreArriveTime() {
        return nextZoneCodeDynamicPreArriveTime;
    }

    public void setNextZoneCodeDynamicPreArriveTime(Long nextZoneCodeDynamicPreArriveTime) {
        this.nextZoneCodeDynamicPreArriveTime = nextZoneCodeDynamicPreArriveTime;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getRequireCategory() {
        return requireCategory;
    }

    public void setRequireCategory(String requireCategory) {
        this.requireCategory = requireCategory;
    }

    public String getLineRequireType() {
        return lineRequireType;
    }

    public void setLineRequireType(String lineRequireType) {
        this.lineRequireType = lineRequireType;
    }

    public String getStopOver() {
        return stopOver;
    }

    public void setStopOver(String stopOver) {
        this.stopOver = stopOver;
    }
}
