package com.sf.realtime.flink.function.query;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.realtime.common.utils.DateUtil;
import com.sf.realtime.common.utils.ElasticSearchUtil;
import org.apache.commons.lang3.StringUtils;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * @Author 01419728
 * @Date 2022/7/5 18:21
 */
public class BatchInfo {
    private String zonecode;  //场地代码
    private String batchCode; //班次代码
    private String batchDate; //班次日期
    private String startTm; // 开始时间
    private String endTm;   // 结束时间
    private String workDay;  // 工作日
    private String validDt;  // 生效日期
    private String invldDt;  // 失效日期
    private String startLastArrTm;  // 上个班次开始时间
    private String lastArrTm;  // 最晚到达时间

    public BatchInfo(Map<String,Object> source) {
        this.zonecode = (String) source.get("zonecode");
        this.batchCode = (String) source.get("batch_code");
        this.batchDate = (String) source.get("batch_date");// 需要通过到达时间进行计算
        this.startTm = (String) source.get("start_tm");
        this.endTm = (String) source.get("end_tm");
        this.workDay = (String) source.get("workday");
        this.validDt = (String) source.get("valid_dt");
        this.invldDt = (String) source.get("invld_dt");
        this.startLastArrTm = (String) source.get("start_last_arr_tm");
        this.lastArrTm = (String) source.get("last_arr_tm");
    }

    public static BatchInfo getBatchInfoFromEs(String zonecode, String arrTime) {

        DateTimeFormatter df2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        DateTimeFormatter df3 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime start = LocalDate.parse(arrTime, df2).atStartOfDay();
        String lastDay = start.minusDays(1).format(df3);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = formatter.parse(arrTime);
        } catch (ParseException e) {
            e.printStackTrace();
            System.out.println(e+"  [error]: 解析arrTime错误......");
        }
        String arrTmDay = arrTime.substring(0, 10);//2022022
        String arrTmHHmm = arrTime.substring(11, 13).concat(arrTime.substring(14, 16));//1550
        Integer arrt = Integer.valueOf(arrTmHHmm);
        //工作日判断
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int week_index = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (week_index < 0) {
            week_index = 0;
        }
        String esIndes = "dim_sf_batch_info";
        String query = "{\"query\":{\"bool\":{\"must\":[" +
                "{\"term\":{\"zonecode\":\""+zonecode+"\"}}," +
                "{\"term\":{\"arrive_date\":\""+week_index+"\"}}," +
                "{\"range\":{\"start_last_arr_tm\":{\"lte\":"+arrt+"}}}," +
                "{\"range\":{\"last_arr_tm\":{\"gte\":"+arrt+"}}}]}}" +
//                ", \"_source\": [\"batch_code\",\"batch_date\"]" +
                "}";
        String searchResult = ElasticSearchUtil.queryDSL(esIndes, query, true);
        JSONObject resultJson = JSON.parseObject(searchResult);
        JSONObject hits1 = resultJson.getJSONObject("hits");
        JSONArray hits = hits1.getJSONArray("hits");
        JSONObject hit = JSON.parseObject(hits.get(0).toString());

        String source = hit.getString("_source");
        JSONObject sourceResult = JSON.parseObject(source);
        BatchInfo batchInfo = new BatchInfo(sourceResult);

        batchInfo.setBatchDate(DateUtil.getLastDayString(arrTmDay, Integer.valueOf(batchInfo.batchDate)));

        ElasticSearchUtil.close();
        return batchInfo;
    }


    @Override
    public String toString() {
        return "BatchInfo{" +
                "zonecode='" + zonecode + '\'' +
                ", batchCode='" + batchCode + '\'' +
                ", batchDate='" + batchDate + '\'' +
                ", startTm='" + startTm + '\'' +
                ", endTm='" + endTm + '\'' +
                ", workDay='" + workDay + '\'' +
                ", validDt='" + validDt + '\'' +
                ", invldDt='" + invldDt + '\'' +
                ", startLastArrTm='" + startLastArrTm + '\'' +
                ", lastArrTm='" + lastArrTm + '\'' +
                '}';
    }
        public static void main(String[] args) {
            BatchInfo batchInfoFromCache = getBatchInfoFromCache("755W", "2022-07-15 00:44:00");
            BatchInfo batchInfo = getBatchInfoFromEs("755W", "2022-07-15 00:44:00");
        System.out.println(
                "班次代码: "+
                batchInfo.getBatchCode()
                        +"班次日期: "+
                batchInfo.getBatchDate()
                        +"上个班次最晚到达时间:"+
                batchInfo.getStartLastArrTm()
                        +"班次最晚到达时间:" +
                batchInfo.getLastArrTm());
    }

    public static BatchInfo getBatchInfoFromCache(String zonecode, String arrTime) {
        DateTimeFormatter df2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        DateTimeFormatter df3 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime start = LocalDate.parse(arrTime, df2).atStartOfDay();
        String lastDay = start.minusDays(1).format(df3);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = formatter.parse(arrTime);
        } catch (ParseException e) {
            e.printStackTrace();
            System.out.println(e+"  [error]: 解析arrTime错误......");
        }
        String arrTmDay = arrTime.substring(0, 10);//2022022
        String arrTmHHmm = arrTime.substring(11, 13).concat(arrTime.substring(14, 16));//1550
        Integer arrt = Integer.valueOf(arrTmHHmm);
        //工作日判断
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int week_index = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (week_index < 0) {
            week_index = 0;
        }
        return null;
    }

    public void setZonecode(String zonecode) {
        this.zonecode = zonecode;
    }

    public void setBatchCode(String batchCode) {
        this.batchCode = batchCode;
    }

    public void setBatchDate(String batchDate) {
        this.batchDate = batchDate;
    }

    public void setStartTm(String startTm) {
        this.startTm = startTm;
    }

    public void setEndTm(String endTm) {
        this.endTm = endTm;
    }

    public void setWorkDay(String workDay) {
        this.workDay = workDay;
    }

    public void setValidDt(String validDt) {
        this.validDt = validDt;
    }

    public void setInvldDt(String invldDt) {
        this.invldDt = invldDt;
    }

    public void setStartLastArrTm(String startLastArrTm) {
        this.startLastArrTm = startLastArrTm;
    }

    public void setLastArrTm(String lastArrTm) {
        this.lastArrTm = lastArrTm;
    }

    public String getZonecode() {
        return zonecode;
    }

    public String getBatchCode() {
        return batchCode;
    }

    public String getBatchDate() {
        return batchDate;
    }

    public String getStartTm() {
        return startTm;
    }

    public String getEndTm() {
        return endTm;
    }

    public String getWorkDay() {
        return workDay;
    }

    public String getValidDt() {
        return validDt;
    }

    public String getInvldDt() {
        return invldDt;
    }

    public String getStartLastArrTm() {
        return startLastArrTm;
    }

    public String getLastArrTm() {
        return lastArrTm;
    }




}
