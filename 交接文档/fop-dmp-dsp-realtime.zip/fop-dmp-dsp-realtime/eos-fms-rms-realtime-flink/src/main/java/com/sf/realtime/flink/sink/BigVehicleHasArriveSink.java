package com.sf.realtime.flink.sink;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.sf.realtime.common.config.Config;
import com.sf.realtime.common.utils.DateUtil;
import com.sf.realtime.flink.common.KafkaDataPreProcess;
import com.sf.realtime.flink.common.SqlUtil;
import com.sf.realtime.flink.dto.BigVehicleHasArriveDto;
import com.sf.realtime.flink.schema.BigVehicleHasArriveTaskSchema;
import com.sf.realtime.flink.schema.Schema;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.flink.types.Row;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.time.LocalDate;


/**
 * @Author 01419728
 * @Date 2022/3/18 20:33
 */
public class BigVehicleHasArriveSink extends RichSinkFunction<BigVehicleHasArriveDto> {

    private DruidDataSource dataSource = null;
    private DruidPooledConnection conn = null;
    private PreparedStatement ps = null;
    private static final Schema schema = new BigVehicleHasArriveTaskSchema();

    //创建连接池对象
    @Override
    public void open(Configuration parameters) throws Exception {
        com.typesafe.config.Config config = Config.getConfig();
        dataSource = new DruidDataSource();
        dataSource.setDriverClassName("com.mysql.jdbc.Driver");
        dataSource.setUrl(config.getString("tidb.jdbc.url"));
        dataSource.setUsername(config.getString("tidb.user"));
        dataSource.setPassword(config.getString("tidb.passwd"));
        dataSource.setInitialSize(10);   //初始化时建立物理连接的个数。初始化发生在显示调用init方法，或者第一次getConnection时
        dataSource.setMinIdle(10);  //最小连接池数量
        dataSource.setMaxActive(20);  //最大连接池数量
        dataSource.setMaxWait(1000 * 20); //获取连接时最大等待时间，单位毫秒。配置了maxWait之后，缺省启用公平锁，并发效率会有所下降，如果需要可以通过配置useUnfairLock属性为true使用非公平锁。
        dataSource.setTimeBetweenEvictionRunsMillis(1000 * 60);  //有两个含义：1) Destroy线程会检测连接的间隔时间2) testWhileIdle的判断依据，详细看testWhileIdle属性的说明
        dataSource.setMaxEvictableIdleTimeMillis(1000 * 60 * 60 * 10);  //<!-- 配置一个连接在池中最大生存的时间，单位是毫秒 -->
        dataSource.setMinEvictableIdleTimeMillis(1000 * 60 * 60 * 9);  //<!-- 配置一个连接在池中最小生存的时间，单位是毫秒 -->
        dataSource.setTestWhileIdle(true);  // <!-- 这里建议配置为TRUE，防止取到的连接不可用 -->
        dataSource.setTestOnBorrow(true);
        dataSource.setTestOnReturn(false);
        dataSource.setValidationQuery("select 1");
    }

    @Override
    public void invoke(BigVehicleHasArriveDto value, Context context) throws Exception {
        conn = dataSource.getConnection();
        ps = conn.prepareStatement(SqlUtil.getInsertByReplaceSql(schema));
//replace into vt_has_arrive_cars_big
// (idKey,requireId,carNo,transLevel,carStatus,srcZoneCode,destZoneCode,ticket,weight,actualTime,sendTime,lineCode,insertTime) values(?,?,?,?,?,?,?,?,?,?,?,?,?)
        ps.setString(1,value.getIdKey());
        ps.setString(2,value.getRequireId());
        ps.setString(3,value.getCarNo());
        ps.setInt(4,value.getTransLevel());
        ps.setInt(5,value.getCarStatus());
        ps.setString(6,value.getSrcZoneCode());
        ps.setString(7,value.getDestZoneCode());
        ps.setLong(8,value.getTicket());
        ps.setDouble(9,value.getWeight());
        ps.setLong(10,value.getActualTime());
        ps.setLong(11,value.getSendTime());
        ps.setString(12,value.getLineCode());
        ps.setTimestamp(13, new Timestamp(System.currentTimeMillis()));
        ps.execute();
        ps.close();
        conn.close();
    }

    @Override
    public void close() throws Exception {
        dataSource.close();
    }

}