package com.sf.realtime.flink.schema;

public class VehicleHasArriveTaskSchema extends Schema {
    public VehicleHasArriveTaskSchema() {
        super("VehicleHasArriveTaskSchema");
    }
}