package com.sf.realtime.flink.schema;

public class BigVehicleHasArriveTaskSchema extends Schema {
    public BigVehicleHasArriveTaskSchema() {
        super("BigVehicleHasArriveTaskSchema");
    }
}