package com.sf.realtime.flink.sink;

import com.sf.realtime.common.config.Config;
import org.apache.flink.api.java.io.jdbc.JDBCOutputFormat;

public class MysqlSink {
    public static JDBCOutputFormat getJDBCOutputFormat(String sql,int[] types){
        return JDBCOutputFormat.buildJDBCOutputFormat()
                .setDrivername("com.mysql.jdbc.Driver")
                .setDBUrl(Config.getConfig().getString("tidb.jdbc.url"))
                .setUsername(Config.getConfig().getString("tidb.user"))
                .setPassword(Config.getConfig().getString("tidb.passwd"))
                .setQuery(sql)
                .setBatchInterval(10)
                .setSqlTypes(types)
                .finish();
    }

    public static JDBCOutputFormat getJDBCOutputFormatForMysql(String sql,int[] types){
        return JDBCOutputFormat.buildJDBCOutputFormat()
                .setDrivername("com.mysql.jdbc.Driver")
                .setDBUrl(Config.getConfig().getString("mysql.jdbc.url"))
                .setUsername(Config.getConfig().getString("mysql.user"))
                .setPassword(Config.getConfig().getString("mysql.passwd"))
                .setQuery(sql)
                .setBatchInterval(10)
                .setSqlTypes(types)
                .finish();
}

}
