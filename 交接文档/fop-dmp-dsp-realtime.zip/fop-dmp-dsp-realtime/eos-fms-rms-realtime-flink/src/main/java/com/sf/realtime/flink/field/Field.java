package com.sf.realtime.flink.field;

public class Field {
    private String name;
    private Types type;
    private String comment;
    private Boolean isNone;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Types getType() {
        return type;
    }

    public void setType(Types type) {
        this.type = type;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Boolean getNone() {
        return isNone;
    }

    public void setNone(Boolean none) {
        isNone = none;
    }
}
